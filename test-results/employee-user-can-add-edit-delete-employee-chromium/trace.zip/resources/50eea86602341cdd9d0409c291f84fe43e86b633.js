(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_@mui_x-data-grid_esm_hooks_features_d6890b37._.js",
  "static/chunks/node_modules_@mui_x-data-grid_esm_hooks_9f39b2b6._.js",
  "static/chunks/node_modules_@mui_x-data-grid_esm_components_panel_96ba14d3._.js",
  "static/chunks/node_modules_@mui_x-data-grid_esm_components_cell_c876382c._.js",
  "static/chunks/node_modules_@mui_x-data-grid_esm_components_01595fde._.js",
  "static/chunks/node_modules_@mui_x-data-grid_esm_d1b76d49._.js",
  "static/chunks/node_modules_@mui_material_esm_8077f8fe._.js",
  "static/chunks/node_modules_@popperjs_core_lib_ce7e5cb7._.js",
  "static/chunks/node_modules_zod_v4_1267b87d._.js",
  "static/chunks/node_modules_560d69fc._.js",
  "static/chunks/src_82c72896._.js"
],
    source: "dynamic"
});

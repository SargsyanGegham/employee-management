(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/node_modules/@mui/x-data-grid/esm/constants/gridClasses.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getDataGridUtilityClass",
    ()=>getDataGridUtilityClass,
    "gridClasses",
    ()=>gridClasses
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$generateUtilityClass$2f$generateUtilityClass$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/utils/esm/generateUtilityClass/generateUtilityClass.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$generateUtilityClasses$2f$generateUtilityClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/utils/esm/generateUtilityClasses/generateUtilityClasses.js [app-client] (ecmascript)");
;
;
function getDataGridUtilityClass(slot) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$generateUtilityClass$2f$generateUtilityClass$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('MuiDataGrid', slot);
}
const gridClasses = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$generateUtilityClasses$2f$generateUtilityClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('MuiDataGrid', [
    'aiAssistantPanel',
    'aiAssistantPanelHeader',
    'aiAssistantPanelTitleContainer',
    'aiAssistantPanelTitle',
    'aiAssistantPanelBody',
    'aiAssistantPanelEmptyText',
    'aiAssistantPanelFooter',
    'aiAssistantPanelConversation',
    'aiAssistantPanelConversationList',
    'aiAssistantPanelConversationTitle',
    'aiAssistantPanelSuggestions',
    'aiAssistantPanelSuggestionsList',
    'aiAssistantPanelSuggestionsItem',
    'aiAssistantPanelSuggestionsLabel',
    'actionsCell',
    'aggregationColumnHeader',
    'aggregationColumnHeader--alignLeft',
    'aggregationColumnHeader--alignCenter',
    'aggregationColumnHeader--alignRight',
    'aggregationColumnHeaderLabel',
    'aggregationRowOverlayWrapper',
    'autoHeight',
    'autosizing',
    'mainContent',
    'withSidePanel',
    'booleanCell',
    'cell--editable',
    'cell--editing',
    'cell--flex',
    'cell--textCenter',
    'cell--textLeft',
    'cell--textRight',
    'cell--rangeTop',
    'cell--rangeBottom',
    'cell--rangeLeft',
    'cell--rangeRight',
    'cell--pinnedLeft',
    'cell--pinnedRight',
    'cell--selectionMode',
    'cell',
    'cellCheckbox',
    'cellEmpty',
    'cellSkeleton',
    'cellOffsetLeft',
    'checkboxInput',
    'collapsible',
    'collapsibleTrigger',
    'collapsibleIcon',
    'collapsiblePanel',
    'columnHeader',
    'columnHeader--alignCenter',
    'columnHeader--alignLeft',
    'columnHeader--alignRight',
    'columnHeader--dragging',
    'columnHeader--moving',
    'columnHeader--numeric',
    'columnHeader--sortable',
    'columnHeader--sorted',
    'columnHeader--filtered',
    'columnHeader--pinnedLeft',
    'columnHeader--pinnedRight',
    'columnHeader--last',
    'columnHeader--siblingFocused',
    'columnHeader--filter',
    'columnHeaderFilterInput',
    'columnHeaderFilterOperatorLabel',
    'columnHeaderCheckbox',
    'columnHeaderDraggableContainer',
    'columnHeaderTitle',
    'columnHeaderTitleContainer',
    'columnHeaderTitleContainerContent',
    'columnHeader--filledGroup',
    'columnHeader--emptyGroup',
    'columnHeaders',
    'columnSeparator--resizable',
    'columnSeparator--resizing',
    'columnSeparator--sideLeft',
    'columnSeparator--sideRight',
    'columnSeparator',
    'columnsManagement',
    'columnsManagementRow',
    'columnsManagementHeader',
    'columnsManagementSearchInput',
    'columnsManagementFooter',
    'columnsManagementScrollArea',
    'columnsManagementEmptyText',
    'container--top',
    'container--bottom',
    'detailPanel',
    'detailPanelToggleCell',
    'detailPanelToggleCell--expanded',
    'footerCell',
    'panel',
    'panelHeader',
    'panelWrapper',
    'panelContent',
    'panelFooter',
    'paper',
    'editBooleanCell',
    'editInputCell',
    'longTextCell',
    'longTextCellContent',
    'longTextCellExpandButton',
    'longTextCellCollapseButton',
    'longTextCellPopup',
    'longTextCellPopperContent',
    'editLongTextCell',
    'editLongTextCellValue',
    'editLongTextCellPopup',
    'editLongTextCellPopperContent',
    'editLongTextCellTextarea',
    'filler',
    'filler--borderBottom',
    'filler--pinnedLeft',
    'filler--pinnedRight',
    'filterForm',
    'filterFormDeleteIcon',
    'filterFormLogicOperatorInput',
    'filterFormColumnInput',
    'filterFormOperatorInput',
    'filterFormValueInput',
    'filterIcon',
    'footerContainer',
    'headerFilterRow',
    'iconButtonContainer',
    'iconSeparator',
    'main',
    'main--hasPinnedRight',
    'main--hiddenContent',
    'menu',
    'menuIcon',
    'menuIconButton',
    'menuOpen',
    'menuList',
    'overlay',
    'overlayWrapper',
    'overlayWrapperInner',
    'root',
    'root--densityStandard',
    'root--densityComfortable',
    'root--densityCompact',
    'root--disableUserSelection',
    'root--noToolbar',
    'row',
    'row--editable',
    'row--editing',
    'row--firstVisible',
    'row--lastVisible',
    // TODO v9: Rename to `cell--dragging`
    'row--dragging',
    'row--beingDragged',
    'row--dynamicHeight',
    'row--detailPanelExpanded',
    'row--borderBottom',
    'rowReorderCellPlaceholder',
    'rowCount',
    'rowReorderCellContainer',
    'rowReorderCell',
    'rowReorderCell--draggable',
    'rowReorderIcon',
    'rowSkeleton',
    'scrollArea--left',
    'scrollArea--right',
    'scrollArea--up',
    'scrollArea--down',
    'scrollArea',
    'scrollbar',
    'scrollbar--vertical',
    'scrollbar--horizontal',
    'scrollbarFiller',
    'scrollbarFiller--pinnedRight',
    'scrollShadow',
    'scrollShadow--vertical',
    'scrollShadow--horizontal',
    'selectedRowCount',
    'sortButton',
    'sortIcon',
    'shadowScrollArea',
    'sidebar',
    'sidebarHeader',
    'toolbarContainer',
    'toolbar',
    'toolbarLabel',
    'toolbarDivider',
    'toolbarFilterList',
    'toolbarQuickFilter',
    'toolbarQuickFilterTrigger',
    'toolbarQuickFilterControl',
    'virtualScroller',
    'virtualScroller--hasScrollX',
    'virtualScrollerContent',
    'virtualScrollerContent--overflowed',
    'virtualScrollerRenderZone',
    'withVerticalBorder',
    'withBorderColor',
    'cell--withRightBorder',
    'cell--withLeftBorder',
    'columnHeader--withRightBorder',
    'columnHeader--withLeftBorder',
    'treeDataGroupingCell',
    'treeDataGroupingCellToggle',
    'treeDataGroupingCellLoadingContainer',
    'groupingCriteriaCell',
    'groupingCriteriaCellToggle',
    'groupingCriteriaCellLoadingContainer',
    'pinnedRows',
    'pinnedRows--top',
    'pinnedRows--bottom',
    'pivotPanelAvailableFields',
    'pivotPanelField',
    'pivotPanelField--sorted',
    'pivotPanelFieldActionContainer',
    'pivotPanelFieldCheckbox',
    'pivotPanelFieldDragIcon',
    'pivotPanelFieldList',
    'pivotPanelFieldName',
    'pivotPanelHeader',
    'pivotPanelPlaceholder',
    'pivotPanelScrollArea',
    'pivotPanelSearchContainer',
    'pivotPanelSection',
    'pivotPanelSectionTitle',
    'pivotPanelSections',
    'pivotPanelSwitch',
    'pivotPanelSwitchLabel',
    'prompt',
    'promptContent',
    'promptText',
    'promptFeedback',
    'promptChangeList',
    'promptChangesToggle',
    'promptChangesToggleIcon',
    'promptIcon',
    'promptIconContainer',
    'promptError',
    'promptAction'
]);
}),
"[project]/node_modules/@mui/x-data-grid/esm/constants/cssVariables.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "vars",
    ()=>vars
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$extends$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@babel/runtime/helpers/esm/extends.js [app-client] (ecmascript)");
;
// NOTE: Breakpoints can't come from the theme because we need access to them at
// initialization time and media-queries can't use CSS variables. For users with
// custom breakpoints, we might want to provide a way to configure them globally
// instead of through the theme.
const breakpoints = {
    values: {
        xs: 0,
        // phone
        sm: 600,
        // tablet
        md: 900,
        // small laptop
        lg: 1200,
        // desktop
        xl: 1536 // large screen
    },
    up: (key)=>{
        const values = breakpoints.values;
        const value = typeof values[key] === 'number' ? values[key] : key;
        return `@media (min-width:${value}px)`;
    }
};
const keys = {
    spacingUnit: '--DataGrid-t-spacing-unit',
    /* Variables */ colors: {
        border: {
            base: '--DataGrid-t-color-border-base'
        },
        foreground: {
            base: '--DataGrid-t-color-foreground-base',
            muted: '--DataGrid-t-color-foreground-muted',
            accent: '--DataGrid-t-color-foreground-accent',
            disabled: '--DataGrid-t-color-foreground-disabled',
            error: '--DataGrid-t-color-foreground-error'
        },
        background: {
            base: '--DataGrid-t-color-background-base',
            overlay: '--DataGrid-t-color-background-overlay',
            backdrop: '--DataGrid-t-color-background-backdrop'
        },
        interactive: {
            hover: '--DataGrid-t-color-interactive-hover',
            hoverOpacity: '--DataGrid-t-color-interactive-hover-opacity',
            focus: '--DataGrid-t-color-interactive-focus',
            focusOpacity: '--DataGrid-t-color-interactive-focus-opacity',
            disabled: '--DataGrid-t-color-interactive-disabled',
            disabledOpacity: '--DataGrid-t-color-interactive-disabled-opacity',
            selected: '--DataGrid-t-color-interactive-selected',
            selectedOpacity: '--DataGrid-t-color-interactive-selected-opacity'
        }
    },
    header: {
        background: {
            base: '--DataGrid-t-header-background-base'
        }
    },
    cell: {
        background: {
            pinned: '--DataGrid-t-cell-background-pinned'
        }
    },
    radius: {
        base: '--DataGrid-t-radius-base'
    },
    typography: {
        font: {
            body: '--DataGrid-t-typography-font-body',
            small: '--DataGrid-t-typography-font-small',
            large: '--DataGrid-t-typography-font-large'
        },
        fontFamily: {
            base: '--DataGrid-t-typography-font-family-base'
        },
        fontWeight: {
            light: '--DataGrid-t-typography-font-weight-light',
            regular: '--DataGrid-t-typography-font-weight-regular',
            medium: '--DataGrid-t-typography-font-weight-medium',
            bold: '--DataGrid-t-typography-font-weight-bold'
        }
    },
    transitions: {
        easing: {
            easeIn: '--DataGrid-t-transition-easing-ease-in',
            easeOut: '--DataGrid-t-transition-easing-ease-out',
            easeInOut: '--DataGrid-t-transition-easing-ease-in-out'
        },
        duration: {
            short: '--DataGrid-t-transition-duration-short',
            base: '--DataGrid-t-transition-duration-base',
            long: '--DataGrid-t-transition-duration-long'
        }
    },
    shadows: {
        base: '--DataGrid-t-shadow-base',
        overlay: '--DataGrid-t-shadow-overlay'
    },
    zIndex: {
        panel: '--DataGrid-t-z-index-panel',
        menu: '--DataGrid-t-z-index-menu'
    }
};
const values = wrap(keys);
const vars = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$extends$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({
    breakpoints,
    spacing,
    transition,
    keys
}, values);
function spacing(a, b, c, d) {
    /* eslint-disable prefer-template */ if (a === undefined) {
        return spacingString(1);
    }
    if (b === undefined) {
        return spacingString(a);
    }
    if (c === undefined) {
        return spacingString(a) + ' ' + spacingString(b);
    }
    if (d === undefined) {
        return spacingString(a) + ' ' + spacingString(b) + ' ' + spacingString(c);
    }
    return spacingString(a) + ' ' + spacingString(b) + ' ' + spacingString(c) + ' ' + spacingString(d);
/* eslint-enable prefer-template */ }
function spacingString(value) {
    if (value === 0) {
        return '0';
    }
    return `calc(var(--DataGrid-t-spacing-unit) * ${value})`;
}
function transition(props, options) {
    const { duration = vars.transitions.duration.base, easing = vars.transitions.easing.easeInOut, delay = 0 } = options ?? {};
    return props.map((prop)=>`${prop} ${duration} ${easing} ${delay}ms`).join(', ');
}
function wrap(input) {
    if (typeof input === 'string') {
        return `var(${input})`;
    }
    const result = {};
    for(const key in input){
        if (Object.hasOwn(input, key)) {
            result[key] = wrap(input[key]);
        }
    }
    return result;
}
}),
"[project]/node_modules/@mui/x-data-grid/esm/constants/signature.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Signal to the underlying logic what version of the public component API
 * of the Data Grid is exposed.
 */ __turbopack_context__.s([
    "GridSignature",
    ()=>GridSignature
]);
let GridSignature = /*#__PURE__*/ function(GridSignature) {
    GridSignature["DataGrid"] = "DataGrid";
    GridSignature["DataGridPro"] = "DataGridPro";
    GridSignature["DataGridPremium"] = "DataGridPremium";
    return GridSignature;
}({});
}),
"[project]/node_modules/@mui/x-data-grid/esm/constants/dataGridPropsDefaultValues.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DATA_GRID_PROPS_DEFAULT_VALUES",
    ()=>DATA_GRID_PROPS_DEFAULT_VALUES
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$models$2f$gridEditRowModel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/models/gridEditRowModel.js [app-client] (ecmascript)");
;
const DATA_GRID_PROPS_DEFAULT_VALUES = {
    autoHeight: false,
    autoPageSize: false,
    autosizeOnMount: false,
    checkboxSelection: false,
    checkboxSelectionVisibleOnly: false,
    clipboardCopyCellDelimiter: '\t',
    columnBufferPx: 150,
    columnFilterDebounceMs: 150,
    columnHeaderHeight: 56,
    disableAutosize: false,
    disableColumnFilter: false,
    disableColumnMenu: false,
    disableColumnReorder: false,
    disableColumnResize: false,
    disableColumnSelector: false,
    disableColumnSorting: false,
    disableDensitySelector: false,
    disableEval: false,
    disableMultipleColumnsFiltering: false,
    disableMultipleColumnsSorting: false,
    disableMultipleRowSelection: false,
    dataSourceRevalidateMs: 0,
    disableRowSelectionOnClick: false,
    disableRowSelectionExcludeModel: false,
    disableVirtualization: false,
    editMode: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$models$2f$gridEditRowModel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridEditModes"].Cell,
    filterDebounceMs: 150,
    filterMode: 'client',
    hideFooter: false,
    hideFooterPagination: false,
    hideFooterRowCount: false,
    hideFooterSelectedRowCount: false,
    ignoreDiacritics: false,
    ignoreValueFormatterDuringExport: false,
    keepColumnPositionIfDraggedOutside: false,
    keepNonExistentRowsSelected: false,
    loading: false,
    logger: console,
    logLevel: ("TURBOPACK compile-time falsy", 0) ? "TURBOPACK unreachable" : 'warn',
    pageSizeOptions: [
        25,
        50,
        100
    ],
    pagination: false,
    paginationMode: 'client',
    resizeThrottleMs: 60,
    rowBufferPx: 150,
    rowHeight: 52,
    rows: [],
    rowSelection: true,
    rowSpacingType: 'margin',
    rowSpanning: false,
    showCellVerticalBorder: false,
    showColumnVerticalBorder: false,
    showToolbar: false,
    sortingMode: 'client',
    sortingOrder: [
        'asc',
        'desc',
        null
    ],
    throttleRowsMs: 0,
    virtualizeColumnsWithAutoRowHeight: false,
    tabNavigation: 'none'
};
}),
"[project]/node_modules/@mui/x-data-grid/esm/constants/localeTextConstants.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "GRID_DEFAULT_LOCALE_TEXT",
    ()=>GRID_DEFAULT_LOCALE_TEXT
]);
const GRID_DEFAULT_LOCALE_TEXT = {
    // Root
    noRowsLabel: 'No rows',
    noResultsOverlayLabel: 'No results found.',
    noColumnsOverlayLabel: 'No columns',
    noColumnsOverlayManageColumns: 'Manage columns',
    emptyPivotOverlayLabel: 'Add fields to rows, columns, and values to create a pivot table',
    // Density selector toolbar button text
    toolbarDensity: 'Density',
    toolbarDensityLabel: 'Density',
    toolbarDensityCompact: 'Compact',
    toolbarDensityStandard: 'Standard',
    toolbarDensityComfortable: 'Comfortable',
    // Undo/redo toolbar button text
    toolbarUndo: 'Undo',
    toolbarRedo: 'Redo',
    // Columns selector toolbar button text
    toolbarColumns: 'Columns',
    toolbarColumnsLabel: 'Select columns',
    // Filters toolbar button text
    toolbarFilters: 'Filters',
    toolbarFiltersLabel: 'Show filters',
    toolbarFiltersTooltipHide: 'Hide filters',
    toolbarFiltersTooltipShow: 'Show filters',
    toolbarFiltersTooltipActive: (count)=>count !== 1 ? `${count} active filters` : `${count} active filter`,
    // Quick filter toolbar field
    toolbarQuickFilterPlaceholder: 'Search…',
    toolbarQuickFilterLabel: 'Search',
    toolbarQuickFilterDeleteIconLabel: 'Clear',
    // Export selector toolbar button text
    toolbarExport: 'Export',
    toolbarExportLabel: 'Export',
    toolbarExportCSV: 'Download as CSV',
    toolbarExportPrint: 'Print',
    toolbarExportExcel: 'Download as Excel',
    // Toolbar pivot button
    toolbarPivot: 'Pivot',
    // Toolbar charts button
    toolbarCharts: 'Charts',
    // Toolbar AI Assistant button
    toolbarAssistant: 'AI Assistant',
    // Columns management text
    columnsManagementSearchTitle: 'Search',
    columnsManagementNoColumns: 'No columns',
    columnsManagementShowHideAllText: 'Show/Hide All',
    columnsManagementReset: 'Reset',
    columnsManagementDeleteIconLabel: 'Clear',
    // Filter panel text
    filterPanelAddFilter: 'Add filter',
    filterPanelRemoveAll: 'Remove all',
    filterPanelDeleteIconLabel: 'Delete',
    filterPanelLogicOperator: 'Logic operator',
    filterPanelOperator: 'Operator',
    filterPanelOperatorAnd: 'And',
    filterPanelOperatorOr: 'Or',
    filterPanelColumns: 'Columns',
    filterPanelInputLabel: 'Value',
    filterPanelInputPlaceholder: 'Filter value',
    // Filter operators text
    filterOperatorContains: 'contains',
    filterOperatorDoesNotContain: 'does not contain',
    filterOperatorEquals: 'equals',
    filterOperatorDoesNotEqual: 'does not equal',
    filterOperatorStartsWith: 'starts with',
    filterOperatorEndsWith: 'ends with',
    filterOperatorIs: 'is',
    filterOperatorNot: 'is not',
    filterOperatorAfter: 'is after',
    filterOperatorOnOrAfter: 'is on or after',
    filterOperatorBefore: 'is before',
    filterOperatorOnOrBefore: 'is on or before',
    filterOperatorIsEmpty: 'is empty',
    filterOperatorIsNotEmpty: 'is not empty',
    filterOperatorIsAnyOf: 'is any of',
    'filterOperator=': '=',
    'filterOperator!=': '!=',
    'filterOperator>': '>',
    'filterOperator>=': '>=',
    'filterOperator<': '<',
    'filterOperator<=': '<=',
    // Header filter operators text
    headerFilterOperatorContains: 'Contains',
    headerFilterOperatorDoesNotContain: 'Does not contain',
    headerFilterOperatorEquals: 'Equals',
    headerFilterOperatorDoesNotEqual: 'Does not equal',
    headerFilterOperatorStartsWith: 'Starts with',
    headerFilterOperatorEndsWith: 'Ends with',
    headerFilterOperatorIs: 'Is',
    headerFilterOperatorNot: 'Is not',
    headerFilterOperatorAfter: 'Is after',
    headerFilterOperatorOnOrAfter: 'Is on or after',
    headerFilterOperatorBefore: 'Is before',
    headerFilterOperatorOnOrBefore: 'Is on or before',
    headerFilterOperatorIsEmpty: 'Is empty',
    headerFilterOperatorIsNotEmpty: 'Is not empty',
    headerFilterOperatorIsAnyOf: 'Is any of',
    'headerFilterOperator=': 'Equals',
    'headerFilterOperator!=': 'Not equals',
    'headerFilterOperator>': 'Greater than',
    'headerFilterOperator>=': 'Greater than or equal to',
    'headerFilterOperator<': 'Less than',
    'headerFilterOperator<=': 'Less than or equal to',
    headerFilterClear: 'Clear filter',
    // Filter values text
    filterValueAny: 'any',
    filterValueTrue: 'true',
    filterValueFalse: 'false',
    // Column menu text
    columnMenuLabel: 'Menu',
    columnMenuAriaLabel: (columnName)=>`${columnName} column menu`,
    columnMenuShowColumns: 'Show columns',
    columnMenuManageColumns: 'Manage columns',
    columnMenuFilter: 'Filter',
    columnMenuHideColumn: 'Hide column',
    columnMenuUnsort: 'Unsort',
    columnMenuSortAsc: 'Sort by ASC',
    columnMenuSortDesc: 'Sort by DESC',
    columnMenuManagePivot: 'Manage pivot',
    columnMenuManageCharts: 'Manage charts',
    // Column header text
    columnHeaderFiltersTooltipActive: (count)=>count !== 1 ? `${count} active filters` : `${count} active filter`,
    columnHeaderFiltersLabel: 'Show filters',
    columnHeaderSortIconLabel: 'Sort',
    // Rows selected footer text
    footerRowSelected: (count)=>count !== 1 ? `${count.toLocaleString()} rows selected` : `${count.toLocaleString()} row selected`,
    // Total row amount footer text
    footerTotalRows: 'Total Rows:',
    // Total visible row amount footer text
    footerTotalVisibleRows: (visibleCount, totalCount)=>`${visibleCount.toLocaleString()} of ${totalCount.toLocaleString()}`,
    // Checkbox selection text
    checkboxSelectionHeaderName: 'Checkbox selection',
    checkboxSelectionSelectAllRows: 'Select all rows',
    checkboxSelectionUnselectAllRows: 'Unselect all rows',
    checkboxSelectionSelectRow: 'Select row',
    checkboxSelectionUnselectRow: 'Unselect row',
    // Boolean cell text
    booleanCellTrueLabel: 'yes',
    booleanCellFalseLabel: 'no',
    // Long text cell
    longTextCellExpandLabel: 'Expand',
    longTextCellCollapseLabel: 'Collapse',
    // Actions cell more text
    actionsCellMore: 'more',
    // Column pinning text
    pinToLeft: 'Pin to left',
    pinToRight: 'Pin to right',
    unpin: 'Unpin',
    // Tree Data
    treeDataGroupingHeaderName: 'Group',
    treeDataExpand: 'see children',
    treeDataCollapse: 'hide children',
    // Grouping columns
    groupingColumnHeaderName: 'Group',
    groupColumn: (name)=>`Group by ${name}`,
    unGroupColumn: (name)=>`Stop grouping by ${name}`,
    // Master/detail
    detailPanelToggle: 'Detail panel toggle',
    expandDetailPanel: 'Expand',
    collapseDetailPanel: 'Collapse',
    // Pagination
    paginationRowsPerPage: 'Rows per page:',
    paginationDisplayedRows: ({ from, to, count, estimated })=>{
        if (!estimated) {
            return `${from}–${to} of ${count !== -1 ? count : `more than ${to}`}`;
        }
        const estimatedLabel = estimated && estimated > to ? `around ${estimated}` : `more than ${to}`;
        return `${from}–${to} of ${count !== -1 ? count : estimatedLabel}`;
    },
    paginationItemAriaLabel: (type)=>{
        if (type === 'first') {
            return 'Go to first page';
        }
        if (type === 'last') {
            return 'Go to last page';
        }
        if (type === 'next') {
            return 'Go to next page';
        }
        // if (type === 'previous') {
        return 'Go to previous page';
    },
    // Row reordering text
    rowReorderingHeaderName: 'Row reordering',
    // Aggregation
    aggregationMenuItemHeader: 'Aggregation',
    aggregationFunctionLabelNone: 'none',
    aggregationFunctionLabelSum: 'sum',
    aggregationFunctionLabelAvg: 'avg',
    aggregationFunctionLabelMin: 'min',
    aggregationFunctionLabelMax: 'max',
    aggregationFunctionLabelSize: 'size',
    // Pivot panel
    pivotToggleLabel: 'Pivot',
    pivotRows: 'Rows',
    pivotColumns: 'Columns',
    pivotValues: 'Values',
    pivotCloseButton: 'Close pivot settings',
    pivotSearchButton: 'Search fields',
    pivotSearchControlPlaceholder: 'Search fields',
    pivotSearchControlLabel: 'Search fields',
    pivotSearchControlClear: 'Clear search',
    pivotNoFields: 'No fields',
    pivotMenuMoveUp: 'Move up',
    pivotMenuMoveDown: 'Move down',
    pivotMenuMoveToTop: 'Move to top',
    pivotMenuMoveToBottom: 'Move to bottom',
    pivotMenuRows: 'Rows',
    pivotMenuColumns: 'Columns',
    pivotMenuValues: 'Values',
    pivotMenuOptions: 'Field options',
    pivotMenuAddToRows: 'Add to Rows',
    pivotMenuAddToColumns: 'Add to Columns',
    pivotMenuAddToValues: 'Add to Values',
    pivotMenuRemove: 'Remove',
    pivotDragToRows: 'Drag here to create rows',
    pivotDragToColumns: 'Drag here to create columns',
    pivotDragToValues: 'Drag here to create values',
    pivotYearColumnHeaderName: '(Year)',
    pivotQuarterColumnHeaderName: '(Quarter)',
    // Charts configuration panel
    chartsNoCharts: 'There are no charts available',
    chartsChartNotSelected: 'Select a chart type to configure its options',
    chartsTabChart: 'Chart',
    chartsTabFields: 'Fields',
    chartsTabCustomize: 'Customize',
    chartsCloseButton: 'Close charts configuration',
    chartsSyncButtonLabel: 'Sync chart',
    chartsSearchPlaceholder: 'Search fields',
    chartsSearchLabel: 'Search fields',
    chartsSearchClear: 'Clear search',
    chartsNoFields: 'No fields',
    chartsFieldBlocked: 'This field cannot be added to any section',
    chartsCategories: 'Categories',
    chartsSeries: 'Series',
    chartsMenuAddToDimensions: (dimensionLabel)=>`Add to ${dimensionLabel}`,
    chartsMenuAddToValues: (valuesLabel)=>`Add to ${valuesLabel}`,
    chartsMenuMoveUp: 'Move up',
    chartsMenuMoveDown: 'Move down',
    chartsMenuMoveToTop: 'Move to top',
    chartsMenuMoveToBottom: 'Move to bottom',
    chartsMenuOptions: 'Field options',
    chartsMenuRemove: 'Remove',
    chartsDragToDimensions: (dimensionLabel)=>`Drag here to use column as ${dimensionLabel}`,
    chartsDragToValues: (valuesLabel)=>`Drag here to use column as ${valuesLabel}`,
    // AI Assistant panel
    aiAssistantPanelTitle: 'AI Assistant',
    aiAssistantPanelClose: 'Close AI Assistant',
    aiAssistantPanelNewConversation: 'New conversation',
    aiAssistantPanelConversationHistory: 'Conversation history',
    aiAssistantPanelEmptyConversation: 'No prompt history',
    aiAssistantSuggestions: 'Suggestions',
    // Prompt field
    promptFieldLabel: 'Prompt',
    promptFieldPlaceholder: 'Type a prompt…',
    promptFieldPlaceholderWithRecording: 'Type or record a prompt…',
    promptFieldPlaceholderListening: 'Listening for prompt…',
    promptFieldSpeechRecognitionNotSupported: 'Speech recognition is not supported in this browser',
    promptFieldSend: 'Send',
    promptFieldRecord: 'Record',
    promptFieldStopRecording: 'Stop recording',
    // Prompt
    promptRerun: 'Run again',
    promptProcessing: 'Processing…',
    promptAppliedChanges: 'Applied changes',
    // Prompt changes
    promptChangeGroupDescription: (column)=>`Group by ${column}`,
    promptChangeAggregationLabel: (column, aggregation)=>`${column} (${aggregation})`,
    promptChangeAggregationDescription: (column, aggregation)=>`Aggregate ${column} (${aggregation})`,
    promptChangeFilterLabel: (column, operator, value)=>{
        if (operator === 'is any of') {
            return `${column} is any of: ${value}`;
        }
        return `${column} ${operator} ${value}`;
    },
    promptChangeFilterDescription: (column, operator, value)=>{
        if (operator === 'is any of') {
            return `Filter where ${column} is any of: ${value}`;
        }
        return `Filter where ${column} ${operator} ${value}`;
    },
    promptChangeSortDescription: (column, direction)=>`Sort by ${column} (${direction})`,
    promptChangePivotEnableLabel: 'Pivot',
    promptChangePivotEnableDescription: 'Enable pivot',
    promptChangePivotColumnsLabel: (count)=>`Columns (${count})`,
    promptChangePivotColumnsDescription: (column, direction)=>`${column}${direction ? ` (${direction})` : ''}`,
    promptChangePivotRowsLabel: (count)=>`Rows (${count})`,
    promptChangePivotValuesLabel: (count)=>`Values (${count})`,
    promptChangePivotValuesDescription: (column, aggregation)=>`${column} (${aggregation})`,
    promptChangeChartsLabel: (dimensionsCount, valuesCount)=>`Dimensions (${dimensionsCount}), Values (${valuesCount})`
};
}),
"[project]/node_modules/@mui/x-data-grid/esm/constants/defaultGridSlotsComponents.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DATA_GRID_DEFAULT_SLOTS_COMPONENTS",
    ()=>DATA_GRID_DEFAULT_SLOTS_COMPONENTS
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$extends$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@babel/runtime/helpers/esm/extends.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$cell$2f$GridSkeletonCell$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/components/cell/GridSkeletonCell.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$panel$2f$GridColumnsPanel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/components/panel/GridColumnsPanel.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$panel$2f$filterPanel$2f$GridFilterPanel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/components/panel/filterPanel/GridFilterPanel.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$GridFooter$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/components/GridFooter.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$GridLoadingOverlay$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/components/GridLoadingOverlay.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$GridNoRowsOverlay$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/components/GridNoRowsOverlay.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$GridPagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/components/GridPagination.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$panel$2f$GridPanel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/components/panel/GridPanel.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$GridRow$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/components/GridRow.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$columnHeaders$2f$GridColumnHeaderFilterIconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/components/columnHeaders/GridColumnHeaderFilterIconButton.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$GridRowCount$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/components/GridRowCount.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$columnsManagement$2f$GridColumnsManagement$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/components/columnsManagement/GridColumnsManagement.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$columnHeaders$2f$GridColumnHeaderSortIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/components/columnHeaders/GridColumnHeaderSortIcon.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$GridNoColumnsOverlay$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/components/GridNoColumnsOverlay.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$cell$2f$GridCell$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/components/cell/GridCell.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$GridColumnHeaders$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/components/GridColumnHeaders.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$menu$2f$columnMenu$2f$GridColumnMenu$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/components/menu/columnMenu/GridColumnMenu.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$GridDetailPanels$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/components/GridDetailPanels.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$GridPinnedRows$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/components/GridPinnedRows.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$GridNoResultsOverlay$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/components/GridNoResultsOverlay.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$material$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/material/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$virtualization$2f$GridBottomContainer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/components/virtualization/GridBottomContainer.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$toolbarV8$2f$GridToolbar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/components/toolbarV8/GridToolbar.js [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
const DATA_GRID_DEFAULT_SLOTS_COMPONENTS = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$extends$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({}, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$material$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["default"], {
    cell: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$cell$2f$GridCell$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridCell"],
    skeletonCell: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$cell$2f$GridSkeletonCell$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridSkeletonCell"],
    columnHeaderFilterIconButton: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$columnHeaders$2f$GridColumnHeaderFilterIconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridColumnHeaderFilterIconButton"],
    columnHeaderSortIcon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$columnHeaders$2f$GridColumnHeaderSortIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridColumnHeaderSortIcon"],
    columnMenu: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$menu$2f$columnMenu$2f$GridColumnMenu$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridColumnMenu"],
    columnHeaders: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$GridColumnHeaders$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridColumnHeaders"],
    detailPanels: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$GridDetailPanels$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridDetailPanels"],
    bottomContainer: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$virtualization$2f$GridBottomContainer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridBottomContainer"],
    footer: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$GridFooter$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridFooter"],
    footerRowCount: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$GridRowCount$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridRowCount"],
    toolbar: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$toolbarV8$2f$GridToolbar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridToolbar"],
    pinnedRows: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$GridPinnedRows$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridPinnedRows"],
    loadingOverlay: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$GridLoadingOverlay$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridLoadingOverlay"],
    noResultsOverlay: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$GridNoResultsOverlay$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridNoResultsOverlay"],
    noRowsOverlay: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$GridNoRowsOverlay$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridNoRowsOverlay"],
    noColumnsOverlay: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$GridNoColumnsOverlay$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridNoColumnsOverlay"],
    pagination: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$GridPagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridPagination"],
    filterPanel: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$panel$2f$filterPanel$2f$GridFilterPanel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridFilterPanel"],
    columnsPanel: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$panel$2f$GridColumnsPanel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridColumnsPanel"],
    columnsManagement: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$columnsManagement$2f$GridColumnsManagement$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridColumnsManagement"],
    panel: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$panel$2f$GridPanel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridPanel"],
    row: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$GridRow$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridRow"]
});
}),
"[project]/node_modules/@mui/x-data-grid/esm/context/GridRootPropsContext.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "GridRootPropsContext",
    ()=>GridRootPropsContext
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
'use client';
;
const GridRootPropsContext = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"](undefined);
if ("TURBOPACK compile-time truthy", 1) GridRootPropsContext.displayName = "GridRootPropsContext";
;
}),
"[project]/node_modules/@mui/x-data-grid/esm/context/GridContextProvider.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "GridContextProvider",
    ()=>GridContextProvider
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$GridApiContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/components/GridApiContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$utils$2f$useGridPrivateApiContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/hooks/utils/useGridPrivateApiContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$context$2f$GridRootPropsContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/context/GridRootPropsContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$GridConfigurationContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/components/GridConfigurationContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$panel$2f$GridPanelContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/components/panel/GridPanelContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$utils$2f$css$2f$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/utils/css/context.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
'use client';
;
;
;
;
;
;
;
;
function GridContextProvider({ privateApiRef, configuration, props, children }) {
    const apiRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](privateApiRef.current.getPublicApi());
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$GridConfigurationContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridConfigurationContext"].Provider, {
        value: configuration,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$context$2f$GridRootPropsContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridRootPropsContext"].Provider, {
            value: props,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$utils$2f$useGridPrivateApiContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridPrivateApiContext"].Provider, {
                value: privateApiRef,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$GridApiContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridApiContext"].Provider, {
                    value: apiRef,
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$panel$2f$GridPanelContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridPanelContextProvider"], {
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$utils$2f$css$2f$context$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridCSSVariablesContext"], {
                            children: children
                        })
                    })
                })
            })
        })
    });
}
}),
"[project]/node_modules/@mui/x-data-grid/esm/utils/css/context.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "GridCSSVariablesContext",
    ()=>GridCSSVariablesContext,
    "GridPortalWrapper",
    ()=>GridPortalWrapper,
    "useCSSVariablesClass",
    ()=>useCSSVariablesClass,
    "useCSSVariablesContext",
    ()=>useCSSVariablesContext
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$utils$2f$useGridRootProps$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/hooks/utils/useGridRootProps.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$utils$2f$useGridConfiguration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/hooks/utils/useGridConfiguration.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
'use client';
;
;
;
;
const CLASSNAME_PREFIX = 'MuiDataGridVariables';
const CSSVariablesContext = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"]({
    className: 'unset',
    tag: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("style", {
        href: "/unset"
    })
});
if ("TURBOPACK compile-time truthy", 1) CSSVariablesContext.displayName = "CSSVariablesContext";
function useCSSVariablesClass() {
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"](CSSVariablesContext).className;
}
function useCSSVariablesContext() {
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"](CSSVariablesContext);
}
function GridPortalWrapper({ children }) {
    const className = useCSSVariablesClass();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", {
        className: className,
        children: children
    });
}
function GridCSSVariablesContext(props) {
    const config = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$utils$2f$useGridConfiguration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGridConfiguration"])();
    const rootProps = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$utils$2f$useGridRootProps$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGridRootProps"])();
    const description = config.hooks.useCSSVariables();
    const context = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "GridCSSVariablesContext.useMemo[context]": ()=>{
            const className = `${CLASSNAME_PREFIX}-${description.id}`;
            const cssString = `.${className}{${variablesToString(description.variables)}}`;
            const tag = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("style", {
                href: `/${className}`,
                nonce: rootProps.nonce,
                children: cssString
            });
            return {
                className,
                tag
            };
        }
    }["GridCSSVariablesContext.useMemo[context]"], [
        rootProps.nonce,
        description
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(CSSVariablesContext.Provider, {
        value: context,
        children: props.children
    });
}
function variablesToString(variables) {
    let output = '';
    for(const key in variables){
        if (Object.hasOwn(variables, key) && variables[key] !== undefined) {
            output += `${key}:${variables[key]};`;
        }
    }
    return output;
}
}),
"[project]/node_modules/@mui/x-data-grid/esm/utils/createSelector.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createRootSelector",
    ()=>createRootSelector,
    "createSelector",
    ()=>createSelector,
    "createSelectorMemoized",
    ()=>createSelectorMemoized
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$internals$2f$esm$2f$store$2f$createSelector$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-internals/esm/store/createSelector.js [app-client] (ecmascript)");
;
const createSelector = (...args)=>{
    const baseSelector = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$internals$2f$esm$2f$store$2f$createSelector$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelector"])(...args);
    const selector = (apiRef, a1, a2, a3)=>baseSelector(unwrapIfNeeded(apiRef), a1, a2, a3);
    return selector;
};
const createSelectorMemoized = (...args)=>{
    const baseSelector = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$internals$2f$esm$2f$store$2f$createSelector$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSelectorMemoized"])(...args);
    const selector = (apiRef, a1, a2, a3)=>baseSelector(unwrapIfNeeded(apiRef), a1, a2, a3);
    return selector;
};
const createRootSelector = (fn)=>(apiRef, args)=>fn(unwrapIfNeeded(apiRef), args);
function unwrapIfNeeded(refOrState) {
    if ('current' in refOrState) {
        return refOrState.current.state;
    }
    return refOrState;
}
}),
"[project]/node_modules/@mui/x-data-grid/esm/utils/cleanupTracking/TimerBasedCleanupTracking.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "TimerBasedCleanupTracking",
    ()=>TimerBasedCleanupTracking
]);
// If no effect ran after this amount of time, we assume that the render was not committed by React
const CLEANUP_TIMER_LOOP_MILLIS = 1000;
class TimerBasedCleanupTracking {
    timeouts = (()=>new Map())();
    cleanupTimeout = (()=>CLEANUP_TIMER_LOOP_MILLIS)();
    constructor(timeout = CLEANUP_TIMER_LOOP_MILLIS){
        this.cleanupTimeout = timeout;
    }
    register(object, unsubscribe, unregisterToken) {
        if (!this.timeouts) {
            this.timeouts = new Map();
        }
        const timeout = setTimeout(()=>{
            if (typeof unsubscribe === 'function') {
                unsubscribe();
            }
            this.timeouts.delete(unregisterToken.cleanupToken);
        }, this.cleanupTimeout);
        this.timeouts.set(unregisterToken.cleanupToken, timeout);
    }
    unregister(unregisterToken) {
        const timeout = this.timeouts.get(unregisterToken.cleanupToken);
        if (timeout) {
            this.timeouts.delete(unregisterToken.cleanupToken);
            clearTimeout(timeout);
        }
    }
    reset() {
        if (this.timeouts) {
            this.timeouts.forEach((value, key)=>{
                this.unregister({
                    cleanupToken: key
                });
            });
            this.timeouts = undefined;
        }
    }
}
}),
"[project]/node_modules/@mui/x-data-grid/esm/utils/cleanupTracking/FinalizationRegistryBasedCleanupTracking.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "FinalizationRegistryBasedCleanupTracking",
    ()=>FinalizationRegistryBasedCleanupTracking
]);
class FinalizationRegistryBasedCleanupTracking {
    registry = (()=>new FinalizationRegistry((unsubscribe)=>{
            if (typeof unsubscribe === 'function') {
                unsubscribe();
            }
        }))();
    register(object, unsubscribe, unregisterToken) {
        this.registry.register(object, unsubscribe, unregisterToken);
    }
    unregister(unregisterToken) {
        this.registry.unregister(unregisterToken);
    }
    reset() {}
}
}),
"[project]/node_modules/@mui/x-data-grid/esm/utils/assert.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "NotRendered",
    ()=>NotRendered
]);
function NotRendered(_props) {
    throw new Error('Failed assertion: should not be rendered');
}
}),
"[project]/node_modules/@mui/x-data-grid/esm/utils/utils.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "clamp",
    ()=>clamp,
    "createRandomNumberGenerator",
    ()=>createRandomNumberGenerator,
    "deepClone",
    ()=>deepClone,
    "escapeRegExp",
    ()=>escapeRegExp,
    "eslintUseValue",
    ()=>eslintUseValue,
    "isFunction",
    ()=>isFunction,
    "isNumber",
    ()=>isNumber,
    "isObject",
    ()=>isObject,
    "localStorageAvailable",
    ()=>localStorageAvailable,
    "range",
    ()=>range,
    "runIf",
    ()=>runIf
]);
function isNumber(value) {
    return typeof value === 'number' && !Number.isNaN(value);
}
function isFunction(value) {
    return typeof value === 'function';
}
function isObject(value) {
    return typeof value === 'object' && value !== null;
}
function localStorageAvailable() {
    try {
        // Incognito mode might reject access to the localStorage for security reasons.
        // window isn't defined on Node.js
        // https://stackoverflow.com/questions/16427636/check-if-localstorage-is-available
        const key = '__some_random_key_you_are_not_going_to_use__';
        window.localStorage.setItem(key, key);
        window.localStorage.removeItem(key);
        return true;
    } catch (err) {
        return false;
    }
}
function escapeRegExp(value) {
    return value.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, '\\$&');
}
const clamp = (value, min, max)=>Math.max(min, Math.min(max, value));
function range(from, to) {
    return Array.from({
        length: to - from
    }).map((_, i)=>from + i);
}
// Pseudo random number. See https://stackoverflow.com/a/47593316
function mulberry32(a) {
    return ()=>{
        /* eslint-disable */ let t = a += 0x6d2b79f5;
        t = Math.imul(t ^ t >>> 15, t | 1);
        t ^= t + Math.imul(t ^ t >>> 7, t | 61);
        return ((t ^ t >>> 14) >>> 0) / 4294967296;
    /* eslint-enable */ };
}
function createRandomNumberGenerator(seed) {
    const random = mulberry32(seed);
    return (min, max)=>min + (max - min) * random();
}
function deepClone(obj) {
    if (typeof structuredClone === 'function') {
        return structuredClone(obj);
    }
    return JSON.parse(JSON.stringify(obj));
}
function eslintUseValue(_) {}
const runIf = (condition, fn)=>(...params)=>{
        if (condition) {
            fn(...params);
        }
    };
}),
"[project]/node_modules/@mui/x-data-grid/esm/utils/getPublicApiRef.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getPublicApiRef",
    ()=>getPublicApiRef
]);
function getPublicApiRef(apiRef) {
    return {
        current: apiRef.current.getPublicApi()
    };
}
}),
"[project]/node_modules/@mui/x-data-grid/esm/utils/keyboardUtils.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// Non printable keys have a name, for example "ArrowRight", see the whole list:
// https://developer.mozilla.org/en-US/docs/Web/API/UI_Events/Keyboard_event_key_values
// So event.key.length === 1 is often enough.
//
// However, we also need to ignore shortcuts, for example: select all:
// - Windows: Ctrl+A, event.ctrlKey is true
// - macOS: ⌘ Command+A, event.metaKey is true
__turbopack_context__.s([
    "isCopyShortcut",
    ()=>isCopyShortcut,
    "isHideMenuKey",
    ()=>isHideMenuKey,
    "isKeyboardEvent",
    ()=>isKeyboardEvent,
    "isNavigationKey",
    ()=>isNavigationKey,
    "isPasteShortcut",
    ()=>isPasteShortcut,
    "isPrintableKey",
    ()=>isPrintableKey,
    "isRedoShortcut",
    ()=>isRedoShortcut,
    "isUndoShortcut",
    ()=>isUndoShortcut
]);
function isPrintableKey(event) {
    return event.key.length === 1 && !event.ctrlKey && !event.metaKey;
}
const isNavigationKey = (key)=>key.indexOf('Arrow') === 0 || key.indexOf('Page') === 0 || key === ' ' || key === 'Home' || key === 'End';
const isKeyboardEvent = (event)=>!!event.key;
const isHideMenuKey = (key)=>key === 'Tab' || key === 'Escape';
function isPasteShortcut(event) {
    return (event.ctrlKey || event.metaKey) && // We can't use event.code === 'KeyV' as event.code assumes a QWERTY keyboard layout,
    // for example, it would be another letter on a Dvorak physical keyboard.
    // We can't use event.key === 'v' as event.key is not stable with key modifiers and keyboard layouts,
    // for example, it would be ה on a Hebrew keyboard layout.
    // https://github.com/w3c/uievents/issues/377 could be a long-term solution
    String.fromCharCode(event.keyCode) === 'V' && !event.shiftKey && !event.altKey;
}
function isCopyShortcut(event) {
    return (event.ctrlKey || event.metaKey) && String.fromCharCode(event.keyCode) === 'C' && !event.shiftKey && !event.altKey;
}
function isUndoShortcut(event) {
    return (event.ctrlKey || event.metaKey) && String.fromCharCode(event.keyCode) === 'Z' && !event.shiftKey && !event.altKey;
}
function isRedoShortcut(event) {
    return (event.ctrlKey || event.metaKey) && (String.fromCharCode(event.keyCode) === 'Z' && event.shiftKey || String.fromCharCode(event.keyCode) === 'Y' && !event.shiftKey) && !event.altKey;
}
}),
"[project]/node_modules/@mui/x-data-grid/esm/utils/exportAs.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * I have hesitated to use https://github.com/eligrey/FileSaver.js.
 * If we get bug reports that this project solves, we should consider using it.
 *
 * Related resources.
 * https://blog.logrocket.com/programmatic-file-downloads-in-the-browser-9a5186298d5c/
 * https://github.com/mbrn/filefy/blob/ec4ed0b7415d93be7158c23029f2ea1fa0b8e2d9/src/core/BaseBuilder.ts
 * https://unpkg.com/browse/@progress/kendo-file-saver@1.0.7/dist/es/save-as.js
 * https://github.com/ag-grid/ag-grid/blob/9565c219b6210aa85fa833c929d0728f9d163a91/community-modules/csv-export/src/csvExport/downloader.ts
 */ __turbopack_context__.s([
    "exportAs",
    ()=>exportAs
]);
function exportAs(blob, extension = 'csv', filename = document.title || 'untitled') {
    const fullName = `${filename}.${extension}`;
    // Test download attribute first
    // https://github.com/eligrey/FileSaver.js/issues/193
    if ('download' in HTMLAnchorElement.prototype) {
        // Create an object URL for the blob object
        const url = URL.createObjectURL(blob);
        // Create a new anchor element
        const a = document.createElement('a');
        a.href = url;
        a.download = fullName;
        // Programmatically trigger a click on the anchor element
        // Useful if you want the download to happen automatically
        // Without attaching the anchor element to the DOM
        a.click();
        // https://github.com/eligrey/FileSaver.js/issues/205
        setTimeout(()=>{
            URL.revokeObjectURL(url);
        });
        return;
    }
    throw new Error('MUI X: exportAs not supported.');
}
}),
"[project]/node_modules/@mui/x-data-grid/esm/utils/doesSupportPreventScroll.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "doesSupportPreventScroll",
    ()=>doesSupportPreventScroll
]);
// Based on https://stackoverflow.com/a/59518678
let cachedSupportsPreventScroll;
function doesSupportPreventScroll() {
    if (cachedSupportsPreventScroll === undefined) {
        document.createElement('div').focus({
            get preventScroll () {
                cachedSupportsPreventScroll = true;
                return false;
            }
        });
    }
    return cachedSupportsPreventScroll;
}
}),
"[project]/node_modules/@mui/x-data-grid/esm/utils/domUtils.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "escapeOperandAttributeSelector",
    ()=>escapeOperandAttributeSelector,
    "findGridCellElementsFromCol",
    ()=>findGridCellElementsFromCol,
    "findGridCells",
    ()=>findGridCells,
    "findGridElement",
    ()=>findGridElement,
    "findGridHeader",
    ()=>findGridHeader,
    "findGridHeaderFilter",
    ()=>findGridHeaderFilter,
    "findGroupHeaderElementsFromField",
    ()=>findGroupHeaderElementsFromField,
    "findHeaderElementFromField",
    ()=>findHeaderElementFromField,
    "findLeftPinnedCellsAfterCol",
    ()=>findLeftPinnedCellsAfterCol,
    "findLeftPinnedHeadersAfterCol",
    ()=>findLeftPinnedHeadersAfterCol,
    "findParentElementFromClassName",
    ()=>findParentElementFromClassName,
    "findRightPinnedCellsBeforeCol",
    ()=>findRightPinnedCellsBeforeCol,
    "findRightPinnedHeadersBeforeCol",
    ()=>findRightPinnedHeadersBeforeCol,
    "getActiveElement",
    ()=>getActiveElement,
    "getFieldFromHeaderElem",
    ()=>getFieldFromHeaderElem,
    "getFieldsFromGroupHeaderElem",
    ()=>getFieldsFromGroupHeaderElem,
    "getGridCellElement",
    ()=>getGridCellElement,
    "getGridColumnHeaderElement",
    ()=>getGridColumnHeaderElement,
    "getGridRowElement",
    ()=>getGridRowElement,
    "isEventTargetInPortal",
    ()=>isEventTargetInPortal,
    "isOverflown",
    ()=>isOverflown
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$constants$2f$gridClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/constants/gridClasses.js [app-client] (ecmascript)");
;
function isOverflown(element) {
    return element.scrollHeight > element.clientHeight || element.scrollWidth > element.clientWidth;
}
function findParentElementFromClassName(elem, className) {
    return elem.closest(`.${className}`);
}
function escapeOperandAttributeSelector(operand) {
    return operand.replace(/["\\]/g, '\\$&');
}
function getGridColumnHeaderElement(root, field) {
    return root.querySelector(`[role="columnheader"][data-field="${escapeOperandAttributeSelector(field)}"]`);
}
function getGridRowElementSelector(id) {
    return `.${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$constants$2f$gridClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["gridClasses"].row}[data-id="${escapeOperandAttributeSelector(String(id))}"]`;
}
function getGridRowElement(root, id) {
    return root.querySelector(getGridRowElementSelector(id));
}
function getGridCellElement(root, { id, field }) {
    const rowSelector = getGridRowElementSelector(id);
    const cellSelector = `.${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$constants$2f$gridClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["gridClasses"].cell}[data-field="${escapeOperandAttributeSelector(field)}"]`;
    const selector = `${rowSelector} ${cellSelector}`;
    return root.querySelector(selector);
}
const getActiveElement = (root = document)=>{
    const activeEl = root.activeElement;
    if (!activeEl) {
        return null;
    }
    if (activeEl.shadowRoot) {
        return getActiveElement(activeEl.shadowRoot);
    }
    return activeEl;
};
function isEventTargetInPortal(event) {
    if (// The target is not an element when triggered by a Select inside the cell
    // See https://github.com/mui/material-ui/issues/10534
    event.target.nodeType === 1 && !event.currentTarget.contains(event.target)) {
        return true;
    }
    return false;
}
function getFieldFromHeaderElem(colCellEl) {
    return colCellEl.getAttribute('data-field');
}
function findHeaderElementFromField(elem, field) {
    return elem.querySelector(`[data-field="${escapeOperandAttributeSelector(field)}"]`);
}
function getFieldsFromGroupHeaderElem(colCellEl) {
    return colCellEl.getAttribute('data-fields').slice(2, -2).split('-|-');
}
function findGroupHeaderElementsFromField(elem, field) {
    return Array.from(elem.querySelectorAll(`[data-fields*="|-${escapeOperandAttributeSelector(field)}-|"]`) ?? []);
}
function findGridCellElementsFromCol(col, api) {
    const root = findParentElementFromClassName(col, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$constants$2f$gridClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["gridClasses"].root);
    if (!root) {
        throw new Error('MUI X: The root element is not found.');
    }
    const ariaColIndex = col.getAttribute('aria-colindex');
    if (!ariaColIndex) {
        return [];
    }
    const colIndex = Number(ariaColIndex) - 1;
    const cells = [];
    if (!api.virtualScrollerRef?.current) {
        return [];
    }
    queryRows(api).forEach((rowElement)=>{
        const rowId = rowElement.getAttribute('data-id');
        if (!rowId) {
            return;
        }
        let columnIndex = colIndex;
        const cellColSpanInfo = api.unstable_getCellColSpanInfo(rowId, colIndex);
        if (cellColSpanInfo && cellColSpanInfo.spannedByColSpan) {
            columnIndex = cellColSpanInfo.leftVisibleCellIndex;
        }
        const cell = rowElement.querySelector(`[data-colindex="${columnIndex}"]`);
        if (cell) {
            cells.push(cell);
        }
    });
    return cells;
}
function findGridElement(api, klass) {
    return api.rootElementRef.current.querySelector(`.${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$constants$2f$gridClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["gridClasses"][klass]}`);
}
const findPinnedCells = ({ api, colIndex, position, filterFn })=>{
    if (colIndex === null) {
        return [];
    }
    const cells = [];
    queryRows(api).forEach((rowElement)=>{
        const rowId = rowElement.getAttribute('data-id');
        if (!rowId) {
            return;
        }
        rowElement.querySelectorAll(`.${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$constants$2f$gridClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["gridClasses"][position === 'left' ? 'cell--pinnedLeft' : 'cell--pinnedRight']}`).forEach((cell)=>{
            const currentColIndex = parseCellColIndex(cell);
            if (currentColIndex !== null && filterFn(currentColIndex)) {
                cells.push(cell);
            }
        });
    });
    return cells;
};
function findLeftPinnedCellsAfterCol(api, col, isRtl) {
    const colIndex = parseCellColIndex(col);
    return findPinnedCells({
        api,
        colIndex,
        position: isRtl ? 'right' : 'left',
        filterFn: (index)=>isRtl ? index < colIndex : index > colIndex
    });
}
function findRightPinnedCellsBeforeCol(api, col, isRtl) {
    const colIndex = parseCellColIndex(col);
    return findPinnedCells({
        api,
        colIndex,
        position: isRtl ? 'left' : 'right',
        filterFn: (index)=>isRtl ? index > colIndex : index < colIndex
    });
}
const findPinnedHeaders = ({ api, colIndex, position, filterFn })=>{
    if (!api.columnHeadersContainerRef?.current) {
        return [];
    }
    if (colIndex === null) {
        return [];
    }
    const elements = [];
    api.columnHeadersContainerRef.current.querySelectorAll(`.${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$constants$2f$gridClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["gridClasses"][position === 'left' ? 'columnHeader--pinnedLeft' : 'columnHeader--pinnedRight']}`).forEach((element)=>{
        const currentColIndex = parseCellColIndex(element);
        if (currentColIndex !== null && filterFn(currentColIndex, element)) {
            elements.push(element);
        }
    });
    return elements;
};
function findLeftPinnedHeadersAfterCol(api, col, isRtl) {
    const colIndex = parseCellColIndex(col);
    return findPinnedHeaders({
        api,
        position: isRtl ? 'right' : 'left',
        colIndex,
        filterFn: (index)=>isRtl ? index < colIndex : index > colIndex
    });
}
function findRightPinnedHeadersBeforeCol(api, col, isRtl) {
    const colIndex = parseCellColIndex(col);
    return findPinnedHeaders({
        api,
        position: isRtl ? 'left' : 'right',
        colIndex,
        filterFn: (index, element)=>{
            if (element.classList.contains(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$constants$2f$gridClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["gridClasses"]['columnHeader--last'])) {
                return false;
            }
            return isRtl ? index > colIndex : index < colIndex;
        }
    });
}
function findGridHeader(api, field) {
    const headers = api.columnHeadersContainerRef.current;
    return headers.querySelector(`:scope > div > [data-field="${escapeOperandAttributeSelector(field)}"][role="columnheader"]`);
}
function findGridHeaderFilter(api, field) {
    const headers = api.columnHeadersContainerRef.current;
    return headers.querySelector(`:scope > .${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$constants$2f$gridClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["gridClasses"].headerFilterRow} > [data-field="${escapeOperandAttributeSelector(field)}"]`);
}
function findGridCells(api, field) {
    const container = api.virtualScrollerRef.current;
    return Array.from(container.querySelectorAll(`:scope > div > div > div > [data-field="${escapeOperandAttributeSelector(field)}"][role="gridcell"]`));
}
function queryRows(api) {
    return api.virtualScrollerRef.current.querySelectorAll(// Use > to ignore rows from nested Data Grids (for example in detail panel)
    `:scope > div > div > .${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$constants$2f$gridClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["gridClasses"].row}`);
}
function parseCellColIndex(col) {
    const ariaColIndex = col.getAttribute('aria-colindex');
    if (!ariaColIndex) {
        return null;
    }
    return Number(ariaColIndex) - 1;
}
}),
"[project]/node_modules/@mui/x-data-grid/esm/utils/isJSDOM.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "isJSDOM",
    ()=>isJSDOM
]);
const isJSDOM = typeof window !== 'undefined' && /jsdom|HappyDOM/.test(window.navigator.userAgent);
}),
"[project]/node_modules/@mui/x-data-grid/esm/utils/createControllablePromise.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createControllablePromise",
    ()=>createControllablePromise
]);
function createControllablePromise() {
    let resolve;
    let reject;
    const promise = new Promise((_resolve, _reject)=>{
        resolve = _resolve;
        reject = _reject;
    });
    promise.resolve = resolve;
    promise.reject = reject;
    return promise;
}
}),
"[project]/node_modules/@mui/x-data-grid/esm/utils/cellBorderUtils.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "shouldCellShowLeftBorder",
    ()=>shouldCellShowLeftBorder,
    "shouldCellShowRightBorder",
    ()=>shouldCellShowRightBorder
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$internals$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/internals/constants.js [app-client] (ecmascript)");
;
const shouldCellShowRightBorder = (pinnedPosition, indexInSection, sectionLength, showCellVerticalBorderRootProp, gridHasFiller, pinnedColumnsSectionSeparatorRootProp)=>{
    const isSectionLastCell = indexInSection === sectionLength - 1;
    if (pinnedColumnsSectionSeparatorRootProp?.startsWith('border') && pinnedPosition === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$internals$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PinnedColumnPosition"].LEFT && isSectionLastCell) {
        return true;
    }
    if (showCellVerticalBorderRootProp) {
        if (pinnedPosition === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$internals$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PinnedColumnPosition"].LEFT) {
            return true;
        }
        if (pinnedPosition === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$internals$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PinnedColumnPosition"].RIGHT) {
            return !isSectionLastCell;
        }
        // pinnedPosition === undefined, middle section
        return !isSectionLastCell || gridHasFiller;
    }
    return false;
};
const shouldCellShowLeftBorder = (pinnedPosition, indexInSection, showCellVerticalBorderRootProp, pinnedColumnsSectionSeparatorRootProp)=>{
    if (pinnedColumnsSectionSeparatorRootProp?.startsWith('border')) {
        return pinnedPosition === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$internals$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PinnedColumnPosition"].RIGHT && indexInSection === 0;
    }
    return showCellVerticalBorderRootProp && pinnedPosition === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$internals$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PinnedColumnPosition"].RIGHT && indexInSection === 0;
};
}),
"[project]/node_modules/@mui/x-data-grid/esm/utils/rtlFlipSide.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "rtlFlipSide",
    ()=>rtlFlipSide
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$internals$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/internals/constants.js [app-client] (ecmascript)");
;
const rtlFlipSide = (position, isRtl)=>{
    if (!position) {
        return undefined;
    }
    if (!isRtl) {
        if (position === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$internals$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PinnedColumnPosition"].LEFT) {
            return 'left';
        }
        if (position === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$internals$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PinnedColumnPosition"].RIGHT) {
            return 'right';
        }
    } else {
        if (position === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$internals$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PinnedColumnPosition"].LEFT) {
            return 'right';
        }
        if (position === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$internals$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PinnedColumnPosition"].RIGHT) {
            return 'left';
        }
    }
    return undefined;
};
}),
"[project]/node_modules/@mui/x-data-grid/esm/utils/composeGridClasses.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "composeGridClasses",
    ()=>composeGridClasses
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$composeClasses$2f$composeClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/utils/esm/composeClasses/composeClasses.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$constants$2f$gridClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/constants/gridClasses.js [app-client] (ecmascript)");
;
;
function composeGridClasses(classes, slots) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$composeClasses$2f$composeClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(slots, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$constants$2f$gridClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDataGridUtilityClass"], classes);
}
}),
"[project]/node_modules/@mui/x-data-grid/esm/models/gridFilterItem.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "GridLogicOperator",
    ()=>GridLogicOperator
]);
/**
 * Filter item definition interface.
 * @demos
 *   - [Custom filter operator](/x/react-data-grid/filtering/customization/#create-a-custom-operator)
 */ var GridLogicOperator = /*#__PURE__*/ function(GridLogicOperator) {
    GridLogicOperator["And"] = "and";
    GridLogicOperator["Or"] = "or";
    return GridLogicOperator;
}(GridLogicOperator || {});
;
}),
"[project]/node_modules/@mui/x-data-grid/esm/models/params/gridEditCellParams.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "GridCellEditStartReasons",
    ()=>GridCellEditStartReasons,
    "GridCellEditStopReasons",
    ()=>GridCellEditStopReasons
]);
/**
 * Params passed to `apiRef.current.setEditCellValue`.
 */ var GridCellEditStartReasons = /*#__PURE__*/ function(GridCellEditStartReasons) {
    GridCellEditStartReasons["enterKeyDown"] = "enterKeyDown";
    GridCellEditStartReasons["cellDoubleClick"] = "cellDoubleClick";
    GridCellEditStartReasons["printableKeyDown"] = "printableKeyDown";
    GridCellEditStartReasons["deleteKeyDown"] = "deleteKeyDown";
    GridCellEditStartReasons["pasteKeyDown"] = "pasteKeyDown";
    return GridCellEditStartReasons;
}(GridCellEditStartReasons || {});
/**
 * Params passed to the `cellEditStart` event.
 */ var GridCellEditStopReasons = /*#__PURE__*/ function(GridCellEditStopReasons) {
    GridCellEditStopReasons["cellFocusOut"] = "cellFocusOut";
    GridCellEditStopReasons["escapeKeyDown"] = "escapeKeyDown";
    GridCellEditStopReasons["enterKeyDown"] = "enterKeyDown";
    GridCellEditStopReasons["tabKeyDown"] = "tabKeyDown";
    GridCellEditStopReasons["shiftTabKeyDown"] = "shiftTabKeyDown";
    return GridCellEditStopReasons;
}(GridCellEditStopReasons || {});
;
}),
"[project]/node_modules/@mui/x-data-grid/esm/models/gridEditRowModel.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "GridCellModes",
    ()=>GridCellModes,
    "GridEditModes",
    ()=>GridEditModes,
    "GridRowModes",
    ()=>GridRowModes
]);
var GridEditModes = /*#__PURE__*/ function(GridEditModes) {
    GridEditModes["Cell"] = "cell";
    GridEditModes["Row"] = "row";
    return GridEditModes;
}(GridEditModes || {});
var GridCellModes = /*#__PURE__*/ function(GridCellModes) {
    GridCellModes["Edit"] = "edit";
    GridCellModes["View"] = "view";
    return GridCellModes;
}(GridCellModes || {});
var GridRowModes = /*#__PURE__*/ function(GridRowModes) {
    GridRowModes["Edit"] = "edit";
    GridRowModes["View"] = "view";
    return GridRowModes;
}(GridRowModes || {});
;
}),
"[project]/node_modules/@mui/x-data-grid/esm/models/gridRowSelectionManager.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createRowSelectionManager",
    ()=>createRowSelectionManager
]);
class IncludeManager {
    constructor(model){
        this.data = model.ids;
    }
    has(id) {
        return this.data.has(id);
    }
    select(id) {
        this.data.add(id);
    }
    unselect(id) {
        this.data.delete(id);
    }
}
class ExcludeManager {
    constructor(model){
        this.data = model.ids;
    }
    has(id) {
        return !this.data.has(id);
    }
    select(id) {
        this.data.delete(id);
    }
    unselect(id) {
        this.data.add(id);
    }
}
const createRowSelectionManager = (model)=>{
    if (model.type === 'include') {
        return new IncludeManager(model);
    }
    return new ExcludeManager(model);
};
}),
"[project]/node_modules/@mui/x-data-grid/esm/models/params/gridRowParams.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "GridRowEditStartReasons",
    ()=>GridRowEditStartReasons,
    "GridRowEditStopReasons",
    ()=>GridRowEditStopReasons
]);
/**
 * Object passed as parameter in the row callbacks.
 * @demos
 *   - [Master-detail row panels](/x/react-data-grid/master-detail/)
 */ /**
 * Object passed as parameter in the row `getRowClassName` callback prop.
 * @demos
 *   - [Styling rows](/x/react-data-grid/style/#styling-rows)
 */ /**
 * Object passed as parameter in the row `getRowHeight` callback prop.
 */ /**
 * The getRowHeight return value.
 */ var GridRowEditStartReasons = /*#__PURE__*/ function(GridRowEditStartReasons) {
    GridRowEditStartReasons["enterKeyDown"] = "enterKeyDown";
    GridRowEditStartReasons["cellDoubleClick"] = "cellDoubleClick";
    GridRowEditStartReasons["printableKeyDown"] = "printableKeyDown";
    GridRowEditStartReasons["deleteKeyDown"] = "deleteKeyDown";
    return GridRowEditStartReasons;
}(GridRowEditStartReasons || {});
/**
 * Params passed to the `rowEditStart` event.
 */ var GridRowEditStopReasons = /*#__PURE__*/ function(GridRowEditStopReasons) {
    GridRowEditStopReasons["rowFocusOut"] = "rowFocusOut";
    GridRowEditStopReasons["escapeKeyDown"] = "escapeKeyDown";
    GridRowEditStopReasons["enterKeyDown"] = "enterKeyDown";
    GridRowEditStopReasons["tabKeyDown"] = "tabKeyDown";
    GridRowEditStopReasons["shiftTabKeyDown"] = "shiftTabKeyDown";
    return GridRowEditStopReasons;
}(GridRowEditStopReasons || {});
;
}),
"[project]/node_modules/@mui/x-data-grid/esm/models/gridColumnGrouping.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "isLeaf",
    ()=>isLeaf
]);
function isLeaf(node) {
    return node.field !== undefined;
} /**
 * A function used to process headerClassName params.
 * @param {GridColumnGroupHeaderParams} params The parameters of the column group header.
 * @returns {string} The class name to be added to the column group header cell.
 */  /**
 * The union type representing the [[GridColDef]] column header class type.
 */ 
}),
"[project]/node_modules/@mui/x-data-grid/esm/colDef/gridStringOperators.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getGridStringOperators",
    ()=>getGridStringOperators,
    "getGridStringQuickFilterFn",
    ()=>getGridStringQuickFilterFn
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$panel$2f$filterPanel$2f$GridFilterInputValue$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/components/panel/filterPanel/GridFilterInputValue.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$utils$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/utils/utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$panel$2f$filterPanel$2f$GridFilterInputMultipleValue$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/components/panel/filterPanel/GridFilterInputMultipleValue.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$filter$2f$gridFilterUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/hooks/features/filter/gridFilterUtils.js [app-client] (ecmascript)");
;
;
;
;
const getGridStringQuickFilterFn = (value)=>{
    if (!value) {
        return null;
    }
    const filterRegex = new RegExp((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$utils$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["escapeRegExp"])(value), 'i');
    return (_, row, column, apiRef)=>{
        let columnValue = apiRef.current.getRowFormattedValue(row, column);
        if (apiRef.current.ignoreDiacritics) {
            columnValue = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$filter$2f$gridFilterUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["removeDiacritics"])(columnValue);
        }
        return columnValue != null ? filterRegex.test(columnValue.toString()) : false;
    };
};
const createContainsFilterFn = (disableTrim, negate)=>(filterItem)=>{
        if (!filterItem.value) {
            return null;
        }
        const trimmedValue = disableTrim ? filterItem.value : filterItem.value.trim();
        const filterRegex = new RegExp((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$utils$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["escapeRegExp"])(trimmedValue), 'i');
        return (value)=>{
            if (value == null) {
                return negate;
            }
            const matches = filterRegex.test(String(value));
            return negate ? !matches : matches;
        };
    };
const createEqualityFilterFn = (disableTrim, negate)=>(filterItem)=>{
        if (!filterItem.value) {
            return null;
        }
        const trimmedValue = disableTrim ? filterItem.value : filterItem.value.trim();
        const collator = new Intl.Collator(undefined, {
            sensitivity: 'base',
            usage: 'search'
        });
        return (value)=>{
            if (value == null) {
                return negate;
            }
            const isEqual = collator.compare(trimmedValue, value.toString()) === 0;
            return negate ? !isEqual : isEqual;
        };
    };
const createEmptyFilterFn = (negate)=>()=>{
        return (value)=>{
            const isEmpty = value === '' || value == null;
            return negate ? !isEmpty : isEmpty;
        };
    };
const getGridStringOperators = (disableTrim = false)=>[
        {
            value: 'contains',
            getApplyFilterFn: createContainsFilterFn(disableTrim, false),
            InputComponent: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$panel$2f$filterPanel$2f$GridFilterInputValue$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridFilterInputValue"]
        },
        {
            value: 'doesNotContain',
            getApplyFilterFn: createContainsFilterFn(disableTrim, true),
            InputComponent: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$panel$2f$filterPanel$2f$GridFilterInputValue$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridFilterInputValue"]
        },
        {
            value: 'equals',
            getApplyFilterFn: createEqualityFilterFn(disableTrim, false),
            InputComponent: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$panel$2f$filterPanel$2f$GridFilterInputValue$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridFilterInputValue"]
        },
        {
            value: 'doesNotEqual',
            getApplyFilterFn: createEqualityFilterFn(disableTrim, true),
            InputComponent: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$panel$2f$filterPanel$2f$GridFilterInputValue$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridFilterInputValue"]
        },
        {
            value: 'startsWith',
            getApplyFilterFn: (filterItem)=>{
                if (!filterItem.value) {
                    return null;
                }
                const filterItemValue = disableTrim ? filterItem.value : filterItem.value.trim();
                const filterRegex = new RegExp(`^${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$utils$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["escapeRegExp"])(filterItemValue)}.*$`, 'i');
                return (value)=>{
                    return value != null ? filterRegex.test(value.toString()) : false;
                };
            },
            InputComponent: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$panel$2f$filterPanel$2f$GridFilterInputValue$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridFilterInputValue"]
        },
        {
            value: 'endsWith',
            getApplyFilterFn: (filterItem)=>{
                if (!filterItem.value) {
                    return null;
                }
                const filterItemValue = disableTrim ? filterItem.value : filterItem.value.trim();
                const filterRegex = new RegExp(`.*${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$utils$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["escapeRegExp"])(filterItemValue)}$`, 'i');
                return (value)=>{
                    return value != null ? filterRegex.test(value.toString()) : false;
                };
            },
            InputComponent: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$panel$2f$filterPanel$2f$GridFilterInputValue$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridFilterInputValue"]
        },
        {
            value: 'isEmpty',
            getApplyFilterFn: createEmptyFilterFn(false),
            requiresFilterValue: false
        },
        {
            value: 'isNotEmpty',
            getApplyFilterFn: createEmptyFilterFn(true),
            requiresFilterValue: false
        },
        {
            value: 'isAnyOf',
            getApplyFilterFn: (filterItem)=>{
                if (!Array.isArray(filterItem.value) || filterItem.value.length === 0) {
                    return null;
                }
                const filterItemValue = disableTrim ? filterItem.value : filterItem.value.map((val)=>val.trim());
                const collator = new Intl.Collator(undefined, {
                    sensitivity: 'base',
                    usage: 'search'
                });
                return (value)=>value != null ? filterItemValue.some((filterValue)=>{
                        return collator.compare(filterValue, value.toString() || '') === 0;
                    }) : false;
            },
            InputComponent: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$panel$2f$filterPanel$2f$GridFilterInputMultipleValue$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridFilterInputMultipleValue"]
        }
    ];
}),
"[project]/node_modules/@mui/x-data-grid/esm/colDef/gridStringColDef.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "GRID_STRING_COL_DEF",
    ()=>GRID_STRING_COL_DEF
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$cell$2f$GridEditInputCell$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/components/cell/GridEditInputCell.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$sorting$2f$gridSortingUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/hooks/features/sorting/gridSortingUtils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$colDef$2f$gridStringOperators$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/colDef/gridStringOperators.js [app-client] (ecmascript)");
;
;
;
const GRID_STRING_COL_DEF = {
    width: 100,
    minWidth: 50,
    maxWidth: Infinity,
    hideable: true,
    sortable: true,
    resizable: true,
    filterable: true,
    groupable: true,
    pinnable: true,
    // @ts-ignore
    aggregable: true,
    chartable: true,
    editable: false,
    sortComparator: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$sorting$2f$gridSortingUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["gridStringOrNumberComparator"],
    type: 'string',
    align: 'left',
    filterOperators: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$colDef$2f$gridStringOperators$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getGridStringOperators"])(),
    renderEditCell: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$cell$2f$GridEditInputCell$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["renderEditInputCell"],
    getApplyQuickFilterFn: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$colDef$2f$gridStringOperators$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getGridStringQuickFilterFn"]
};
}),
"[project]/node_modules/@mui/x-data-grid/esm/colDef/gridNumericOperators.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getGridNumericOperators",
    ()=>getGridNumericOperators,
    "getGridNumericQuickFilterFn",
    ()=>getGridNumericQuickFilterFn
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$panel$2f$filterPanel$2f$GridFilterInputValue$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/components/panel/filterPanel/GridFilterInputValue.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$panel$2f$filterPanel$2f$GridFilterInputMultipleValue$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/components/panel/filterPanel/GridFilterInputMultipleValue.js [app-client] (ecmascript)");
;
;
const parseNumericValue = (value)=>{
    if (value == null) {
        return null;
    }
    return Number(value);
};
const getGridNumericQuickFilterFn = (value)=>{
    if (value == null || Number.isNaN(value) || value === '') {
        return null;
    }
    return (columnValue)=>{
        return parseNumericValue(columnValue) === parseNumericValue(value);
    };
};
const getGridNumericOperators = ()=>[
        {
            value: '=',
            getApplyFilterFn: (filterItem)=>{
                if (filterItem.value == null || Number.isNaN(filterItem.value)) {
                    return null;
                }
                return (value)=>{
                    return parseNumericValue(value) === filterItem.value;
                };
            },
            InputComponent: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$panel$2f$filterPanel$2f$GridFilterInputValue$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridFilterInputValue"],
            InputComponentProps: {
                type: 'number'
            }
        },
        {
            value: '!=',
            getApplyFilterFn: (filterItem)=>{
                if (filterItem.value == null || Number.isNaN(filterItem.value)) {
                    return null;
                }
                return (value)=>{
                    return parseNumericValue(value) !== filterItem.value;
                };
            },
            InputComponent: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$panel$2f$filterPanel$2f$GridFilterInputValue$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridFilterInputValue"],
            InputComponentProps: {
                type: 'number'
            }
        },
        {
            value: '>',
            getApplyFilterFn: (filterItem)=>{
                if (filterItem.value == null || Number.isNaN(filterItem.value)) {
                    return null;
                }
                return (value)=>{
                    if (value == null) {
                        return false;
                    }
                    return parseNumericValue(value) > filterItem.value;
                };
            },
            InputComponent: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$panel$2f$filterPanel$2f$GridFilterInputValue$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridFilterInputValue"],
            InputComponentProps: {
                type: 'number'
            }
        },
        {
            value: '>=',
            getApplyFilterFn: (filterItem)=>{
                if (filterItem.value == null || Number.isNaN(filterItem.value)) {
                    return null;
                }
                return (value)=>{
                    if (value == null) {
                        return false;
                    }
                    return parseNumericValue(value) >= filterItem.value;
                };
            },
            InputComponent: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$panel$2f$filterPanel$2f$GridFilterInputValue$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridFilterInputValue"],
            InputComponentProps: {
                type: 'number'
            }
        },
        {
            value: '<',
            getApplyFilterFn: (filterItem)=>{
                if (filterItem.value == null || Number.isNaN(filterItem.value)) {
                    return null;
                }
                return (value)=>{
                    if (value == null) {
                        return false;
                    }
                    return parseNumericValue(value) < filterItem.value;
                };
            },
            InputComponent: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$panel$2f$filterPanel$2f$GridFilterInputValue$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridFilterInputValue"],
            InputComponentProps: {
                type: 'number'
            }
        },
        {
            value: '<=',
            getApplyFilterFn: (filterItem)=>{
                if (filterItem.value == null || Number.isNaN(filterItem.value)) {
                    return null;
                }
                return (value)=>{
                    if (value == null) {
                        return false;
                    }
                    return parseNumericValue(value) <= filterItem.value;
                };
            },
            InputComponent: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$panel$2f$filterPanel$2f$GridFilterInputValue$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridFilterInputValue"],
            InputComponentProps: {
                type: 'number'
            }
        },
        {
            value: 'isEmpty',
            getApplyFilterFn: ()=>{
                return (value)=>{
                    return value == null;
                };
            },
            requiresFilterValue: false
        },
        {
            value: 'isNotEmpty',
            getApplyFilterFn: ()=>{
                return (value)=>{
                    return value != null;
                };
            },
            requiresFilterValue: false
        },
        {
            value: 'isAnyOf',
            getApplyFilterFn: (filterItem)=>{
                if (!Array.isArray(filterItem.value) || filterItem.value.length === 0) {
                    return null;
                }
                return (value)=>{
                    return value != null && filterItem.value.includes(Number(value));
                };
            },
            InputComponent: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$panel$2f$filterPanel$2f$GridFilterInputMultipleValue$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridFilterInputMultipleValue"],
            InputComponentProps: {
                type: 'number'
            }
        }
    ];
}),
"[project]/node_modules/@mui/x-data-grid/esm/colDef/gridNumericColDef.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "GRID_NUMERIC_COL_DEF",
    ()=>GRID_NUMERIC_COL_DEF
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$extends$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@babel/runtime/helpers/esm/extends.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$sorting$2f$gridSortingUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/hooks/features/sorting/gridSortingUtils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$utils$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/utils/utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$colDef$2f$gridNumericOperators$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/colDef/gridNumericOperators.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$colDef$2f$gridStringColDef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/colDef/gridStringColDef.js [app-client] (ecmascript)");
;
;
;
;
;
const GRID_NUMERIC_COL_DEF = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$extends$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({}, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$colDef$2f$gridStringColDef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GRID_STRING_COL_DEF"], {
    type: 'number',
    align: 'right',
    headerAlign: 'right',
    sortComparator: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$sorting$2f$gridSortingUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["gridNumberComparator"],
    valueParser: (value)=>value === '' ? null : Number(value),
    valueFormatter: (value)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$utils$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNumber"])(value) ? value.toLocaleString() : value || '',
    filterOperators: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$colDef$2f$gridNumericOperators$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getGridNumericOperators"])(),
    getApplyQuickFilterFn: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$colDef$2f$gridNumericOperators$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getGridNumericQuickFilterFn"]
});
}),
"[project]/node_modules/@mui/x-data-grid/esm/colDef/gridDateOperators.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getGridDateOperators",
    ()=>getGridDateOperators
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$panel$2f$filterPanel$2f$GridFilterInputDate$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/components/panel/filterPanel/GridFilterInputDate.js [app-client] (ecmascript)");
;
function buildApplyFilterFn(filterItem, compareFn, showTime, keepRawComparison) {
    if (!filterItem.value) {
        return null;
    }
    const date = new Date(filterItem.value);
    if (showTime) {
        date.setSeconds(0, 0);
    } else {
        // In GMT-X timezone, the date will be one day behind.
        // For 2022-08-16:
        // GMT+2: Tue Aug 16 2022 02:00:00 GMT+0200
        // GMT-4: Mon Aug 15 2022 20:00:00 GMT-0400
        //
        // We need to add the offset before resetting the hours.
        date.setMinutes(date.getMinutes() + date.getTimezoneOffset());
        date.setHours(0, 0, 0, 0);
    }
    const time = date.getTime();
    return (value)=>{
        if (!value) {
            return false;
        }
        if (keepRawComparison) {
            return compareFn(value.getTime(), time);
        }
        // Make a copy of the date to not reset the hours in the original object
        const dateCopy = new Date(value);
        if (showTime) {
            dateCopy.setSeconds(0, 0);
        } else {
            dateCopy.setHours(0, 0, 0, 0);
        }
        return compareFn(dateCopy.getTime(), time);
    };
}
const getGridDateOperators = (showTime)=>[
        {
            value: 'is',
            getApplyFilterFn: (filterItem)=>{
                return buildApplyFilterFn(filterItem, (value1, value2)=>value1 === value2, showTime);
            },
            InputComponent: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$panel$2f$filterPanel$2f$GridFilterInputDate$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridFilterInputDate"],
            InputComponentProps: {
                type: showTime ? 'datetime-local' : 'date'
            }
        },
        {
            value: 'not',
            getApplyFilterFn: (filterItem)=>{
                return buildApplyFilterFn(filterItem, (value1, value2)=>value1 !== value2, showTime);
            },
            InputComponent: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$panel$2f$filterPanel$2f$GridFilterInputDate$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridFilterInputDate"],
            InputComponentProps: {
                type: showTime ? 'datetime-local' : 'date'
            }
        },
        {
            value: 'after',
            getApplyFilterFn: (filterItem)=>{
                return buildApplyFilterFn(filterItem, (value1, value2)=>value1 > value2, showTime, showTime);
            },
            InputComponent: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$panel$2f$filterPanel$2f$GridFilterInputDate$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridFilterInputDate"],
            InputComponentProps: {
                type: showTime ? 'datetime-local' : 'date'
            }
        },
        {
            value: 'onOrAfter',
            getApplyFilterFn: (filterItem)=>{
                return buildApplyFilterFn(filterItem, (value1, value2)=>value1 >= value2, showTime, showTime);
            },
            InputComponent: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$panel$2f$filterPanel$2f$GridFilterInputDate$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridFilterInputDate"],
            InputComponentProps: {
                type: showTime ? 'datetime-local' : 'date'
            }
        },
        {
            value: 'before',
            getApplyFilterFn: (filterItem)=>{
                return buildApplyFilterFn(filterItem, (value1, value2)=>value1 < value2, showTime, true);
            },
            InputComponent: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$panel$2f$filterPanel$2f$GridFilterInputDate$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridFilterInputDate"],
            InputComponentProps: {
                type: showTime ? 'datetime-local' : 'date'
            }
        },
        {
            value: 'onOrBefore',
            getApplyFilterFn: (filterItem)=>{
                return buildApplyFilterFn(filterItem, (value1, value2)=>value1 <= value2, showTime, showTime);
            },
            InputComponent: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$panel$2f$filterPanel$2f$GridFilterInputDate$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridFilterInputDate"],
            InputComponentProps: {
                type: showTime ? 'datetime-local' : 'date'
            }
        },
        {
            value: 'isEmpty',
            getApplyFilterFn: ()=>{
                return (value)=>{
                    return value == null;
                };
            },
            requiresFilterValue: false
        },
        {
            value: 'isNotEmpty',
            getApplyFilterFn: ()=>{
                return (value)=>{
                    return value != null;
                };
            },
            requiresFilterValue: false
        }
    ];
}),
"[project]/node_modules/@mui/x-data-grid/esm/colDef/gridDateColDef.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "GRID_DATETIME_COL_DEF",
    ()=>GRID_DATETIME_COL_DEF,
    "GRID_DATE_COL_DEF",
    ()=>GRID_DATE_COL_DEF,
    "gridDateFormatter",
    ()=>gridDateFormatter,
    "gridDateTimeFormatter",
    ()=>gridDateTimeFormatter
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$extends$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@babel/runtime/helpers/esm/extends.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$sorting$2f$gridSortingUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/hooks/features/sorting/gridSortingUtils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$colDef$2f$gridDateOperators$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/colDef/gridDateOperators.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$colDef$2f$gridStringColDef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/colDef/gridStringColDef.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$cell$2f$GridEditDateCell$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/components/cell/GridEditDateCell.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$core$2f$gridPropsSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/hooks/core/gridPropsSelectors.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$rows$2f$gridRowsUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/hooks/features/rows/gridRowsUtils.js [app-client] (ecmascript)");
;
;
;
;
;
;
;
function throwIfNotDateObject({ value, columnType, rowId, field }) {
    if (!(value instanceof Date)) {
        throw new Error([
            `MUI X: \`${columnType}\` column type only accepts \`Date\` objects as values.`,
            'Use `valueGetter` to transform the value into a `Date` object.',
            `Row ID: ${rowId}, field: "${field}".`
        ].join('\n'));
    }
}
const gridDateFormatter = (value, row, column, apiRef)=>{
    if (!value) {
        return '';
    }
    const rowId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$core$2f$gridPropsSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["gridRowIdSelector"])(apiRef, row);
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$rows$2f$gridRowsUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isAutogeneratedRow"])(row) && !(value instanceof Date)) {
        return value;
    }
    throwIfNotDateObject({
        value,
        columnType: 'date',
        rowId,
        field: column.field
    });
    return value.toLocaleDateString();
};
const gridDateTimeFormatter = (value, row, column, apiRef)=>{
    if (!value) {
        return '';
    }
    const rowId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$core$2f$gridPropsSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["gridRowIdSelector"])(apiRef, row);
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$rows$2f$gridRowsUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isAutogeneratedRow"])(row) && !(value instanceof Date)) {
        return value;
    }
    throwIfNotDateObject({
        value,
        columnType: 'dateTime',
        rowId,
        field: column.field
    });
    return value.toLocaleString();
};
const GRID_DATE_COL_DEF = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$extends$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({}, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$colDef$2f$gridStringColDef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GRID_STRING_COL_DEF"], {
    type: 'date',
    sortComparator: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$sorting$2f$gridSortingUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["gridDateComparator"],
    valueFormatter: gridDateFormatter,
    filterOperators: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$colDef$2f$gridDateOperators$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getGridDateOperators"])(),
    renderEditCell: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$cell$2f$GridEditDateCell$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["renderEditDateCell"],
    // @ts-ignore
    pastedValueParser: (value)=>new Date(value)
});
const GRID_DATETIME_COL_DEF = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$extends$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({}, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$colDef$2f$gridStringColDef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GRID_STRING_COL_DEF"], {
    type: 'dateTime',
    sortComparator: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$sorting$2f$gridSortingUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["gridDateComparator"],
    valueFormatter: gridDateTimeFormatter,
    filterOperators: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$colDef$2f$gridDateOperators$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getGridDateOperators"])(true),
    renderEditCell: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$cell$2f$GridEditDateCell$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["renderEditDateCell"],
    // @ts-ignore
    pastedValueParser: (value)=>new Date(value)
});
}),
"[project]/node_modules/@mui/x-data-grid/esm/colDef/gridBooleanOperators.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getGridBooleanOperators",
    ()=>getGridBooleanOperators
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$panel$2f$filterPanel$2f$GridFilterInputBoolean$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/components/panel/filterPanel/GridFilterInputBoolean.js [app-client] (ecmascript)");
;
const getGridBooleanOperators = ()=>[
        {
            value: 'is',
            getApplyFilterFn: (filterItem)=>{
                const sanitizedValue = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$panel$2f$filterPanel$2f$GridFilterInputBoolean$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sanitizeFilterItemValue"])(filterItem.value);
                if (sanitizedValue === undefined) {
                    return null;
                }
                return (value)=>Boolean(value) === sanitizedValue;
            },
            InputComponent: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$panel$2f$filterPanel$2f$GridFilterInputBoolean$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridFilterInputBoolean"]
        }
    ];
}),
"[project]/node_modules/@mui/x-data-grid/esm/colDef/gridBooleanColDef.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "GRID_BOOLEAN_COL_DEF",
    ()=>GRID_BOOLEAN_COL_DEF
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$extends$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@babel/runtime/helpers/esm/extends.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$colDef$2f$gridStringColDef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/colDef/gridStringColDef.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$cell$2f$GridBooleanCell$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/components/cell/GridBooleanCell.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$cell$2f$GridEditBooleanCell$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/components/cell/GridEditBooleanCell.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$sorting$2f$gridSortingUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/hooks/features/sorting/gridSortingUtils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$colDef$2f$gridBooleanOperators$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/colDef/gridBooleanOperators.js [app-client] (ecmascript)");
;
;
;
;
;
;
const gridBooleanFormatter = (value, row, column, apiRef)=>{
    return value ? apiRef.current.getLocaleText('booleanCellTrueLabel') : apiRef.current.getLocaleText('booleanCellFalseLabel');
};
const stringToBoolean = (value)=>{
    switch(value.toLowerCase().trim()){
        case 'true':
        case 'yes':
        case '1':
            return true;
        case 'false':
        case 'no':
        case '0':
        case 'null':
        case 'undefined':
            return false;
        default:
            return undefined;
    }
};
const GRID_BOOLEAN_COL_DEF = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$extends$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({}, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$colDef$2f$gridStringColDef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GRID_STRING_COL_DEF"], {
    type: 'boolean',
    display: 'flex',
    align: 'center',
    headerAlign: 'center',
    renderCell: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$cell$2f$GridBooleanCell$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["renderBooleanCell"],
    renderEditCell: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$cell$2f$GridEditBooleanCell$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["renderEditBooleanCell"],
    sortComparator: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$sorting$2f$gridSortingUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["gridNumberComparator"],
    valueFormatter: gridBooleanFormatter,
    filterOperators: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$colDef$2f$gridBooleanOperators$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getGridBooleanOperators"])(),
    getApplyQuickFilterFn: ()=>null,
    // @ts-ignore
    chartable: false,
    // @ts-ignore
    pastedValueParser: (value)=>stringToBoolean(value)
});
}),
"[project]/node_modules/@mui/x-data-grid/esm/colDef/gridSingleSelectOperators.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getGridSingleSelectOperators",
    ()=>getGridSingleSelectOperators
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$panel$2f$filterPanel$2f$GridFilterInputSingleSelect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/components/panel/filterPanel/GridFilterInputSingleSelect.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$panel$2f$filterPanel$2f$GridFilterInputMultipleSingleSelect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/components/panel/filterPanel/GridFilterInputMultipleSingleSelect.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$utils$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/utils/utils.js [app-client] (ecmascript)");
;
;
;
const parseObjectValue = (value)=>{
    if (value == null || !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$utils$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isObject"])(value)) {
        return value;
    }
    return value.value;
};
const getGridSingleSelectOperators = ()=>[
        {
            value: 'is',
            getApplyFilterFn: (filterItem)=>{
                if (filterItem.value == null || filterItem.value === '') {
                    return null;
                }
                return (value)=>parseObjectValue(value) === parseObjectValue(filterItem.value);
            },
            InputComponent: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$panel$2f$filterPanel$2f$GridFilterInputSingleSelect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridFilterInputSingleSelect"]
        },
        {
            value: 'not',
            getApplyFilterFn: (filterItem)=>{
                if (filterItem.value == null || filterItem.value === '') {
                    return null;
                }
                return (value)=>parseObjectValue(value) !== parseObjectValue(filterItem.value);
            },
            InputComponent: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$panel$2f$filterPanel$2f$GridFilterInputSingleSelect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridFilterInputSingleSelect"]
        },
        {
            value: 'isAnyOf',
            getApplyFilterFn: (filterItem)=>{
                if (!Array.isArray(filterItem.value) || filterItem.value.length === 0) {
                    return null;
                }
                const filterItemValues = filterItem.value.map(parseObjectValue);
                return (value)=>filterItemValues.includes(parseObjectValue(value));
            },
            InputComponent: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$panel$2f$filterPanel$2f$GridFilterInputMultipleSingleSelect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridFilterInputMultipleSingleSelect"]
        }
    ];
}),
"[project]/node_modules/@mui/x-data-grid/esm/colDef/gridSingleSelectColDef.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "GRID_SINGLE_SELECT_COL_DEF",
    ()=>GRID_SINGLE_SELECT_COL_DEF
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$extends$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@babel/runtime/helpers/esm/extends.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$colDef$2f$gridStringColDef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/colDef/gridStringColDef.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$cell$2f$GridEditSingleSelectCell$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/components/cell/GridEditSingleSelectCell.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$colDef$2f$gridSingleSelectOperators$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/colDef/gridSingleSelectOperators.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$panel$2f$filterPanel$2f$filterPanelUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/components/panel/filterPanel/filterPanelUtils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$utils$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/utils/utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$core$2f$gridPropsSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/hooks/core/gridPropsSelectors.js [app-client] (ecmascript)");
;
;
;
;
;
;
;
const isArrayOfObjects = (options)=>{
    return typeof options[0] === 'object';
};
const defaultGetOptionValue = (value)=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$utils$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isObject"])(value) ? value.value : value;
};
const defaultGetOptionLabel = (value)=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$utils$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isObject"])(value) ? value.label : String(value);
};
const GRID_SINGLE_SELECT_COL_DEF = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$extends$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({}, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$colDef$2f$gridStringColDef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GRID_STRING_COL_DEF"], {
    type: 'singleSelect',
    getOptionLabel: defaultGetOptionLabel,
    getOptionValue: defaultGetOptionValue,
    valueFormatter (value, row, colDef, apiRef) {
        const rowId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$core$2f$gridPropsSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["gridRowIdSelector"])(apiRef, row);
        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$panel$2f$filterPanel$2f$filterPanelUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSingleSelectColDef"])(colDef)) {
            return '';
        }
        const valueOptions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$panel$2f$filterPanel$2f$filterPanelUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getValueOptions"])(colDef, {
            id: rowId,
            row
        });
        if (value == null) {
            return '';
        }
        if (!valueOptions) {
            return value;
        }
        if (!isArrayOfObjects(valueOptions)) {
            return colDef.getOptionLabel(value);
        }
        const valueOption = valueOptions.find((option)=>colDef.getOptionValue(option) === value);
        return valueOption ? colDef.getOptionLabel(valueOption) : '';
    },
    renderEditCell: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$cell$2f$GridEditSingleSelectCell$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["renderEditSingleSelectCell"],
    filterOperators: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$colDef$2f$gridSingleSelectOperators$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getGridSingleSelectOperators"])(),
    // @ts-ignore
    pastedValueParser: (value, row, column)=>{
        const colDef = column;
        const valueOptions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$panel$2f$filterPanel$2f$filterPanelUtils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getValueOptions"])(colDef) || [];
        const getOptionValue = colDef.getOptionValue;
        const valueOption = valueOptions.find((option)=>{
            if (getOptionValue(option) === value) {
                return true;
            }
            return false;
        });
        if (valueOption) {
            return value;
        }
        // do not paste the value if it is not in the valueOptions
        return undefined;
    }
});
}),
"[project]/node_modules/@mui/x-data-grid/esm/colDef/gridActionsColDef.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "GRID_ACTIONS_COLUMN_TYPE",
    ()=>GRID_ACTIONS_COLUMN_TYPE,
    "GRID_ACTIONS_COL_DEF",
    ()=>GRID_ACTIONS_COL_DEF
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$extends$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@babel/runtime/helpers/esm/extends.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$colDef$2f$gridStringColDef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/colDef/gridStringColDef.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$cell$2f$GridActionsCell$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/components/cell/GridActionsCell.js [app-client] (ecmascript)");
;
;
;
const GRID_ACTIONS_COLUMN_TYPE = 'actions';
const GRID_ACTIONS_COL_DEF = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$extends$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({}, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$colDef$2f$gridStringColDef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GRID_STRING_COL_DEF"], {
    sortable: false,
    filterable: false,
    // @ts-ignore
    aggregable: false,
    chartable: false,
    width: 100,
    display: 'flex',
    align: 'center',
    headerAlign: 'center',
    headerName: '',
    disableColumnMenu: true,
    disableExport: true,
    renderCell: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$cell$2f$GridActionsCell$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["renderActionsCell"],
    getApplyQuickFilterFn: ()=>null
});
}),
"[project]/node_modules/@mui/x-data-grid/esm/colDef/gridLongTextColDef.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "GRID_LONG_TEXT_COL_DEF",
    ()=>GRID_LONG_TEXT_COL_DEF
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$extends$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@babel/runtime/helpers/esm/extends.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$colDef$2f$gridStringColDef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/colDef/gridStringColDef.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$cell$2f$GridLongTextCell$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/components/cell/GridLongTextCell.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$cell$2f$GridEditLongTextCell$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/components/cell/GridEditLongTextCell.js [app-client] (ecmascript)");
;
;
;
;
const GRID_LONG_TEXT_COL_DEF = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$extends$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({}, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$colDef$2f$gridStringColDef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GRID_STRING_COL_DEF"], {
    type: 'longText',
    display: 'flex',
    renderCell: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$cell$2f$GridLongTextCell$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["renderLongTextCell"],
    renderEditCell: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$cell$2f$GridEditLongTextCell$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["renderEditLongTextCell"]
});
}),
"[project]/node_modules/@mui/x-data-grid/esm/colDef/gridDefaultColumnTypes.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DEFAULT_GRID_COL_TYPE_KEY",
    ()=>DEFAULT_GRID_COL_TYPE_KEY,
    "getGridDefaultColumnTypes",
    ()=>getGridDefaultColumnTypes
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$colDef$2f$gridStringColDef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/colDef/gridStringColDef.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$colDef$2f$gridNumericColDef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/colDef/gridNumericColDef.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$colDef$2f$gridDateColDef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/colDef/gridDateColDef.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$colDef$2f$gridBooleanColDef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/colDef/gridBooleanColDef.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$colDef$2f$gridSingleSelectColDef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/colDef/gridSingleSelectColDef.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$colDef$2f$gridActionsColDef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/colDef/gridActionsColDef.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$colDef$2f$gridLongTextColDef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/colDef/gridLongTextColDef.js [app-client] (ecmascript)");
;
;
;
;
;
;
;
const DEFAULT_GRID_COL_TYPE_KEY = 'string';
const getGridDefaultColumnTypes = ()=>{
    const nativeColumnTypes = {
        string: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$colDef$2f$gridStringColDef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GRID_STRING_COL_DEF"],
        number: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$colDef$2f$gridNumericColDef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GRID_NUMERIC_COL_DEF"],
        date: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$colDef$2f$gridDateColDef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GRID_DATE_COL_DEF"],
        dateTime: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$colDef$2f$gridDateColDef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GRID_DATETIME_COL_DEF"],
        boolean: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$colDef$2f$gridBooleanColDef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GRID_BOOLEAN_COL_DEF"],
        singleSelect: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$colDef$2f$gridSingleSelectColDef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GRID_SINGLE_SELECT_COL_DEF"],
        [__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$colDef$2f$gridActionsColDef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GRID_ACTIONS_COLUMN_TYPE"]]: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$colDef$2f$gridActionsColDef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GRID_ACTIONS_COL_DEF"],
        custom: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$colDef$2f$gridStringColDef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GRID_STRING_COL_DEF"],
        longText: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$colDef$2f$gridLongTextColDef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GRID_LONG_TEXT_COL_DEF"]
    };
    return nativeColumnTypes;
};
}),
"[project]/node_modules/@mui/x-data-grid/esm/colDef/gridCheckboxSelectionColDef.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "GRID_CHECKBOX_SELECTION_COL_DEF",
    ()=>GRID_CHECKBOX_SELECTION_COL_DEF,
    "GRID_CHECKBOX_SELECTION_FIELD",
    ()=>GRID_CHECKBOX_SELECTION_FIELD
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$extends$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@babel/runtime/helpers/esm/extends.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$columnSelection$2f$GridCellCheckboxRenderer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/components/columnSelection/GridCellCheckboxRenderer.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$columnSelection$2f$GridHeaderCheckbox$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/components/columnSelection/GridHeaderCheckbox.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$colDef$2f$gridBooleanColDef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/colDef/gridBooleanColDef.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$core$2f$gridPropsSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/hooks/core/gridPropsSelectors.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
;
;
;
;
;
;
const GRID_CHECKBOX_SELECTION_FIELD = '__check__';
const GRID_CHECKBOX_SELECTION_COL_DEF = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$extends$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({}, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$colDef$2f$gridBooleanColDef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GRID_BOOLEAN_COL_DEF"], {
    type: 'custom',
    field: GRID_CHECKBOX_SELECTION_FIELD,
    width: 50,
    resizable: false,
    sortable: false,
    filterable: false,
    // @ts-ignore
    aggregable: false,
    chartable: false,
    disableColumnMenu: true,
    disableReorder: true,
    disableExport: true,
    getApplyQuickFilterFn: ()=>null,
    display: 'flex',
    valueGetter: (value, row, column, apiRef)=>{
        const rowId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$core$2f$gridPropsSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["gridRowIdSelector"])(apiRef, row);
        return apiRef.current.isRowSelected(rowId);
    },
    rowSpanValueGetter: (_, row, column, apiRef)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$core$2f$gridPropsSelectors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["gridRowIdSelector"])(apiRef, row),
    renderHeader: (params)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$columnSelection$2f$GridHeaderCheckbox$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridHeaderCheckbox"], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$extends$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({}, params)),
    renderCell: (params)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$columnSelection$2f$GridCellCheckboxRenderer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridCellCheckboxRenderer"], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$extends$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({}, params))
});
}),
"[project]/node_modules/@mui/x-data-grid/esm/internals/constants.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "GRID_DETAIL_PANEL_TOGGLE_FIELD",
    ()=>GRID_DETAIL_PANEL_TOGGLE_FIELD,
    "GRID_ROW_GROUPING_SINGLE_GROUPING_FIELD",
    ()=>GRID_ROW_GROUPING_SINGLE_GROUPING_FIELD,
    "GRID_TREE_DATA_GROUPING_FIELD",
    ()=>GRID_TREE_DATA_GROUPING_FIELD,
    "PinnedColumnPosition",
    ()=>PinnedColumnPosition
]);
const GRID_TREE_DATA_GROUPING_FIELD = '__tree_data_group__';
const GRID_ROW_GROUPING_SINGLE_GROUPING_FIELD = '__row_group_by_columns_group__';
const GRID_DETAIL_PANEL_TOGGLE_FIELD = '__detail_panel_toggle__';
let PinnedColumnPosition = /*#__PURE__*/ function(PinnedColumnPosition) {
    PinnedColumnPosition[PinnedColumnPosition["NONE"] = 0] = "NONE";
    PinnedColumnPosition[PinnedColumnPosition["LEFT"] = 1] = "LEFT";
    PinnedColumnPosition[PinnedColumnPosition["RIGHT"] = 2] = "RIGHT";
    PinnedColumnPosition[PinnedColumnPosition["VIRTUAL"] = 3] = "VIRTUAL";
    return PinnedColumnPosition;
}({});
}),
"[project]/node_modules/@mui/x-data-grid/esm/internals/utils/gridRowGroupingUtils.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getRowGroupingCriteriaFromGroupingField",
    ()=>getRowGroupingCriteriaFromGroupingField,
    "isGroupingColumn",
    ()=>isGroupingColumn
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$internals$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/internals/constants.js [app-client] (ecmascript)");
;
const getRowGroupingCriteriaFromGroupingField = (groupingColDefField)=>{
    const match = groupingColDefField.match(/^__row_group_by_columns_group_(.*)__$/);
    if (!match) {
        return null;
    }
    return match[1];
};
const isGroupingColumn = (field)=>field === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$internals$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GRID_ROW_GROUPING_SINGLE_GROUPING_FIELD"] || getRowGroupingCriteriaFromGroupingField(field) !== null;
}),
"[project]/node_modules/@mui/x-data-grid/esm/internals/utils/getPinnedCellOffset.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getPinnedCellOffset",
    ()=>getPinnedCellOffset
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$internals$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/internals/constants.js [app-client] (ecmascript)");
;
const getPinnedCellOffset = (pinnedPosition, computedWidth, columnIndex, columnPositions, columnsTotalWidth, scrollbarWidth)=>{
    let pinnedOffset;
    switch(pinnedPosition){
        case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$internals$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PinnedColumnPosition"].LEFT:
            pinnedOffset = columnPositions[columnIndex];
            break;
        case __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$internals$2f$constants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PinnedColumnPosition"].RIGHT:
            pinnedOffset = columnsTotalWidth - columnPositions[columnIndex] - computedWidth + scrollbarWidth;
            break;
        default:
            pinnedOffset = undefined;
            break;
    }
    // XXX: fix this properly
    if (Number.isNaN(pinnedOffset)) {
        pinnedOffset = undefined;
    }
    return pinnedOffset;
};
}),
"[project]/node_modules/@mui/x-data-grid/esm/internals/utils/attachPinnedStyle.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "attachPinnedStyle",
    ()=>attachPinnedStyle
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$utils$2f$rtlFlipSide$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/utils/rtlFlipSide.js [app-client] (ecmascript)");
;
function attachPinnedStyle(style, isRtl, pinnedPosition, pinnedOffset) {
    const side = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$utils$2f$rtlFlipSide$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rtlFlipSide"])(pinnedPosition, isRtl);
    if (!side || pinnedOffset === undefined) {
        return style;
    }
    style[side] = pinnedOffset;
    return style;
}
}),
"[project]/node_modules/@mui/x-data-grid/esm/internals/utils/computeSlots.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "computeSlots",
    ()=>computeSlots
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$extends$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@babel/runtime/helpers/esm/extends.js [app-client] (ecmascript)");
;
function computeSlots({ defaultSlots, slots }) {
    const overrides = slots;
    if (!overrides || Object.keys(overrides).length === 0) {
        return defaultSlots;
    }
    const result = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$extends$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({}, defaultSlots);
    Object.keys(overrides).forEach((key)=>{
        const k = key;
        if (overrides[k] !== undefined) {
            result[k] = overrides[k];
        }
    });
    return result;
}
}),
"[project]/node_modules/@mui/x-data-grid/esm/internals/utils/propValidation.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "propValidatorsDataGrid",
    ()=>propValidatorsDataGrid,
    "validateProps",
    ()=>validateProps
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$internals$2f$esm$2f$warning$2f$warning$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-internals/esm/warning/warning.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$utils$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/utils/utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$constants$2f$signature$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/constants/signature.js [app-client] (ecmascript)");
;
;
;
const propValidatorsDataGrid = [
    (props)=>props.autoPageSize && props.autoHeight && [
            'MUI X: `<DataGrid autoPageSize={true} autoHeight={true} />` are not valid props.',
            'You cannot use both the `autoPageSize` and `autoHeight` props at the same time because `autoHeight` scales the height of the Data Grid according to the `pageSize`.',
            '',
            'Please remove one of these two props.'
        ].join('\n') || undefined,
    (props)=>props.paginationMode === 'client' && props.paginationMeta != null && [
            'MUI X: Usage of the `paginationMeta` prop with client-side pagination (`paginationMode="client"`) has no effect.',
            '`paginationMeta` is only meant to be used with `paginationMode="server"`.'
        ].join('\n') || undefined,
    (props)=>props.signature === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$constants$2f$signature$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridSignature"].DataGrid && props.paginationMode === 'client' && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$utils$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNumber"])(props.rowCount) && [
            'MUI X: Usage of the `rowCount` prop with client side pagination (`paginationMode="client"`) has no effect.',
            '`rowCount` is only meant to be used with `paginationMode="server"`.'
        ].join('\n') || undefined,
    (props)=>props.paginationMode === 'server' && props.rowCount == null && !props.dataSource && [
            "MUI X: The `rowCount` prop must be passed using `paginationMode='server'`",
            'For more detail, see http://mui.com/components/data-grid/pagination/#index-based-pagination'
        ].join('\n') || undefined
];
function validateProps(props, validators) {
    validators.forEach((validator)=>{
        const message = validator(props);
        if (message) {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$internals$2f$esm$2f$warning$2f$warning$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["warnOnce"])(message, 'error');
        }
    });
}
}),
"[project]/node_modules/@mui/x-data-grid/esm/DataGrid/useDataGridComponent.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useDataGridComponent",
    ()=>useDataGridComponent
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$internals$2f$esm$2f$useFirstRender$2f$useFirstRender$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-internals/esm/useFirstRender/useFirstRender.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$core$2f$useGridInitialization$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/hooks/core/useGridInitialization.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$utils$2f$useGridInitializeState$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/hooks/utils/useGridInitializeState.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$clipboard$2f$useGridClipboard$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/hooks/features/clipboard/useGridClipboard.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$columnMenu$2f$useGridColumnMenu$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/hooks/features/columnMenu/useGridColumnMenu.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$columns$2f$useGridColumns$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/hooks/features/columns/useGridColumns.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$density$2f$useGridDensity$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/hooks/features/density/useGridDensity.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$export$2f$useGridCsvExport$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/hooks/features/export/useGridCsvExport.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$export$2f$useGridPrintExport$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/hooks/features/export/useGridPrintExport.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$filter$2f$useGridFilter$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/hooks/features/filter/useGridFilter.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$focus$2f$useGridFocus$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/hooks/features/focus/useGridFocus.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$keyboardNavigation$2f$useGridKeyboardNavigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/hooks/features/keyboardNavigation/useGridKeyboardNavigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$pagination$2f$useGridPagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/hooks/features/pagination/useGridPagination.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$preferencesPanel$2f$useGridPreferencesPanel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/hooks/features/preferencesPanel/useGridPreferencesPanel.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$editing$2f$useGridEditing$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/hooks/features/editing/useGridEditing.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$rows$2f$useGridRows$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/hooks/features/rows/useGridRows.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$rows$2f$useGridRowsPreProcessors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/hooks/features/rows/useGridRowsPreProcessors.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$rows$2f$useGridParamsApi$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/hooks/features/rows/useGridParamsApi.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$rowSelection$2f$useGridRowSelection$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/hooks/features/rowSelection/useGridRowSelection.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$rowSelection$2f$useGridRowSelectionPreProcessors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/hooks/features/rowSelection/useGridRowSelectionPreProcessors.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$sorting$2f$useGridSorting$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/hooks/features/sorting/useGridSorting.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$scroll$2f$useGridScroll$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/hooks/features/scroll/useGridScroll.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$events$2f$useGridEvents$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/hooks/features/events/useGridEvents.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$dimensions$2f$useGridDimensions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/hooks/features/dimensions/useGridDimensions.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$rows$2f$useGridRowsMeta$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/hooks/features/rows/useGridRowsMeta.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$statePersistence$2f$useGridStatePersistence$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/hooks/features/statePersistence/useGridStatePersistence.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$columns$2f$useGridColumnSpanning$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/hooks/features/columns/useGridColumnSpanning.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$columnGrouping$2f$useGridColumnGrouping$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/hooks/features/columnGrouping/useGridColumnGrouping.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$virtualization$2f$useGridVirtualization$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/hooks/features/virtualization/useGridVirtualization.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$columnResize$2f$useGridColumnResize$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/hooks/features/columnResize/useGridColumnResize.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$rows$2f$useGridRowSpanning$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/hooks/features/rows/useGridRowSpanning.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$listView$2f$useGridListView$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/hooks/features/listView/useGridListView.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$core$2f$useGridProps$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/hooks/core/useGridProps.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$dataSource$2f$useGridDataSource$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/hooks/features/dataSource/useGridDataSource.js [app-client] (ecmascript)");
'use client';
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const useDataGridComponent = (apiRef, props, configuration)=>{
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$core$2f$useGridInitialization$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGridInitialization"])(apiRef, props);
    /**
   * Register all pre-processors called during state initialization here.
   */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$rowSelection$2f$useGridRowSelectionPreProcessors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGridRowSelectionPreProcessors"])(apiRef, props);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$rows$2f$useGridRowsPreProcessors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGridRowsPreProcessors"])(apiRef);
    /**
   * Register all state initializers here.
   */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$utils$2f$useGridInitializeState$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGridInitializeState"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$core$2f$useGridProps$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["propsStateInitializer"], apiRef, props);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$utils$2f$useGridInitializeState$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGridInitializeState"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$rowSelection$2f$useGridRowSelection$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rowSelectionStateInitializer"], apiRef, props);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$utils$2f$useGridInitializeState$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGridInitializeState"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$columns$2f$useGridColumns$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["columnsStateInitializer"], apiRef, props);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$utils$2f$useGridInitializeState$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGridInitializeState"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$rows$2f$useGridRows$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rowsStateInitializer"], apiRef, props);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$utils$2f$useGridInitializeState$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGridInitializeState"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$pagination$2f$useGridPagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["paginationStateInitializer"], apiRef, props);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$utils$2f$useGridInitializeState$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGridInitializeState"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$editing$2f$useGridEditing$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["editingStateInitializer"], apiRef, props);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$utils$2f$useGridInitializeState$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGridInitializeState"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$focus$2f$useGridFocus$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["focusStateInitializer"], apiRef, props);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$utils$2f$useGridInitializeState$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGridInitializeState"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$sorting$2f$useGridSorting$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sortingStateInitializer"], apiRef, props);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$utils$2f$useGridInitializeState$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGridInitializeState"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$preferencesPanel$2f$useGridPreferencesPanel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["preferencePanelStateInitializer"], apiRef, props);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$utils$2f$useGridInitializeState$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGridInitializeState"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$filter$2f$useGridFilter$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["filterStateInitializer"], apiRef, props);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$utils$2f$useGridInitializeState$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGridInitializeState"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$rows$2f$useGridRowSpanning$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rowSpanningStateInitializer"], apiRef, props);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$utils$2f$useGridInitializeState$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGridInitializeState"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$density$2f$useGridDensity$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["densityStateInitializer"], apiRef, props);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$utils$2f$useGridInitializeState$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGridInitializeState"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$columnResize$2f$useGridColumnResize$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["columnResizeStateInitializer"], apiRef, props);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$utils$2f$useGridInitializeState$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGridInitializeState"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$columnMenu$2f$useGridColumnMenu$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["columnMenuStateInitializer"], apiRef, props);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$utils$2f$useGridInitializeState$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGridInitializeState"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$columnGrouping$2f$useGridColumnGrouping$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["columnGroupsStateInitializer"], apiRef, props);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$utils$2f$useGridInitializeState$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGridInitializeState"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$virtualization$2f$useGridVirtualization$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["virtualizationStateInitializer"], apiRef, props);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$utils$2f$useGridInitializeState$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGridInitializeState"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$dimensions$2f$useGridDimensions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dimensionsStateInitializer"], apiRef, props);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$utils$2f$useGridInitializeState$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGridInitializeState"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$rows$2f$useGridRowsMeta$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rowsMetaStateInitializer"], apiRef, props);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$utils$2f$useGridInitializeState$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGridInitializeState"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$listView$2f$useGridListView$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["listViewStateInitializer"], apiRef, props);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$keyboardNavigation$2f$useGridKeyboardNavigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGridKeyboardNavigation"])(apiRef, props);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$rowSelection$2f$useGridRowSelection$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGridRowSelection"])(apiRef, props);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$columns$2f$useGridColumns$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGridColumns"])(apiRef, props);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$rows$2f$useGridRows$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGridRows"])(apiRef, props, configuration);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$rows$2f$useGridRowSpanning$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGridRowSpanning"])(apiRef, props);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$rows$2f$useGridParamsApi$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGridParamsApi"])(apiRef, props, configuration);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$columns$2f$useGridColumnSpanning$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGridColumnSpanning"])(apiRef);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$columnGrouping$2f$useGridColumnGrouping$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGridColumnGrouping"])(apiRef, props);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$editing$2f$useGridEditing$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGridEditing"])(apiRef, props, configuration);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$focus$2f$useGridFocus$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGridFocus"])(apiRef, props);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$preferencesPanel$2f$useGridPreferencesPanel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGridPreferencesPanel"])(apiRef, props);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$filter$2f$useGridFilter$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGridFilter"])(apiRef, props, configuration);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$sorting$2f$useGridSorting$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGridSorting"])(apiRef, props);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$density$2f$useGridDensity$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGridDensity"])(apiRef, props);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$columnResize$2f$useGridColumnResize$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGridColumnResize"])(apiRef, props);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$pagination$2f$useGridPagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGridPagination"])(apiRef, props);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$scroll$2f$useGridScroll$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGridScroll"])(apiRef, props);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$columnMenu$2f$useGridColumnMenu$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGridColumnMenu"])(apiRef);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$export$2f$useGridCsvExport$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGridCsvExport"])(apiRef, props);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$export$2f$useGridPrintExport$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGridPrintExport"])(apiRef, props);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$clipboard$2f$useGridClipboard$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGridClipboard"])(apiRef, props);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$dimensions$2f$useGridDimensions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGridDimensions"])(apiRef, props);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$events$2f$useGridEvents$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGridEvents"])(apiRef, props);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$statePersistence$2f$useGridStatePersistence$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGridStatePersistence"])(apiRef);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$virtualization$2f$useGridVirtualization$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGridVirtualization"])(apiRef, props);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$listView$2f$useGridListView$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGridListView"])(apiRef, props);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$dataSource$2f$useGridDataSource$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGridDataSource"])(apiRef, props);
    // Should be the last thing to run, because all pre-processors should have been registered by now.
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$internals$2f$esm$2f$useFirstRender$2f$useFirstRender$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFirstRender"])({
        "useDataGridComponent.useFirstRender": ()=>{
            apiRef.current.runAppliersForPendingProcessors();
        }
    }["useDataGridComponent.useFirstRender"]);
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "useDataGridComponent.useEffect": ()=>{
            apiRef.current.runAppliersForPendingProcessors();
        }
    }["useDataGridComponent.useEffect"]);
};
}),
"[project]/node_modules/@mui/x-data-grid/esm/DataGrid/useDataGridProps.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useDataGridProps",
    ()=>useDataGridProps
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$extends$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@babel/runtime/helpers/esm/extends.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$useTheme$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__useTheme$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/styles/useTheme.js [app-client] (ecmascript) <export default as useTheme>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$useThemeProps$2f$getThemeProps$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__getThemeProps$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/system/esm/useThemeProps/getThemeProps.js [app-client] (ecmascript) <export default as getThemeProps>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$constants$2f$localeTextConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/constants/localeTextConstants.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$constants$2f$defaultGridSlotsComponents$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/constants/defaultGridSlotsComponents.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$internals$2f$utils$2f$computeSlots$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/internals/utils/computeSlots.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$constants$2f$dataGridPropsDefaultValues$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/constants/dataGridPropsDefaultValues.js [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
const DATA_GRID_FORCED_PROPS = {
    disableMultipleColumnsFiltering: true,
    disableMultipleColumnsSorting: true,
    throttleRowsMs: undefined,
    hideFooterRowCount: false,
    pagination: true,
    checkboxSelectionVisibleOnly: false,
    disableColumnReorder: true,
    keepColumnPositionIfDraggedOutside: false,
    signature: 'DataGrid',
    listView: false
};
const getDataGridForcedProps = (themedProps)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$extends$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({}, DATA_GRID_FORCED_PROPS, themedProps.dataSource ? {
        filterMode: 'server',
        sortingMode: 'server',
        paginationMode: 'server'
    } : {});
const defaultSlots = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$constants$2f$defaultGridSlotsComponents$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DATA_GRID_DEFAULT_SLOTS_COMPONENTS"];
const useDataGridProps = (inProps)=>{
    const theme = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$useTheme$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__useTheme$3e$__["useTheme"])();
    const themedProps = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "useDataGridProps.useMemo[themedProps]": ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$useThemeProps$2f$getThemeProps$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__getThemeProps$3e$__["getThemeProps"])({
                props: inProps,
                theme,
                name: 'MuiDataGrid'
            })
    }["useDataGridProps.useMemo[themedProps]"], [
        theme,
        inProps
    ]);
    const localeText = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "useDataGridProps.useMemo[localeText]": ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$extends$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({}, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$constants$2f$localeTextConstants$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GRID_DEFAULT_LOCALE_TEXT"], themedProps.localeText)
    }["useDataGridProps.useMemo[localeText]"], [
        themedProps.localeText
    ]);
    const slots = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "useDataGridProps.useMemo[slots]": ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$internals$2f$utils$2f$computeSlots$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["computeSlots"])({
                defaultSlots,
                slots: themedProps.slots
            })
    }["useDataGridProps.useMemo[slots]"], [
        themedProps.slots
    ]);
    const injectDefaultProps = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "useDataGridProps.useMemo[injectDefaultProps]": ()=>{
            return Object.keys(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$constants$2f$dataGridPropsDefaultValues$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DATA_GRID_PROPS_DEFAULT_VALUES"]).reduce({
                "useDataGridProps.useMemo[injectDefaultProps]": (acc, key)=>{
                    // @ts-ignore
                    acc[key] = themedProps[key] ?? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$constants$2f$dataGridPropsDefaultValues$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DATA_GRID_PROPS_DEFAULT_VALUES"][key];
                    return acc;
                }
            }["useDataGridProps.useMemo[injectDefaultProps]"], {});
        }
    }["useDataGridProps.useMemo[injectDefaultProps]"], [
        themedProps
    ]);
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "useDataGridProps.useMemo": ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$extends$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({}, themedProps, injectDefaultProps, {
                localeText,
                slots
            }, getDataGridForcedProps(themedProps))
    }["useDataGridProps.useMemo"], [
        themedProps,
        localeText,
        slots,
        injectDefaultProps
    ]);
};
}),
"[project]/node_modules/@mui/x-data-grid/esm/DataGrid/DataGrid.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DataGrid",
    ()=>DataGrid
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$extends$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@babel/runtime/helpers/esm/extends.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/prop-types/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$internals$2f$esm$2f$forwardRef$2f$forwardRef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-internals/esm/forwardRef/forwardRef.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$containers$2f$GridRoot$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/components/containers/GridRoot.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$utils$2f$useGridAriaAttributes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/hooks/utils/useGridAriaAttributes.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$rows$2f$useGridRowAriaAttributes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/hooks/features/rows/useGridRowAriaAttributes.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$rows$2f$useGridRowsOverridableMethods$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/hooks/features/rows/useGridRowsOverridableMethods.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$rows$2f$useGridParamsOverridableMethods$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/hooks/features/rows/useGridParamsOverridableMethods.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$editing$2f$useGridCellEditable$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/hooks/features/editing/useGridCellEditable.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$context$2f$GridContextProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/context/GridContextProvider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$DataGrid$2f$useDataGridComponent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/DataGrid/useDataGridComponent.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$DataGrid$2f$useDataGridProps$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/DataGrid/useDataGridProps.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$internals$2f$utils$2f$propValidation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/internals/utils/propValidation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$material$2f$variables$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/material/variables.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$core$2f$useGridApiInitialization$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/hooks/core/useGridApiInitialization.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
'use client';
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const configuration = {
    hooks: {
        useCSSVariables: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$material$2f$variables$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMaterialCSSVariables"],
        useGridAriaAttributes: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$utils$2f$useGridAriaAttributes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGridAriaAttributes"],
        useGridRowAriaAttributes: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$rows$2f$useGridRowAriaAttributes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGridRowAriaAttributes"],
        useGridRowsOverridableMethods: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$rows$2f$useGridRowsOverridableMethods$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGridRowsOverridableMethods"],
        useGridParamsOverridableMethods: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$rows$2f$useGridParamsOverridableMethods$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGridParamsOverridableMethods"],
        useIsCellEditable: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$features$2f$editing$2f$useGridCellEditable$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsCellEditable"],
        useCellAggregationResult: ()=>null,
        useFilterValueGetter: (apiRef)=>apiRef.current.getRowValue
    }
};
const DataGridRaw = function DataGrid(inProps, ref) {
    const props = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$DataGrid$2f$useDataGridProps$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDataGridProps"])(inProps);
    const privateApiRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$core$2f$useGridApiInitialization$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGridApiInitialization"])(props.apiRef, props);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$DataGrid$2f$useDataGridComponent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDataGridComponent"])(privateApiRef, props, configuration);
    if ("TURBOPACK compile-time truthy", 1) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$internals$2f$utils$2f$propValidation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["validateProps"])(props, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$internals$2f$utils$2f$propValidation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["propValidatorsDataGrid"]);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$context$2f$GridContextProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridContextProvider"], {
        privateApiRef: privateApiRef,
        configuration: configuration,
        props: props,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$containers$2f$GridRoot$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridRoot"], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$extends$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({
            className: props.className,
            style: props.style,
            sx: props.sx
        }, props.slotProps?.root, {
            ref: ref
        }))
    });
};
if ("TURBOPACK compile-time truthy", 1) DataGridRaw.displayName = "DataGridRaw";
const DataGrid = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["memo"]((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$internals$2f$esm$2f$forwardRef$2f$forwardRef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(DataGridRaw));
if ("TURBOPACK compile-time truthy", 1) DataGrid.displayName = "DataGrid";
DataGridRaw.propTypes = {
    // ----------------------------- Warning --------------------------------
    // | These PropTypes are generated from the TypeScript type definitions |
    // | To update them edit the TypeScript types and run "pnpm proptypes"  |
    // ----------------------------------------------------------------------
    /**
   * The ref object that allows Data Grid manipulation. Can be instantiated with `useGridApiRef()`.
   */ apiRef: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].shape({
        current: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object
    }),
    /**
   * The `aria-label` of the Data Grid.
   */ 'aria-label': __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    /**
   * The `id` of the element containing a label for the Data Grid.
   */ 'aria-labelledby': __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    /**
   * If `true`, the Data Grid height is dynamic and follows the number of rows in the Data Grid.
   * @default false
   * @deprecated Use flex parent container instead: https://mui.com/x/react-data-grid/layout/#flex-parent-container
   * @example
   * <div style={{ display: 'flex', flexDirection: 'column' }}>
   *   <DataGrid />
   * </div>
   */ autoHeight: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * If `true`, the pageSize is calculated according to the container size and the max number of rows to avoid rendering a vertical scroll bar.
   * @default false
   */ autoPageSize: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * If `true`, columns are autosized after the datagrid is mounted.
   * @default false
   */ autosizeOnMount: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * The options for autosize when user-initiated.
   */ autosizeOptions: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].shape({
        columns: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].arrayOf(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string),
        disableColumnVirtualization: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
        expand: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
        includeHeaders: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
        includeOutliers: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
        outliersFactor: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number
    }),
    /**
   * Controls the modes of the cells.
   */ cellModesModel: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object,
    /**
   * If `true`, the Data Grid will display an extra column with checkboxes for selecting rows.
   * @default false
   */ checkboxSelection: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * Override or extend the styles applied to the component.
   */ classes: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object,
    className: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    /**
   * The character used to separate cell values when copying to the clipboard.
   * @default '\t'
   */ clipboardCopyCellDelimiter: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    /**
   * Column region in pixels to render before/after the viewport
   * @default 150
   */ columnBufferPx: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number,
    /**
   * The milliseconds delay to wait after a keystroke before triggering filtering in the columns menu.
   * @default 150
   */ columnFilterDebounceMs: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number,
    /**
   * Sets the height in pixels of the column group headers in the Data Grid.
   * Inherits the `columnHeaderHeight` value if not set.
   */ columnGroupHeaderHeight: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number,
    columnGroupingModel: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].arrayOf(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object),
    /**
   * Sets the height in pixel of the column headers in the Data Grid.
   * @default 56
   */ columnHeaderHeight: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number,
    /**
   * Set of columns of type [[GridColDef]][].
   */ columns: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].arrayOf(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object).isRequired,
    /**
   * Set the column visibility model of the Data Grid.
   * If defined, the Data Grid will ignore the `hide` property in [[GridColDef]].
   */ columnVisibilityModel: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object,
    /**
   * The data source object.
   */ dataSource: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].shape({
        getRows: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func.isRequired,
        updateRow: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func
    }),
    /**
   * Data source cache object.
   */ dataSourceCache: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].shape({
        clear: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func.isRequired,
        get: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func.isRequired,
        set: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func.isRequired
    }),
    /**
   * If positive, the Data Grid will periodically revalidate data source rows by
   * re-fetching them from the server when the cache entry has expired.
   * Set to `0` to disable polling.
   * @default 0
   */ dataSourceRevalidateMs: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number,
    /**
   * Set the density of the Data Grid.
   * @default "standard"
   */ density: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOf([
        'comfortable',
        'compact',
        'standard'
    ]),
    /**
   * If `true`, column autosizing on header separator double-click is disabled.
   * @default false
   */ disableAutosize: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * If `true`, column filters are disabled.
   * @default false
   */ disableColumnFilter: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * If `true`, the column menu is disabled.
   * @default false
   */ disableColumnMenu: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * If `true`, resizing columns is disabled.
   * @default false
   */ disableColumnResize: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * If `true`, hiding/showing columns is disabled.
   * @default false
   */ disableColumnSelector: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * If `true`, the column sorting feature will be disabled.
   * @default false
   */ disableColumnSorting: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * If `true`, the density selector is disabled.
   * @default false
   */ disableDensitySelector: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * If `true`, `eval()` is not used for performance optimization.
   * @default false
   */ disableEval: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * If `true`, multiple selection using the Ctrl/CMD or Shift key is disabled.
   * The MIT DataGrid will ignore this prop, unless `checkboxSelection` is enabled.
   * @default false (`!props.checkboxSelection` for MIT Data Grid)
   */ disableMultipleRowSelection: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * If `true`, the Data Grid will not use the exclude model optimization when selecting all rows.
   * @default false
   */ disableRowSelectionExcludeModel: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * If `true`, the selection on click on a row or cell is disabled.
   * @default false
   */ disableRowSelectionOnClick: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * If `true`, the virtualization is disabled.
   * @default false
   */ disableVirtualization: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * Controls whether to use the cell or row editing.
   * @default "cell"
   */ editMode: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOf([
        'cell',
        'row'
    ]),
    /**
   * Use if the actual rowCount is not known upfront, but an estimation is available.
   * If some rows have children (for instance in the tree data), this number represents the amount of top level rows.
   * Applicable only with `paginationMode="server"` and when `rowCount="-1"`
   */ estimatedRowCount: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number,
    /**
   * Unstable features, breaking changes might be introduced.
   * For each feature, if the flag is not explicitly set to `true`, the feature will be fully disabled and any property / method call will not have any effect.
   */ experimentalFeatures: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].shape({
        warnIfFocusStateIsNotSynced: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool
    }),
    /**
   * The milliseconds delay to wait after a keystroke before triggering filtering.
   * @default 150
   */ filterDebounceMs: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number,
    /**
   * Filtering can be processed on the server or client-side.
   * Set it to 'server' if you would like to handle filtering on the server-side.
   * @default "client"
   */ filterMode: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOf([
        'client',
        'server'
    ]),
    /**
   * Set the filter model of the Data Grid.
   */ filterModel: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].shape({
        items: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].arrayOf(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].shape({
            field: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string.isRequired,
            id: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
                __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number,
                __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string
            ]),
            operator: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string.isRequired,
            value: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].any
        })).isRequired,
        logicOperator: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOf([
            'and',
            'or'
        ]),
        quickFilterExcludeHiddenColumns: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
        quickFilterLogicOperator: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOf([
            'and',
            'or'
        ]),
        quickFilterValues: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].array
    }),
    /**
   * Function that applies CSS classes dynamically on cells.
   * @param {GridCellParams} params With all properties from [[GridCellParams]].
   * @returns {string} The CSS class to apply to the cell.
   */ getCellClassName: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
    /**
   * Function that returns the element to render in row detail.
   * @param {GridRowParams} params With all properties from [[GridRowParams]].
   * @returns {React.JSX.Element} The row detail element.
   */ getDetailPanelContent: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
    /**
   * Function that returns the estimated height for a row.
   * Only works if dynamic row height is used.
   * Once the row height is measured this value is discarded.
   * @param {GridRowHeightParams} params With all properties from [[GridRowHeightParams]].
   * @returns {number | null} The estimated row height value. If `null` or `undefined` then the default row height, based on the density, is applied.
   */ getEstimatedRowHeight: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
    /**
   * Function that applies CSS classes dynamically on rows.
   * @param {GridRowClassNameParams} params With all properties from [[GridRowClassNameParams]].
   * @returns {string} The CSS class to apply to the row.
   */ getRowClassName: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
    /**
   * Function that sets the row height per row.
   * @param {GridRowHeightParams} params With all properties from [[GridRowHeightParams]].
   * @returns {GridRowHeightReturnValue} The row height value. If `null` or `undefined` then the default row height is applied. If "auto" then the row height is calculated based on the content.
   */ getRowHeight: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
    /**
   * Return the id of a given [[GridRowModel]].
   * Ensure the reference of this prop is stable to avoid performance implications.
   * It could be done by either defining the prop outside of the component or by memoizing it.
   */ getRowId: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
    /**
   * Function that allows to specify the spacing between rows.
   * @param {GridRowSpacingParams} params With all properties from [[GridRowSpacingParams]].
   * @returns {GridRowSpacing} The row spacing values.
   */ getRowSpacing: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
    /**
   * If `true`, the footer component is hidden.
   * @default false
   */ hideFooter: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * If `true`, the pagination component in the footer is hidden.
   * @default false
   */ hideFooterPagination: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * If `true`, the selected row count in the footer is hidden.
   * @default false
   */ hideFooterSelectedRowCount: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * If `true`, the diacritics (accents) are ignored when filtering or quick filtering.
   * E.g. when filter value is `cafe`, the rows with `café` will be visible.
   * @default false
   */ ignoreDiacritics: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * If `true`, the Data Grid will not use `valueFormatter` when exporting to CSV or copying to clipboard.
   * If an object is provided, you can choose to ignore the `valueFormatter` for CSV export or clipboard export.
   * @default false
   */ ignoreValueFormatterDuringExport: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].shape({
            clipboardExport: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
            csvExport: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool
        }),
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool
    ]),
    /**
   * The initial state of the DataGrid.
   * The data in it will be set in the state on initialization but will not be controlled.
   * If one of the data in `initialState` is also being controlled, then the control state wins.
   */ initialState: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object,
    /**
   * Callback fired when a cell is rendered, returns true if the cell is editable.
   * @param {GridCellParams} params With all properties from [[GridCellParams]].
   * @returns {boolean} A boolean indicating if the cell is editable.
   */ isCellEditable: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
    /**
   * Determines if a row can be selected.
   * @param {GridRowParams} params With all properties from [[GridRowParams]].
   * @returns {boolean} A boolean indicating if the row is selectable.
   */ isRowSelectable: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
    /**
   * If `true`, the selection model will retain selected rows that do not exist.
   * Useful when using server side pagination and row selections need to be retained
   * when changing pages.
   * @default false
   */ keepNonExistentRowsSelected: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * The label of the Data Grid.
   * If the `showToolbar` prop is `true`, the label will be displayed in the toolbar and applied to the `aria-label` attribute of the grid.
   * If the `showToolbar` prop is `false`, the label will not be visible but will be applied to the `aria-label` attribute of the grid.
   */ label: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    /**
   * If `true`, a loading overlay is displayed.
   * @default false
   */ loading: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * Set the locale text of the Data Grid.
   * You can find all the translation keys supported in [the source](https://github.com/mui/mui-x/blob/HEAD/packages/x-data-grid/src/constants/localeTextConstants.ts) in the GitHub repository.
   */ localeText: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object,
    /**
   * Pass a custom logger in the components that implements the [[Logger]] interface.
   * @default console
   */ logger: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].shape({
        debug: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func.isRequired,
        error: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func.isRequired,
        info: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func.isRequired,
        warn: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func.isRequired
    }),
    /**
   * Allows to pass the logging level or false to turn off logging.
   * @default "error" ("warn" in dev mode)
   */ logLevel: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOf([
        'debug',
        'error',
        'info',
        'warn',
        false
    ]),
    /**
   * Nonce of the inline styles for [Content Security Policy](https://www.w3.org/TR/2016/REC-CSP2-20161215/#script-src-the-nonce-attribute).
   */ nonce: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string,
    /**
   * Callback fired when any cell is clicked.
   * @param {GridCellParams} params With all properties from [[GridCellParams]].
   * @param {MuiEvent<React.MouseEvent>} event The event object.
   * @param {GridCallbackDetails} details Additional details for this callback.
   */ onCellClick: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
    /**
   * Callback fired when a double click event comes from a cell element.
   * @param {GridCellParams} params With all properties from [[GridCellParams]].
   * @param {MuiEvent<React.MouseEvent>} event The event object.
   * @param {GridCallbackDetails} details Additional details for this callback.
   */ onCellDoubleClick: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
    /**
   * Callback fired when the cell turns to edit mode.
   * @param {GridCellParams} params With all properties from [[GridCellParams]].
   * @param {MuiEvent<React.KeyboardEvent | React.MouseEvent>} event The event that caused this prop to be called.
   */ onCellEditStart: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
    /**
   * Callback fired when the cell turns to view mode.
   * @param {GridCellParams} params With all properties from [[GridCellParams]].
   * @param {MuiEvent<MuiBaseEvent>} event The event that caused this prop to be called.
   */ onCellEditStop: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
    /**
   * Callback fired when a keydown event comes from a cell element.
   * @param {GridCellParams} params With all properties from [[GridCellParams]].
   * @param {MuiEvent<React.KeyboardEvent>} event The event object.
   * @param {GridCallbackDetails} details Additional details for this callback.
   */ onCellKeyDown: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
    /**
   * Callback fired when the `cellModesModel` prop changes.
   * @param {GridCellModesModel} cellModesModel Object containing which cells are in "edit" mode.
   * @param {GridCallbackDetails} details Additional details for this callback.
   */ onCellModesModelChange: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
    /**
   * Callback called when the data is copied to the clipboard.
   * @param {string} data The data copied to the clipboard.
   */ onClipboardCopy: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
    /**
   * Callback fired when a click event comes from a column header element.
   * @param {GridColumnHeaderParams} params With all properties from [[GridColumnHeaderParams]].
   * @param {MuiEvent<React.MouseEvent>} event The event object.
   * @param {GridCallbackDetails} details Additional details for this callback.
   */ onColumnHeaderClick: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
    /**
   * Callback fired when a contextmenu event comes from a column header element.
   * @param {GridColumnHeaderParams} params With all properties from [[GridColumnHeaderParams]].
   * @param {MuiEvent<React.MouseEvent>} event The event object.
   */ onColumnHeaderContextMenu: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
    /**
   * Callback fired when a double click event comes from a column header element.
   * @param {GridColumnHeaderParams} params With all properties from [[GridColumnHeaderParams]].
   * @param {MuiEvent<React.MouseEvent>} event The event object.
   * @param {GridCallbackDetails} details Additional details for this callback.
   */ onColumnHeaderDoubleClick: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
    /**
   * Callback fired when a mouse enter event comes from a column header element.
   * @param {GridColumnHeaderParams} params With all properties from [[GridColumnHeaderParams]].
   * @param {MuiEvent<React.MouseEvent>} event The event object.
   * @param {GridCallbackDetails} details Additional details for this callback.
   */ onColumnHeaderEnter: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
    /**
   * Callback fired when a mouse leave event comes from a column header element.
   * @param {GridColumnHeaderParams} params With all properties from [[GridColumnHeaderParams]].
   * @param {MuiEvent<React.MouseEvent>} event The event object.
   * @param {GridCallbackDetails} details Additional details for this callback.
   */ onColumnHeaderLeave: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
    /**
   * Callback fired when a mouseout event comes from a column header element.
   * @param {GridColumnHeaderParams} params With all properties from [[GridColumnHeaderParams]].
   * @param {MuiEvent<React.MouseEvent>} event The event object.
   * @param {GridCallbackDetails} details Additional details for this callback.
   */ onColumnHeaderOut: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
    /**
   * Callback fired when a mouseover event comes from a column header element.
   * @param {GridColumnHeaderParams} params With all properties from [[GridColumnHeaderParams]].
   * @param {MuiEvent<React.MouseEvent>} event The event object.
   * @param {GridCallbackDetails} details Additional details for this callback.
   */ onColumnHeaderOver: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
    /**
   * Callback fired when a column is reordered.
   * @param {GridColumnOrderChangeParams} params With all properties from [[GridColumnOrderChangeParams]].
   * @param {MuiEvent<{}>} event The event object.
   * @param {GridCallbackDetails} details Additional details for this callback.
   */ onColumnOrderChange: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
    /**
   * Callback fired while a column is being resized.
   * @param {GridColumnResizeParams} params With all properties from [[GridColumnResizeParams]].
   * @param {MuiEvent<React.MouseEvent>} event The event object.
   * @param {GridCallbackDetails} details Additional details for this callback.
   */ onColumnResize: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
    /**
   * Callback fired when the column visibility model changes.
   * @param {GridColumnVisibilityModel} model The new model.
   * @param {GridCallbackDetails} details Additional details for this callback.
   */ onColumnVisibilityModelChange: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
    /**
   * Callback fired when the width of a column is changed.
   * @param {GridColumnResizeParams} params With all properties from [[GridColumnResizeParams]].
   * @param {MuiEvent<React.MouseEvent>} event The event object.
   * @param {GridCallbackDetails} details Additional details for this callback.
   */ onColumnWidthChange: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
    /**
   * Callback fired when a data source request fails.
   * @param {GridGetRowsError | GridUpdateRowError} error The data source error object.
   */ onDataSourceError: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
    /**
   * Callback fired when the density changes.
   * @param {GridDensity} density New density value.
   */ onDensityChange: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
    /**
   * Callback fired when the Filter model changes before the filters are applied.
   * @param {GridFilterModel} model With all properties from [[GridFilterModel]].
   * @param {GridCallbackDetails} details Additional details for this callback.
   */ onFilterModelChange: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
    /**
   * Callback fired when the menu is closed.
   * @param {GridMenuParams} params With all properties from [[GridMenuParams]].
   * @param {MuiEvent<{}>} event The event object.
   * @param {GridCallbackDetails} details Additional details for this callback.
   */ onMenuClose: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
    /**
   * Callback fired when the menu is opened.
   * @param {GridMenuParams} params With all properties from [[GridMenuParams]].
   * @param {MuiEvent<{}>} event The event object.
   * @param {GridCallbackDetails} details Additional details for this callback.
   */ onMenuOpen: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
    /**
   * Callback fired when the pagination meta has changed.
   * @param {GridPaginationMeta} paginationMeta Updated pagination meta.
   */ onPaginationMetaChange: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
    /**
   * Callback fired when the pagination model has changed.
   * @param {GridPaginationModel} model Updated pagination model.
   * @param {GridCallbackDetails} details Additional details for this callback.
   */ onPaginationModelChange: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
    /**
   * Callback fired when the preferences panel is closed.
   * @param {GridPreferencePanelParams} params With all properties from [[GridPreferencePanelParams]].
   * @param {MuiEvent<{}>} event The event object.
   * @param {GridCallbackDetails} details Additional details for this callback.
   */ onPreferencePanelClose: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
    /**
   * Callback fired when the preferences panel is opened.
   * @param {GridPreferencePanelParams} params With all properties from [[GridPreferencePanelParams]].
   * @param {MuiEvent<{}>} event The event object.
   * @param {GridCallbackDetails} details Additional details for this callback.
   */ onPreferencePanelOpen: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
    /**
   * Callback called when `processRowUpdate()` throws an error or rejects.
   * @param {any} error The error thrown.
   */ onProcessRowUpdateError: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
    /**
   * Callback fired when the Data Grid is resized.
   * @param {ElementSize} containerSize With all properties from [[ElementSize]].
   * @param {MuiEvent<{}>} event The event object.
   * @param {GridCallbackDetails} details Additional details for this callback.
   */ onResize: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
    /**
   * Callback fired when a row is clicked.
   * Not called if the target clicked is an interactive element added by the built-in columns.
   * @param {GridRowParams} params With all properties from [[GridRowParams]].
   * @param {MuiEvent<React.MouseEvent>} event The event object.
   * @param {GridCallbackDetails} details Additional details for this callback.
   */ onRowClick: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
    /**
   * Callback fired when the row count has changed.
   * @param {number} count Updated row count.
   */ onRowCountChange: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
    /**
   * Callback fired when a double click event comes from a row container element.
   * @param {GridRowParams} params With all properties from [[RowParams]].
   * @param {MuiEvent<React.MouseEvent>} event The event object.
   * @param {GridCallbackDetails} details Additional details for this callback.
   */ onRowDoubleClick: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
    /**
   * Callback fired when the row turns to edit mode.
   * @param {GridRowParams} params With all properties from [[GridRowParams]].
   * @param {MuiEvent<React.KeyboardEvent | React.MouseEvent>} event The event that caused this prop to be called.
   */ onRowEditStart: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
    /**
   * Callback fired when the row turns to view mode.
   * @param {GridRowParams} params With all properties from [[GridRowParams]].
   * @param {MuiEvent<MuiBaseEvent>} event The event that caused this prop to be called.
   */ onRowEditStop: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
    /**
   * Callback fired when the `rowModesModel` prop changes.
   * @param {GridRowModesModel} rowModesModel Object containing which rows are in "edit" mode.
   * @param {GridCallbackDetails} details Additional details for this callback.
   */ onRowModesModelChange: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
    /**
   * Callback fired when the selection state of one or multiple rows changes.
   * @param {GridRowSelectionModel} rowSelectionModel With all the row ids [[GridSelectionModel]].
   * @param {GridCallbackDetails} details Additional details for this callback.
   */ onRowSelectionModelChange: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
    /**
   * Callback fired when the sort model changes before a column is sorted.
   * @param {GridSortModel} model With all properties from [[GridSortModel]].
   * @param {GridCallbackDetails} details Additional details for this callback.
   */ onSortModelChange: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
    /**
   * Callback fired when the state of the Data Grid is updated.
   * @param {GridState} state The new state.
   * @param {MuiEvent<{}>} event The event object.
   * @param {GridCallbackDetails} details Additional details for this callback.
   * @ignore - do not document.
   */ onStateChange: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
    /**
   * Select the pageSize dynamically using the component UI.
   * @default [25, 50, 100]
   */ pageSizeOptions: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].arrayOf(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number,
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].shape({
            label: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string.isRequired,
            value: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number.isRequired
        })
    ]).isRequired),
    pagination: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOf([
        true
    ]),
    /**
   * The extra information about the pagination state of the Data Grid.
   * Only applicable with `paginationMode="server"`.
   */ paginationMeta: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].shape({
        hasNextPage: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool
    }),
    /**
   * Pagination can be processed on the server or client-side.
   * Set it to 'client' if you would like to handle the pagination on the client-side.
   * Set it to 'server' if you would like to handle the pagination on the server-side.
   * @default "client"
   */ paginationMode: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOf([
        'client',
        'server'
    ]),
    /**
   * The pagination model of type [[GridPaginationModel]] which refers to current `page` and `pageSize`.
   */ paginationModel: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].shape({
        page: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number.isRequired,
        pageSize: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number.isRequired
    }),
    /**
   * Callback called before updating a row with new values in the row and cell editing.
   * @template R
   * @param {R} newRow Row object with the new values.
   * @param {R} oldRow Row object with the old values.
   * @param {{ rowId: GridRowId }} params Additional parameters.
   * @returns {Promise<R> | R} The final values to update the row.
   */ processRowUpdate: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
    /**
   * The milliseconds throttle delay for resizing the grid.
   * @default 60
   */ resizeThrottleMs: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number,
    /**
   * Row region in pixels to render before/after the viewport
   * @default 150
   */ rowBufferPx: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number,
    /**
   * Set the total number of rows, if it is different from the length of the value `rows` prop.
   * If some rows have children (for instance in the tree data), this number represents the amount of top level rows.
   * Only works with `paginationMode="server"`, ignored when `paginationMode="client"`.
   */ rowCount: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number,
    /**
   * Sets the height in pixel of a row in the Data Grid.
   * @default 52
   */ rowHeight: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number,
    /**
   * Controls the modes of the rows.
   */ rowModesModel: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object,
    /**
   * Set of rows of type [[GridRowsProp]].
   * @default []
   */ rows: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].arrayOf(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object),
    /**
   * If `false`, the row selection mode is disabled.
   * @default true
   */ rowSelection: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * Sets the row selection model of the Data Grid.
   */ rowSelectionModel: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"] /* @typescript-to-proptypes-ignore */ .shape({
        ids: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].instanceOf(Set).isRequired,
        type: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOf([
            'exclude',
            'include'
        ]).isRequired
    }),
    /**
   * Sets the type of space between rows added by `getRowSpacing`.
   * @default "margin"
   */ rowSpacingType: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOf([
        'border',
        'margin'
    ]),
    /**
   * If `true`, the Data Grid will auto span the cells over the rows having the same value.
   * @default false
   */ rowSpanning: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * Override the height/width of the Data Grid inner scrollbar.
   */ scrollbarSize: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].number,
    /**
   * If `true`, vertical borders will be displayed between cells.
   * @default false
   */ showCellVerticalBorder: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * If `true`, vertical borders will be displayed between column header items.
   * @default false
   */ showColumnVerticalBorder: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * If `true`, the toolbar is displayed.
   * @default false
   */ showToolbar: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool,
    /**
   * Overridable components props dynamically passed to the component at rendering.
   */ slotProps: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object,
    /**
   * Overridable components.
   */ slots: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object,
    /**
   * Sorting can be processed on the server or client-side.
   * Set it to 'client' if you would like to handle sorting on the client-side.
   * Set it to 'server' if you would like to handle sorting on the server-side.
   * @default "client"
   */ sortingMode: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOf([
        'client',
        'server'
    ]),
    /**
   * The order of the sorting sequence.
   * @default ['asc', 'desc', null]
   */ sortingOrder: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].arrayOf(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOf([
        'asc',
        'desc'
    ])),
    /**
   * Set the sort model of the Data Grid.
   */ sortModel: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].arrayOf(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].shape({
        field: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].string.isRequired,
        sort: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOf([
            'asc',
            'desc'
        ])
    })),
    style: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object,
    /**
   * The system prop that allows defining system overrides as well as additional CSS styles.
   */ sx: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].arrayOf(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].oneOfType([
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object,
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool
        ])),
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].func,
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].object
    ]),
    /**
   * If `true`, the Data Grid enables column virtualization when `getRowHeight` is set to `() => 'auto'`.
   * By default, column virtualization is disabled when dynamic row height is enabled to measure the row height correctly.
   * For datasets with a large number of columns, this can cause performance issues.
   * The downside of enabling this prop is that the row height will be estimated based the cells that are currently rendered, which can cause row height change when scrolling horizontally.
   * @default false
   */ virtualizeColumnsWithAutoRowHeight: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$prop$2d$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].bool
};
}),
"[project]/node_modules/@mui/x-data-grid/esm/material/icons/createSvgIcon.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createSvgIcon",
    ()=>createSvgIcon
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createSvgIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/utils/createSvgIcon.js [app-client] (ecmascript) <export default as createSvgIcon>");
;
const createSvgIcon = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$utils$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createSvgIcon$3e$__["createSvgIcon"];
}),
"[project]/node_modules/@mui/x-data-grid/esm/material/icons/index.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "GridAddIcon",
    ()=>GridAddIcon,
    "GridArrowDownwardIcon",
    ()=>GridArrowDownwardIcon,
    "GridArrowUpwardIcon",
    ()=>GridArrowUpwardIcon,
    "GridCheckCircleIcon",
    ()=>GridCheckCircleIcon,
    "GridCheckIcon",
    ()=>GridCheckIcon,
    "GridClearIcon",
    ()=>GridClearIcon,
    "GridCloseIcon",
    ()=>GridCloseIcon,
    "GridColumnIcon",
    ()=>GridColumnIcon,
    "GridDeleteForeverIcon",
    ()=>GridDeleteForeverIcon,
    "GridDeleteIcon",
    ()=>GridDeleteIcon,
    "GridDownloadIcon",
    ()=>GridDownloadIcon,
    "GridDragIcon",
    ()=>GridDragIcon,
    "GridExpandMoreIcon",
    ()=>GridExpandMoreIcon,
    "GridFilterAltIcon",
    ()=>GridFilterAltIcon,
    "GridFilterListIcon",
    ()=>GridFilterListIcon,
    "GridKeyboardArrowRight",
    ()=>GridKeyboardArrowRight,
    "GridLoadIcon",
    ()=>GridLoadIcon,
    "GridLongTextCellCollapseIcon",
    ()=>GridLongTextCellCollapseIcon,
    "GridLongTextCellExpandIcon",
    ()=>GridLongTextCellExpandIcon,
    "GridMenuIcon",
    ()=>GridMenuIcon,
    "GridMoreVertIcon",
    ()=>GridMoreVertIcon,
    "GridRedoIcon",
    ()=>GridRedoIcon,
    "GridRemoveIcon",
    ()=>GridRemoveIcon,
    "GridSearchIcon",
    ()=>GridSearchIcon,
    "GridSeparatorIcon",
    ()=>GridSeparatorIcon,
    "GridTableRowsIcon",
    ()=>GridTableRowsIcon,
    "GridTripleDotsVerticalIcon",
    ()=>GridTripleDotsVerticalIcon,
    "GridUndoIcon",
    ()=>GridUndoIcon,
    "GridViewColumnIcon",
    ()=>GridViewColumnIcon,
    "GridViewHeadlineIcon",
    ()=>GridViewHeadlineIcon,
    "GridViewStreamIcon",
    ()=>GridViewStreamIcon,
    "GridVisibilityOffIcon",
    ()=>GridVisibilityOffIcon
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$material$2f$icons$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/material/icons/createSvgIcon.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
;
;
const GridArrowUpwardIcon = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$material$2f$icons$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSvgIcon"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
    d: "M4 12l1.41 1.41L11 7.83V20h2V7.83l5.58 5.59L20 12l-8-8-8 8z"
}), 'ArrowUpward');
const GridArrowDownwardIcon = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$material$2f$icons$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSvgIcon"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
    d: "M20 12l-1.41-1.41L13 16.17V4h-2v12.17l-5.58-5.59L4 12l8 8 8-8z"
}), 'ArrowDownward');
const GridKeyboardArrowRight = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$material$2f$icons$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSvgIcon"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
    d: "M8.59 16.59 13.17 12 8.59 7.41 10 6l6 6-6 6-1.41-1.41z"
}), 'KeyboardArrowRight');
const GridExpandMoreIcon = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$material$2f$icons$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSvgIcon"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
    d: "M16.59 8.59 12 13.17 7.41 8.59 6 10l6 6 6-6z"
}), 'ExpandMore');
const GridFilterListIcon = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$material$2f$icons$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSvgIcon"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
    d: "M10 18h4v-2h-4v2zM3 6v2h18V6H3zm3 7h12v-2H6v2z"
}), 'FilterList');
const GridFilterAltIcon = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$material$2f$icons$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSvgIcon"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
    d: "M4.25 5.61C6.27 8.2 10 13 10 13v6c0 .55.45 1 1 1h2c.55 0 1-.45 1-1v-6s3.72-4.8 5.74-7.39c.51-.66.04-1.61-.79-1.61H5.04c-.83 0-1.3.95-.79 1.61z"
}), 'FilterAlt');
const GridSearchIcon = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$material$2f$icons$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSvgIcon"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
    d: "M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"
}), 'Search');
const GridMenuIcon = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$material$2f$icons$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSvgIcon"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
    d: "M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z"
}), 'Menu');
const GridCheckCircleIcon = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$material$2f$icons$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSvgIcon"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
    d: "M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"
}), 'CheckCircle');
const GridUndoIcon = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$material$2f$icons$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSvgIcon"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
    d: "M12.5 8c-2.65 0-5.05.99-6.9 2.6L2 7v9h9l-3.62-3.62c1.39-1.16 3.16-1.88 5.12-1.88 3.54 0 6.55 2.31 7.6 5.5l2.37-.78C21.08 11.03 17.15 8 12.5 8"
}), 'Undo');
const GridRedoIcon = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$material$2f$icons$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSvgIcon"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
    d: "M18.4 10.6C16.55 8.99 14.15 8 11.5 8c-4.65 0-8.58 3.03-9.96 7.22L3.9 16c1.05-3.19 4.05-5.5 7.6-5.5 1.95 0 3.73.72 5.12 1.88L13 16h9V7z"
}), 'Redo');
const GridColumnIcon = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$material$2f$icons$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSvgIcon"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
    d: "M14.67 5v14H9.33V5zm1 14H21V5h-5.33zm-7.34 0V5H3v14z"
}), 'ColumnIcon');
const GridSeparatorIcon = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$material$2f$icons$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSvgIcon"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("rect", {
    width: "1",
    height: "24",
    x: "11.5",
    rx: "0.5"
}), 'Separator');
const GridViewHeadlineIcon = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$material$2f$icons$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSvgIcon"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
    d: "M4 15h16v-2H4v2zm0 4h16v-2H4v2zm0-8h16V9H4v2zm0-6v2h16V5H4z"
}), 'ViewHeadline');
const GridTableRowsIcon = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$material$2f$icons$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSvgIcon"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
    d: "M21,8H3V4h18V8z M21,10H3v4h18V10z M21,16H3v4h18V16z"
}), 'TableRows');
const GridViewStreamIcon = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$material$2f$icons$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSvgIcon"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
    d: "M4 18h17v-6H4v6zM4 5v6h17V5H4z"
}), 'ViewStream');
const GridTripleDotsVerticalIcon = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$material$2f$icons$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSvgIcon"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
    d: "M12 8c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zm0 2c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm0 6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z"
}), 'TripleDotsVertical');
const GridCloseIcon = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$material$2f$icons$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSvgIcon"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
    d: "M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"
}), 'Close');
const GridAddIcon = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$material$2f$icons$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSvgIcon"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
    d: "M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z"
}), 'Add');
const GridRemoveIcon = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$material$2f$icons$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSvgIcon"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
    d: "M19 13H5v-2h14v2z"
}), 'Remove');
const GridLoadIcon = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$material$2f$icons$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSvgIcon"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
    d: "M12 4V1L8 5l4 4V6c3.31 0 6 2.69 6 6 0 1.01-.25 1.97-.7 2.8l1.46 1.46C19.54 15.03 20 13.57 20 12c0-4.42-3.58-8-8-8zm0 14c-3.31 0-6-2.69-6-6 0-1.01.25-1.97.7-2.8L5.24 7.74C4.46 8.97 4 10.43 4 12c0 4.42 3.58 8 8 8v3l4-4-4-4v3z"
}), 'Load');
const GridDragIcon = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$material$2f$icons$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSvgIcon"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
    d: "M11 18c0 1.1-.9 2-2 2s-2-.9-2-2 .9-2 2-2 2 .9 2 2zm-2-8c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm0-6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm6 4c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zm0 2c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm0 6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z"
}), 'Drag');
const GridCheckIcon = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$material$2f$icons$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSvgIcon"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
    d: "M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"
}), 'Check');
const GridMoreVertIcon = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$material$2f$icons$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSvgIcon"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
    d: "M12 8c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zm0 2c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm0 6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z"
}), 'MoreVert');
const GridVisibilityOffIcon = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$material$2f$icons$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSvgIcon"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
    d: "M12 7c2.76 0 5 2.24 5 5 0 .65-.13 1.26-.36 1.83l2.92 2.92c1.51-1.26 2.7-2.89 3.43-4.75-1.73-4.39-6-7.5-11-7.5-1.4 0-2.74.25-3.98.7l2.16 2.16C10.74 7.13 11.35 7 12 7zM2 4.27l2.28 2.28.46.46C3.08 8.3 1.78 10.02 1 12c1.73 4.39 6 7.5 11 7.5 1.55 0 3.03-.3 4.38-.84l.42.42L19.73 22 21 20.73 3.27 3 2 4.27zM7.53 9.8l1.55 1.55c-.05.21-.08.43-.08.65 0 1.66 1.34 3 3 3 .22 0 .44-.03.65-.08l1.55 1.55c-.67.33-1.41.53-2.2.53-2.76 0-5-2.24-5-5 0-.79.2-1.53.53-2.2zm4.31-.78l3.15 3.15.02-.16c0-1.66-1.34-3-3-3l-.17.01z"
}), 'VisibilityOff');
const GridViewColumnIcon = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$material$2f$icons$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSvgIcon"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("g", {
    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
        d: "M14.67,5v14H9.33V5H14.67z M15.67,19H21V5h-5.33V19z M8.33,19V5H3v14H8.33z"
    })
}), 'ViewColumn');
const GridClearIcon = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$material$2f$icons$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSvgIcon"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
    d: "M12 2C6.47 2 2 6.47 2 12s4.47 10 10 10 10-4.47 10-10S17.53 2 12 2m5 13.59L15.59 17 12 13.41 8.41 17 7 15.59 10.59 12 7 8.41 8.41 7 12 10.59 15.59 7 17 8.41 13.41 12z"
}), 'Clear');
const GridDeleteIcon = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$material$2f$icons$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSvgIcon"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
    d: "M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"
}), 'Delete');
const GridDeleteForeverIcon = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$material$2f$icons$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSvgIcon"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
    d: "M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zm2.46-7.12l1.41-1.41L12 12.59l2.12-2.12 1.41 1.41L13.41 14l2.12 2.12-1.41 1.41L12 15.41l-2.12 2.12-1.41-1.41L10.59 14l-2.13-2.12zM15.5 4l-1-1h-5l-1 1H5v2h14V4z"
}), 'Delete');
const GridDownloadIcon = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$material$2f$icons$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSvgIcon"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
    d: "M5 20h14v-2H5zM19 9h-4V3H9v6H5l7 7z"
}), 'Download');
const GridLongTextCellExpandIcon = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$material$2f$icons$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSvgIcon"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
    d: "M21 11V3h-8l3.29 3.29-10 10L3 13v8h8l-3.29-3.29 10-10z"
}), 'OpenInFull');
const GridLongTextCellCollapseIcon = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$material$2f$icons$2f$createSvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSvgIcon"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
    d: "M5 15h2V8.41L18.59 20 20 18.59 8.41 7H15V5H5z"
}), 'NorthWest');
}),
"[project]/node_modules/@mui/x-data-grid/esm/material/index.js [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$extends$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@babel/runtime/helpers/esm/extends.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$objectWithoutPropertiesLoose$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@babel/runtime/helpers/esm/objectWithoutPropertiesLoose.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/clsx/dist/clsx.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$useForkRef$2f$useForkRef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/utils/esm/useForkRef/useForkRef.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$useEventCallback$2f$useEventCallback$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/utils/esm/useEventCallback/useEventCallback.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__styled$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/styles/styled.js [app-client] (ecmascript) <locals> <export default as styled>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$useTheme$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__useTheme$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/styles/useTheme.js [app-client] (ecmascript) <export default as useTheme>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Autocomplete$2f$Autocomplete$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Autocomplete/Autocomplete.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Badge$2f$Badge$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Badge/Badge.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Checkbox$2f$Checkbox$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Checkbox/Checkbox.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Chip/Chip.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$CircularProgress$2f$CircularProgress$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/CircularProgress/CircularProgress.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Divider$2f$Divider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Divider/Divider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$InputBase$2f$InputBase$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/InputBase/InputBase.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Unstable_TrapFocus$2f$FocusTrap$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Unstable_TrapFocus/FocusTrap.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$LinearProgress$2f$LinearProgress$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/LinearProgress/LinearProgress.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemIcon$2f$ListItemIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/ListItemIcon/ListItemIcon.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemText$2f$ListItemText$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/ListItemText/ListItemText.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemText$2f$listItemTextClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__listItemTextClasses$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/ListItemText/listItemTextClasses.js [app-client] (ecmascript) <export default as listItemTextClasses>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$MenuList$2f$MenuList$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/MenuList/MenuList.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$MenuItem$2f$MenuItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/MenuItem/MenuItem.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/TextField/TextField.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextareaAutosize$2f$TextareaAutosize$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/TextareaAutosize/TextareaAutosize.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControl$2f$FormControl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/FormControl/FormControl.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControlLabel$2f$FormControlLabel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/FormControlLabel/FormControlLabel.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControlLabel$2f$formControlLabelClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__formControlLabelClasses$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/FormControlLabel/formControlLabelClasses.js [app-client] (ecmascript) <export default as formControlLabelClasses>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Select$2f$Select$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Select/Select.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Switch$2f$Switch$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Switch/Switch.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Button/Button.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/IconButton/IconButton.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$iconButtonClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__iconButtonClasses$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/IconButton/iconButtonClasses.js [app-client] (ecmascript) <export default as iconButtonClasses>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$InputAdornment$2f$InputAdornment$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/InputAdornment/InputAdornment.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$InputAdornment$2f$inputAdornmentClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__inputAdornmentClasses$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/InputAdornment/inputAdornmentClasses.js [app-client] (ecmascript) <export default as inputAdornmentClasses>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Tooltip/Tooltip.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TablePagination$2f$TablePagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/TablePagination/TablePagination.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TablePagination$2f$tablePaginationClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__tablePaginationClasses$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/TablePagination/tablePaginationClasses.js [app-client] (ecmascript) <export default as tablePaginationClasses>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Popper$2f$Popper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Popper/Popper.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ClickAwayListener$2f$ClickAwayListener$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__ClickAwayListener__as__default$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/ClickAwayListener/ClickAwayListener.js [app-client] (ecmascript) <export ClickAwayListener as default>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Grow$2f$Grow$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Grow/Grow.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Paper$2f$Paper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Paper/Paper.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$InputLabel$2f$InputLabel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/InputLabel/InputLabel.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Skeleton/Skeleton.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tabs$2f$Tabs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Tabs/Tabs.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tab$2f$Tab$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Tab/Tab.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ToggleButton$2f$ToggleButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/ToggleButton/ToggleButton.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$internals$2f$esm$2f$forwardRef$2f$forwardRef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-internals/esm/forwardRef/forwardRef.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$useId$2f$useId$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/utils/esm/useId/useId.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$material$2f$icons$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/material/icons/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$GridColumnUnsortedIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/components/GridColumnUnsortedIcon.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$utils$2f$useGridApiContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/hooks/utils/useGridApiContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$utils$2f$useGridRootProps$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/hooks/utils/useGridRootProps.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
;
;
const _excluded = [
    "id",
    "label",
    "labelId",
    "material",
    "disabled",
    "slotProps",
    "onChange",
    "onKeyDown",
    "onOpen",
    "onClose",
    "size",
    "style",
    "fullWidth"
], _excluded2 = [
    "onRowsPerPageChange",
    "material",
    "disabled"
], _excluded3 = [
    "material"
], _excluded4 = [
    "autoFocus",
    "label",
    "fullWidth",
    "slotProps",
    "className",
    "material"
], _excluded5 = [
    "material"
], _excluded6 = [
    "material"
], _excluded7 = [
    "material"
], _excluded8 = [
    "material"
], _excluded9 = [
    "material"
], _excluded0 = [
    "material"
], _excluded1 = [
    "material"
], _excluded10 = [
    "material"
], _excluded11 = [
    "material"
], _excluded12 = [
    "material",
    "label",
    "className"
], _excluded13 = [
    "material"
], _excluded14 = [
    "inert",
    "iconStart",
    "iconEnd",
    "children",
    "material"
], _excluded15 = [
    "slotProps",
    "material"
], _excluded16 = [
    "id",
    "multiple",
    "freeSolo",
    "options",
    "getOptionLabel",
    "isOptionEqualToValue",
    "value",
    "onChange",
    "label",
    "placeholder",
    "slotProps",
    "material"
], _excluded17 = [
    "key"
], _excluded18 = [
    "inputProps",
    "InputProps",
    "InputLabelProps"
], _excluded19 = [
    "slotProps",
    "material"
], _excluded20 = [
    "material"
], _excluded21 = [
    "ref",
    "open",
    "children",
    "className",
    "clickAwayTouchEvent",
    "clickAwayMouseEvent",
    "flip",
    "focusTrap",
    "onExited",
    "onClickAway",
    "onDidShow",
    "onDidHide",
    "id",
    "target",
    "transition",
    "placement",
    "material"
], _excluded22 = [
    "native"
], _excluded23 = [
    "children",
    "value",
    "active"
], _excluded24 = [
    "items",
    "value",
    "material"
];
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
/* eslint-disable material-ui/disallow-react-api-in-server-components */ const InputAdornment = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$InputAdornment$2f$InputAdornment$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
    slot: 'internal'
})(({ theme })=>({
        [`&.${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$InputAdornment$2f$inputAdornmentClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__inputAdornmentClasses$3e$__["inputAdornmentClasses"].positionEnd} .${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$iconButtonClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__iconButtonClasses$3e$__["iconButtonClasses"].sizeSmall}`]: {
            marginRight: theme.spacing(-0.75)
        }
    }));
const FormControlLabel = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControlLabel$2f$FormControlLabel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
    slot: 'internal',
    shouldForwardProp: (prop)=>prop !== 'fullWidth'
})(({ theme })=>({
        gap: theme.spacing(0.5),
        margin: 0,
        overflow: 'hidden',
        [`& .${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControlLabel$2f$formControlLabelClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__formControlLabelClasses$3e$__["formControlLabelClasses"].label}`]: {
            fontSize: theme.typography.pxToRem(14),
            overflow: 'hidden',
            textOverflow: 'ellipsis',
            whiteSpace: 'nowrap'
        },
        variants: [
            {
                props: {
                    fullWidth: true
                },
                style: {
                    width: '100%'
                }
            }
        ]
    }));
const Checkbox = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Checkbox$2f$Checkbox$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
    slot: 'internal',
    shouldForwardProp: (prop)=>prop !== 'density'
})(({ theme })=>({
        variants: [
            {
                props: {
                    density: 'compact'
                },
                style: {
                    padding: theme.spacing(0.5)
                }
            }
        ]
    }));
const ListItemText = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemText$2f$ListItemText$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
    slot: 'internal'
})({
    [`& .${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemText$2f$listItemTextClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__listItemTextClasses$3e$__["listItemTextClasses"].primary}`]: {
        overflowX: 'clip',
        textOverflow: 'ellipsis',
        maxWidth: '300px'
    }
});
const BaseSelect = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$internals$2f$esm$2f$forwardRef$2f$forwardRef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(function BaseSelect(props, ref) {
    const { id, label, labelId, material, disabled, slotProps, onChange, onKeyDown, onOpen, onClose, size, style, fullWidth } = props, other = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$objectWithoutPropertiesLoose$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(props, _excluded);
    const theme = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$useTheme$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__useTheme$3e$__["useTheme"])();
    const textFieldDefaults = theme.components?.MuiTextField?.defaultProps ?? {};
    const computedSize = size ?? textFieldDefaults.size;
    const computedVariant = textFieldDefaults.variant ?? 'outlined';
    const menuProps = {
        PaperProps: {
            onKeyDown
        }
    };
    if (onClose) {
        menuProps.onClose = onClose;
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$FormControl$2f$FormControl$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        size: computedSize,
        fullWidth: fullWidth,
        style: style,
        disabled: disabled,
        ref: ref,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$InputLabel$2f$InputLabel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                id: labelId,
                htmlFor: id,
                shrink: true,
                variant: computedVariant,
                children: label
            }),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Select$2f$Select$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$extends$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({
                id: id,
                labelId: labelId,
                label: label,
                displayEmpty: true,
                onChange: onChange,
                variant: computedVariant
            }, other, {
                inputProps: slotProps?.htmlInput,
                onOpen: onOpen,
                MenuProps: menuProps,
                size: computedSize
            }, material))
        ]
    });
});
if ("TURBOPACK compile-time truthy", 1) BaseSelect.displayName = "BaseSelect";
const StyledPagination = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TablePagination$2f$TablePagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
    slot: 'internal'
})(({ theme })=>({
        [`& .${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TablePagination$2f$tablePaginationClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__tablePaginationClasses$3e$__["tablePaginationClasses"].selectLabel}`]: {
            display: 'none',
            [theme.breakpoints.up('sm')]: {
                display: 'block'
            }
        },
        [`& .${__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TablePagination$2f$tablePaginationClasses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__tablePaginationClasses$3e$__["tablePaginationClasses"].input}`]: {
            display: 'none',
            [theme.breakpoints.up('sm')]: {
                display: 'inline-flex'
            }
        }
    }));
const BasePagination = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$internals$2f$esm$2f$forwardRef$2f$forwardRef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(function BasePagination(props, ref) {
    const { onRowsPerPageChange, material, disabled } = props, other = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$objectWithoutPropertiesLoose$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(props, _excluded2);
    const computedProps = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "BasePagination.BasePagination.useMemo[computedProps]": ()=>{
            if (!disabled) {
                return undefined;
            }
            return {
                backIconButtonProps: {
                    disabled: true
                },
                nextIconButtonProps: {
                    disabled: true
                }
            };
        }
    }["BasePagination.BasePagination.useMemo[computedProps]"], [
        disabled
    ]);
    const apiRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$utils$2f$useGridApiContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGridApiContext"])();
    const rootProps = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$utils$2f$useGridRootProps$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGridRootProps"])();
    const { estimatedRowCount } = rootProps;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(StyledPagination, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$extends$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({
        component: "div",
        onRowsPerPageChange: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$useEventCallback$2f$useEventCallback$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({
            "BasePagination.BasePagination.useEventCallback": (event)=>{
                onRowsPerPageChange?.(Number(event.target.value));
            }
        }["BasePagination.BasePagination.useEventCallback"]),
        labelRowsPerPage: apiRef.current.getLocaleText('paginationRowsPerPage'),
        labelDisplayedRows: (params)=>apiRef.current.getLocaleText('paginationDisplayedRows')((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$extends$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({}, params, {
                estimated: estimatedRowCount
            })),
        getItemAriaLabel: apiRef.current.getLocaleText('paginationItemAriaLabel')
    }, computedProps, other, material, {
        ref: ref
    }));
});
if ("TURBOPACK compile-time truthy", 1) BasePagination.displayName = "BasePagination";
const BaseBadge = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$internals$2f$esm$2f$forwardRef$2f$forwardRef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(function BaseBadge(props, ref) {
    const { material } = props, other = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$objectWithoutPropertiesLoose$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(props, _excluded3);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Badge$2f$Badge$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$extends$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({}, other, material, {
        ref: ref
    }));
});
if ("TURBOPACK compile-time truthy", 1) BaseBadge.displayName = "BaseBadge";
const BaseCheckbox = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$internals$2f$esm$2f$forwardRef$2f$forwardRef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(function BaseCheckbox(props, ref) {
    const { autoFocus, label, fullWidth, slotProps, className, material } = props, other = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$objectWithoutPropertiesLoose$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(props, _excluded4);
    const elementRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null);
    const handleRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$useForkRef$2f$useForkRef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(elementRef, ref);
    const rippleRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null);
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "BaseCheckbox.BaseCheckbox.useEffect": ()=>{
            if (autoFocus) {
                const input = elementRef.current?.querySelector('input');
                input?.focus({
                    preventScroll: true
                });
            } else if (autoFocus === false && rippleRef.current) {
                // Only available in @mui/material v5.4.1 or later
                // @ts-ignore
                rippleRef.current.stop({});
            }
        }
    }["BaseCheckbox.BaseCheckbox.useEffect"], [
        autoFocus
    ]);
    if (!label) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Checkbox, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$extends$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({}, other, material, {
            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(className, material?.className),
            inputProps: slotProps?.htmlInput,
            ref: handleRef,
            touchRippleRef: rippleRef
        }));
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(FormControlLabel, {
        className: className,
        control: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Checkbox, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$extends$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({}, other, material, {
            inputProps: slotProps?.htmlInput,
            ref: handleRef,
            touchRippleRef: rippleRef
        })),
        label: label,
        fullWidth: fullWidth
    });
});
if ("TURBOPACK compile-time truthy", 1) BaseCheckbox.displayName = "BaseCheckbox";
const BaseCircularProgress = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$internals$2f$esm$2f$forwardRef$2f$forwardRef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(function BaseCircularProgress(props, ref) {
    const { material } = props, other = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$objectWithoutPropertiesLoose$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(props, _excluded5);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$CircularProgress$2f$CircularProgress$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$extends$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({}, other, material, {
        ref: ref
    }));
});
if ("TURBOPACK compile-time truthy", 1) BaseCircularProgress.displayName = "BaseCircularProgress";
const BaseDivider = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$internals$2f$esm$2f$forwardRef$2f$forwardRef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(function BaseDivider(props, ref) {
    const { material } = props, other = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$objectWithoutPropertiesLoose$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(props, _excluded6);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Divider$2f$Divider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$extends$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({}, other, material, {
        ref: ref
    }));
});
if ("TURBOPACK compile-time truthy", 1) BaseDivider.displayName = "BaseDivider";
const BaseLinearProgress = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$internals$2f$esm$2f$forwardRef$2f$forwardRef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(function BaseLinearProgress(props, ref) {
    const { material } = props, other = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$objectWithoutPropertiesLoose$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(props, _excluded7);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$LinearProgress$2f$LinearProgress$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$extends$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({}, other, material, {
        ref: ref
    }));
});
if ("TURBOPACK compile-time truthy", 1) BaseLinearProgress.displayName = "BaseLinearProgress";
const BaseButton = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$internals$2f$esm$2f$forwardRef$2f$forwardRef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(function BaseButton(props, ref) {
    const { material } = props, other = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$objectWithoutPropertiesLoose$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(props, _excluded8);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$extends$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({}, other, material, {
        ref: ref
    }));
});
if ("TURBOPACK compile-time truthy", 1) BaseButton.displayName = "BaseButton";
const StyledToggleButton = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ToggleButton$2f$ToggleButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
    slot: 'internal'
})(({ theme })=>({
        gap: theme.spacing(1),
        border: 0
    }));
const BaseToggleButton = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$internals$2f$esm$2f$forwardRef$2f$forwardRef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(function BaseToggleButton(props, ref) {
    const { material } = props, rest = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$objectWithoutPropertiesLoose$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(props, _excluded9);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(StyledToggleButton, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$extends$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({
        size: "small",
        color: "primary"
    }, rest, material, {
        ref: ref
    }));
});
if ("TURBOPACK compile-time truthy", 1) BaseToggleButton.displayName = "BaseToggleButton";
const BaseChip = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$internals$2f$esm$2f$forwardRef$2f$forwardRef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(function BaseChip(props, ref) {
    const { material } = props, other = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$objectWithoutPropertiesLoose$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(props, _excluded0);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$extends$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({}, other, material, {
        ref: ref
    }));
});
if ("TURBOPACK compile-time truthy", 1) BaseChip.displayName = "BaseChip";
const BaseIconButton = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$internals$2f$esm$2f$forwardRef$2f$forwardRef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(function BaseIconButton(props, ref) {
    const { material } = props, other = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$objectWithoutPropertiesLoose$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(props, _excluded1);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$extends$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({}, other, material, {
        ref: ref
    }));
});
if ("TURBOPACK compile-time truthy", 1) BaseIconButton.displayName = "BaseIconButton";
const BaseTooltip = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$internals$2f$esm$2f$forwardRef$2f$forwardRef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(function BaseTooltip(props, ref) {
    const { material } = props, other = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$objectWithoutPropertiesLoose$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(props, _excluded10);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$extends$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({}, other, material, {
        ref: ref
    }));
});
if ("TURBOPACK compile-time truthy", 1) BaseTooltip.displayName = "BaseTooltip";
const BaseSkeleton = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$internals$2f$esm$2f$forwardRef$2f$forwardRef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(function BaseSkeleton(props, ref) {
    const { material } = props, other = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$objectWithoutPropertiesLoose$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(props, _excluded11);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Skeleton$2f$Skeleton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$extends$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({}, other, material, {
        ref: ref
    }));
});
if ("TURBOPACK compile-time truthy", 1) BaseSkeleton.displayName = "BaseSkeleton";
const BaseSwitch = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$internals$2f$esm$2f$forwardRef$2f$forwardRef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(function BaseSwitch(props, ref) {
    const { material, label, className } = props, other = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$objectWithoutPropertiesLoose$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(props, _excluded12);
    if (!label) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Switch$2f$Switch$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$extends$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({}, other, material, {
            className: className,
            ref: ref
        }));
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(FormControlLabel, {
        className: className,
        control: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Switch$2f$Switch$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$extends$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({}, other, material, {
            ref: ref
        })),
        label: label
    });
});
if ("TURBOPACK compile-time truthy", 1) BaseSwitch.displayName = "BaseSwitch";
const BaseMenuList = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$internals$2f$esm$2f$forwardRef$2f$forwardRef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(function BaseMenuList(props, ref) {
    const { material } = props, other = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$objectWithoutPropertiesLoose$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(props, _excluded13);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$MenuList$2f$MenuList$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$extends$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({}, other, material, {
        ref: ref
    }));
});
if ("TURBOPACK compile-time truthy", 1) BaseMenuList.displayName = "BaseMenuList";
function BaseMenuItem(props) {
    const { inert, iconStart, iconEnd, children, material } = props, other = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$objectWithoutPropertiesLoose$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(props, _excluded14);
    if (inert) {
        other.disableRipple = true;
    }
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$MenuItem$2f$MenuItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$extends$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({}, other, material), [
        iconStart && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemIcon$2f$ListItemIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            children: iconStart
        }, "1"),
        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(ListItemText, {
            children: children
        }, "2"),
        iconEnd && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemIcon$2f$ListItemIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            children: iconEnd
        }, "3")
    ]);
}
function BaseTextField(props) {
    // MaterialUI v5 doesn't support slotProps, until we drop v5 support we need to
    // translate the pattern.
    const { slotProps, material } = props, other = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$objectWithoutPropertiesLoose$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(props, _excluded15);
    const theme = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$useTheme$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__useTheme$3e$__["useTheme"])();
    const textFieldDefaults = theme.components?.MuiTextField?.defaultProps ?? {};
    const computedVariant = other.variant ?? textFieldDefaults.variant ?? 'outlined';
    const computedSize = other.size ?? textFieldDefaults.size;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$extends$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({
        variant: computedVariant,
        size: computedSize
    }, other, material, {
        inputProps: slotProps?.htmlInput,
        InputProps: transformInputProps(slotProps?.input),
        InputLabelProps: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$extends$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({
            shrink: true
        }, slotProps?.inputLabel)
    }));
}
function BaseAutocomplete(props) {
    const rootProps = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$hooks$2f$utils$2f$useGridRootProps$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGridRootProps"])();
    const { id, multiple, freeSolo, options, getOptionLabel, isOptionEqualToValue, value, onChange, label, placeholder, slotProps, material } = props, other = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$objectWithoutPropertiesLoose$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(props, _excluded16);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Autocomplete$2f$Autocomplete$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["default"], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$extends$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({
        id: id,
        multiple: multiple,
        freeSolo: freeSolo,
        options: options,
        getOptionLabel: getOptionLabel,
        isOptionEqualToValue: isOptionEqualToValue,
        value: value,
        onChange: onChange,
        renderTags: (currentValue, getTagProps)=>currentValue.map((option, index)=>{
                const _getTagProps = getTagProps({
                    index
                }), { key } = _getTagProps, tagProps = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$objectWithoutPropertiesLoose$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(_getTagProps, _excluded17);
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$extends$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({
                    variant: "outlined",
                    size: "small",
                    label: typeof option === 'string' ? option : getOptionLabel?.(option)
                }, tagProps), key);
            }),
        renderInput: (params)=>{
            const { inputProps, InputProps, InputLabelProps } = params, inputRest = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$objectWithoutPropertiesLoose$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(params, _excluded18);
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$extends$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({}, inputRest, {
                label: label,
                placeholder: placeholder,
                inputProps: inputProps,
                InputProps: transformInputProps(InputProps, false),
                InputLabelProps: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$extends$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({
                    shrink: true
                }, InputLabelProps)
            }, slotProps?.textField, rootProps.slotProps?.baseTextField));
        }
    }, other, material));
}
function BaseInput(props) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$InputBase$2f$InputBase$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$extends$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({}, transformInputProps(props)));
}
function transformInputProps(props, wrapAdornments = true) {
    if (!props) {
        return undefined;
    }
    const { slotProps, material } = props, other = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$objectWithoutPropertiesLoose$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(props, _excluded19);
    const result = other;
    if (wrapAdornments) {
        if (result.startAdornment) {
            result.startAdornment = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(InputAdornment, {
                position: "start",
                children: result.startAdornment
            });
        }
        if (result.endAdornment) {
            result.endAdornment = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(InputAdornment, {
                position: "end",
                children: result.endAdornment
            });
        }
    }
    for(const k in material){
        if (Object.hasOwn(material, k)) {
            result[k] = material[k];
        }
    }
    if (slotProps?.htmlInput) {
        if (result.inputProps) {
            result.inputProps = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$extends$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({}, result.inputProps, slotProps?.htmlInput);
        } else {
            result.inputProps = slotProps?.htmlInput;
        }
    }
    return result;
}
const BaseTextarea = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$internals$2f$esm$2f$forwardRef$2f$forwardRef$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(function BaseTextarea(props, ref) {
    const { material } = props, other = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$objectWithoutPropertiesLoose$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(props, _excluded20);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextareaAutosize$2f$TextareaAutosize$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$extends$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({}, other, material, {
        ref: ref
    }));
});
if ("TURBOPACK compile-time truthy", 1) BaseTextarea.displayName = "BaseTextarea";
const transformOrigin = {
    'bottom-start': 'top left',
    'bottom-end': 'top right'
};
function BasePopper(props) {
    const { open, children, className, flip, onExited, onDidShow, onDidHide, id, target, transition, placement, material } = props, other = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$objectWithoutPropertiesLoose$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(props, _excluded21);
    const modifiers = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "BasePopper.useMemo[modifiers]": ()=>{
            const result = [
                {
                    name: 'preventOverflow',
                    options: {
                        padding: 8
                    }
                }
            ];
            if (flip) {
                result.push({
                    name: 'flip',
                    enabled: true
                });
            }
            if (onDidShow || onDidHide) {
                result.push({
                    name: 'isPlaced',
                    enabled: true,
                    phase: 'main',
                    fn: {
                        "BasePopper.useMemo[modifiers]": ()=>{
                            onDidShow?.();
                        }
                    }["BasePopper.useMemo[modifiers]"],
                    effect: {
                        "BasePopper.useMemo[modifiers]": ()=>({
                                "BasePopper.useMemo[modifiers]": ()=>{
                                    onDidHide?.();
                                }
                            })["BasePopper.useMemo[modifiers]"]
                    }["BasePopper.useMemo[modifiers]"]
                });
            }
            return result;
        }
    }["BasePopper.useMemo[modifiers]"], [
        flip,
        onDidShow,
        onDidHide
    ]);
    let content;
    if (!transition) {
        content = wrappers(props, children);
    } else {
        const handleExited = (popperOnExited)=>(node)=>{
                if (popperOnExited) {
                    popperOnExited();
                }
                if (onExited) {
                    onExited(node);
                }
            };
        content = (p)=>wrappers(props, /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Grow$2f$Grow$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$extends$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({}, p.TransitionProps, {
                style: {
                    transformOrigin: transformOrigin[p.placement]
                },
                onExited: handleExited(p.TransitionProps?.onExited),
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Paper$2f$Paper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    children: children
                })
            })));
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Popper$2f$Popper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$extends$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({
        id: id,
        className: className,
        open: open,
        anchorEl: target,
        transition: transition,
        placement: placement,
        modifiers: modifiers
    }, other, material, {
        children: content
    }));
}
function wrappers(props, content) {
    return focusTrapWrapper(props, clickAwayWrapper(props, content));
}
function clickAwayWrapper(props, content) {
    if (props.onClickAway === undefined) {
        return content;
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ClickAwayListener$2f$ClickAwayListener$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__ClickAwayListener__as__default$3e$__["default"], {
        onClickAway: props.onClickAway,
        touchEvent: props.clickAwayTouchEvent,
        mouseEvent: props.clickAwayMouseEvent,
        children: content
    });
}
function focusTrapWrapper(props, content) {
    if (props.focusTrap === undefined) {
        return content;
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Unstable_TrapFocus$2f$FocusTrap$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        open: true,
        disableEnforceFocus: true,
        disableAutoFocus: true,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("div", {
            tabIndex: -1,
            children: content
        })
    });
}
function BaseSelectOption(_ref) {
    let { native } = _ref, props = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$objectWithoutPropertiesLoose$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(_ref, _excluded22);
    if (native) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("option", (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$extends$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({}, props));
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$MenuItem$2f$MenuItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$extends$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({}, props));
}
const StyledTabs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tabs$2f$Tabs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
    name: 'MuiDataGrid',
    slot: 'Tabs'
})(({ theme })=>({
        borderBottom: `1px solid ${theme.palette.divider}`
    }));
const StyledTab = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__styled$3e$__["styled"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tab$2f$Tab$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
    name: 'MuiDataGrid',
    slot: 'Tab'
})({
    flex: 1,
    minWidth: 'fit-content'
});
const StyledTabPanel = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$styled$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__styled$3e$__["styled"])('div', {
    name: 'MuiDataGrid',
    slot: 'TabPanel'
})({
    flex: 1,
    display: 'flex',
    flexDirection: 'column',
    overflow: 'hidden'
});
function TabPanel(props) {
    const { children, active } = props, other = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$objectWithoutPropertiesLoose$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(props, _excluded23);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(StyledTabPanel, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$extends$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({
        role: "tabpanel",
        style: {
            display: active ? 'flex' : 'none'
        }
    }, other, {
        children: children
    }));
}
function BaseTabs(_ref2) {
    let { items, value, material } = _ref2, props = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$objectWithoutPropertiesLoose$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(_ref2, _excluded24);
    const id = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$utils$2f$esm$2f$useId$2f$useId$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])();
    const labelId = `${id}-tab-${value}`;
    const panelId = `${id}-tabpanel-${value}`;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(StyledTabs, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$extends$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({}, props, {
                value: value,
                variant: "scrollable",
                scrollButtons: "auto"
            }, material, {
                children: items.map((item)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(StyledTab, {
                        value: item.value,
                        label: item.label,
                        id: labelId,
                        "aria-controls": panelId
                    }, item.value))
            })),
            items.map((item)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(TabPanel, {
                    value: item.value,
                    active: value === item.value,
                    id: panelId,
                    "aria-labelledby": labelId,
                    children: item.children
                }, item.value))
        ]
    });
}
const iconSlots = {
    booleanCellTrueIcon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$material$2f$icons$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridCheckIcon"],
    booleanCellFalseIcon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$material$2f$icons$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridCloseIcon"],
    columnMenuIcon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$material$2f$icons$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridTripleDotsVerticalIcon"],
    openFilterButtonIcon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$material$2f$icons$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridFilterListIcon"],
    filterPanelDeleteIcon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$material$2f$icons$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridCloseIcon"],
    undoIcon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$material$2f$icons$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridUndoIcon"],
    redoIcon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$material$2f$icons$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridRedoIcon"],
    columnFilteredIcon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$material$2f$icons$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridFilterAltIcon"],
    columnSelectorIcon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$material$2f$icons$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridColumnIcon"],
    columnUnsortedIcon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$GridColumnUnsortedIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridColumnUnsortedIcon"],
    columnSortedAscendingIcon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$material$2f$icons$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridArrowUpwardIcon"],
    columnSortedDescendingIcon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$material$2f$icons$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridArrowDownwardIcon"],
    columnResizeIcon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$material$2f$icons$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridSeparatorIcon"],
    densityCompactIcon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$material$2f$icons$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridViewHeadlineIcon"],
    densityStandardIcon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$material$2f$icons$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridTableRowsIcon"],
    densityComfortableIcon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$material$2f$icons$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridViewStreamIcon"],
    exportIcon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$material$2f$icons$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridDownloadIcon"],
    moreActionsIcon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$material$2f$icons$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridMoreVertIcon"],
    treeDataCollapseIcon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$material$2f$icons$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridExpandMoreIcon"],
    treeDataExpandIcon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$material$2f$icons$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridKeyboardArrowRight"],
    groupingCriteriaCollapseIcon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$material$2f$icons$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridExpandMoreIcon"],
    groupingCriteriaExpandIcon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$material$2f$icons$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridKeyboardArrowRight"],
    detailPanelExpandIcon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$material$2f$icons$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridAddIcon"],
    detailPanelCollapseIcon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$material$2f$icons$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridRemoveIcon"],
    rowReorderIcon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$material$2f$icons$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridDragIcon"],
    quickFilterIcon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$material$2f$icons$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridSearchIcon"],
    quickFilterClearIcon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$material$2f$icons$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridClearIcon"],
    columnMenuHideIcon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$material$2f$icons$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridVisibilityOffIcon"],
    columnMenuSortAscendingIcon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$material$2f$icons$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridArrowUpwardIcon"],
    columnMenuSortDescendingIcon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$material$2f$icons$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridArrowDownwardIcon"],
    columnMenuUnsortIcon: null,
    columnMenuFilterIcon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$material$2f$icons$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridFilterAltIcon"],
    columnMenuManageColumnsIcon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$material$2f$icons$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridViewColumnIcon"],
    columnMenuClearIcon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$material$2f$icons$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridClearIcon"],
    loadIcon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$material$2f$icons$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridLoadIcon"],
    filterPanelAddIcon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$material$2f$icons$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridAddIcon"],
    filterPanelRemoveAllIcon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$material$2f$icons$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridDeleteForeverIcon"],
    columnReorderIcon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$material$2f$icons$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridDragIcon"],
    menuItemCheckIcon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$material$2f$icons$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridCheckIcon"],
    longTextCellExpandIcon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$material$2f$icons$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridLongTextCellExpandIcon"],
    longTextCellCollapseIcon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$material$2f$icons$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GridLongTextCellCollapseIcon"]
};
const baseSlots = {
    baseAutocomplete: BaseAutocomplete,
    baseBadge: BaseBadge,
    baseCheckbox: BaseCheckbox,
    baseChip: BaseChip,
    baseCircularProgress: BaseCircularProgress,
    baseDivider: BaseDivider,
    baseInput: BaseInput,
    baseTextarea: BaseTextarea,
    baseLinearProgress: BaseLinearProgress,
    baseMenuList: BaseMenuList,
    baseMenuItem: BaseMenuItem,
    baseTextField: BaseTextField,
    baseButton: BaseButton,
    baseIconButton: BaseIconButton,
    baseToggleButton: BaseToggleButton,
    baseTooltip: BaseTooltip,
    baseTabs: BaseTabs,
    basePagination: BasePagination,
    basePopper: BasePopper,
    baseSelect: BaseSelect,
    baseSelectOption: BaseSelectOption,
    baseSkeleton: BaseSkeleton,
    baseSwitch: BaseSwitch
};
const materialSlots = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$babel$2f$runtime$2f$helpers$2f$esm$2f$extends$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({}, baseSlots, iconSlots);
const __TURBOPACK__default__export__ = materialSlots;
}),
"[project]/node_modules/@mui/x-data-grid/esm/material/variables.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useMaterialCSSVariables",
    ()=>useMaterialCSSVariables
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/system/esm/colorManipulator/colorManipulator.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$useTheme$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__useTheme$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/styles/useTheme.js [app-client] (ecmascript) <export default as useTheme>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$internals$2f$esm$2f$hash$2f$hash$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-internals/esm/hash/hash.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$constants$2f$cssVariables$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/constants/cssVariables.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$containers$2f$GridRootStyles$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/x-data-grid/esm/components/containers/GridRootStyles.js [app-client] (ecmascript)");
;
;
;
;
;
;
function useMaterialCSSVariables() {
    const theme = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$useTheme$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__useTheme$3e$__["useTheme"])();
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "useMaterialCSSVariables.useMemo": ()=>{
            const id = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$internals$2f$esm$2f$hash$2f$hash$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hash"])(stringifyTheme(theme));
            const variables = transformTheme(theme);
            return {
                id,
                variables
            };
        }
    }["useMaterialCSSVariables.useMemo"], [
        theme
    ]);
}
function transformTheme(t) {
    const borderColor = getBorderColor(t);
    const dataGridPalette = (t.vars || t).palette.DataGrid;
    const paperColor = (t.vars || t).palette.background.paper;
    const backgroundBase = dataGridPalette?.bg ?? (t.palette.mode === 'dark' ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$containers$2f$GridRootStyles$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["colorMixIfSupported"])(`color-mix(in srgb, ${paperColor} 95%, #fff)`, paperColor) : paperColor);
    const backgroundHeader = dataGridPalette?.headerBg ?? backgroundBase;
    const backgroundPinned = dataGridPalette?.pinnedBg ?? backgroundBase;
    const backgroundBackdrop = t.vars ? `rgba(${t.vars.palette.background.defaultChannel} / ${t.vars.palette.action.disabledOpacity})` : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["alpha"])(t.palette.background.default, t.palette.action.disabledOpacity);
    const backgroundOverlay = t.palette.mode === 'dark' ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$containers$2f$GridRootStyles$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["colorMixIfSupported"])(`color-mix(in srgb, ${paperColor} 90%, #fff)`, paperColor) : paperColor;
    const selectedColor = t.vars ? `rgb(${t.vars.palette.primary.mainChannel})` : t.palette.primary.main;
    const radius = getRadius(t);
    const fontBody = t.vars?.font?.body2 ?? formatFont(t.typography.body2);
    const fontSmall = t.vars?.font?.caption ?? formatFont(t.typography.caption);
    const fontLarge = t.vars?.font?.body1 ?? formatFont(t.typography.body1);
    const k = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$constants$2f$cssVariables$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["vars"].keys;
    return {
        [k.spacingUnit]: t.vars ? t.vars.spacing ?? t.spacing(1) : t.spacing(1),
        [k.colors.border.base]: borderColor,
        [k.colors.background.base]: backgroundBase,
        [k.colors.background.overlay]: backgroundOverlay,
        [k.colors.background.backdrop]: backgroundBackdrop,
        [k.colors.foreground.base]: (t.vars || t).palette.text.primary,
        [k.colors.foreground.muted]: (t.vars || t).palette.text.secondary,
        [k.colors.foreground.accent]: (t.vars || t).palette.primary.dark,
        [k.colors.foreground.disabled]: (t.vars || t).palette.text.disabled,
        [k.colors.foreground.error]: (t.vars || t).palette.error.dark,
        [k.colors.interactive.hover]: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$containers$2f$GridRootStyles$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supportsColorMix"] ? (t.vars || t).palette.action.hover : (t.vars || t).palette.grey[t.palette.mode === 'dark' ? 800 : 100],
        [k.colors.interactive.hoverOpacity]: (t.vars || t).palette.action.hoverOpacity,
        [k.colors.interactive.focus]: removeOpacity((t.vars || t).palette.primary.main),
        [k.colors.interactive.focusOpacity]: (t.vars || t).palette.action.focusOpacity,
        [k.colors.interactive.disabled]: removeOpacity((t.vars || t).palette.action.disabled),
        [k.colors.interactive.disabledOpacity]: (t.vars || t).palette.action.disabledOpacity,
        [k.colors.interactive.selected]: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$x$2d$data$2d$grid$2f$esm$2f$components$2f$containers$2f$GridRootStyles$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supportsColorMix"] ? selectedColor : (t.vars || t).palette.grey[t.palette.mode === 'dark' ? 700 : 200],
        [k.colors.interactive.selectedOpacity]: (t.vars || t).palette.action.selectedOpacity,
        [k.header.background.base]: backgroundHeader,
        [k.cell.background.pinned]: backgroundPinned,
        [k.radius.base]: radius,
        [k.typography.fontFamily.base]: t.typography.fontFamily,
        [k.typography.fontWeight.light]: t.typography.fontWeightLight,
        [k.typography.fontWeight.regular]: t.typography.fontWeightRegular,
        [k.typography.fontWeight.medium]: t.typography.fontWeightMedium,
        [k.typography.fontWeight.bold]: t.typography.fontWeightBold,
        [k.typography.font.body]: fontBody,
        [k.typography.font.small]: fontSmall,
        [k.typography.font.large]: fontLarge,
        [k.transitions.easing.easeIn]: t.transitions.easing.easeIn,
        [k.transitions.easing.easeOut]: t.transitions.easing.easeOut,
        [k.transitions.easing.easeInOut]: t.transitions.easing.easeInOut,
        [k.transitions.duration.short]: `${t.transitions.duration.shorter}ms`,
        [k.transitions.duration.base]: `${t.transitions.duration.short}ms`,
        [k.transitions.duration.long]: `${t.transitions.duration.standard}ms`,
        [k.shadows.base]: (t.vars || t).shadows[2],
        [k.shadows.overlay]: (t.vars || t).shadows[8],
        [k.zIndex.panel]: (t.vars || t).zIndex.modal,
        [k.zIndex.menu]: (t.vars || t).zIndex.modal
    };
}
function getRadius(theme) {
    if (theme.vars) {
        return theme.vars.shape.borderRadius;
    }
    return typeof theme.shape.borderRadius === 'number' ? `${theme.shape.borderRadius}px` : theme.shape.borderRadius;
}
function getBorderColor(theme) {
    if (theme.vars) {
        return theme.vars.palette.TableCell.border;
    }
    if (theme.palette.mode === 'light') {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["lighten"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["alpha"])(theme.palette.divider, 1), 0.88);
    }
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["darken"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["alpha"])(theme.palette.divider, 1), 0.68);
}
function setOpacity(color, opacity) {
    return `rgba(from ${color} r g b / ${opacity})`;
}
function removeOpacity(color) {
    return setOpacity(color, 1);
}
function formatFont(font) {
    // Accounts for disabled typography variants
    // See: https://github.com/mui/mui-x/issues/17812
    if (!font) {
        return undefined;
    }
    const fontSize = typeof font.fontSize === 'number' ? `${font.fontSize}px` : font.fontSize;
    return `${font.fontWeight} ${fontSize} / ${font.lineHeight} ${font.fontFamily}`;
}
/**
 * A version of JSON.stringify for theme objects.
 * Fixes: https://github.com/mui/mui-x/issues/17521
 * Source: https://www.30secondsofcode.org/js/s/stringify-circular-json/
 */ function stringifyTheme(input) {
    const seen = new WeakSet();
    return JSON.stringify(input, (_, v)=>{
        // https://github.com/mui/mui-x/issues/17855
        if (typeof window !== 'undefined' && v === window || typeof document !== 'undefined' && v === document) {
            return v.toString();
        }
        if (v !== null && typeof v === 'object') {
            // Do not attempt to serialize React elements due to performance concerns.
            // Fixes https://github.com/mui/mui-x/issues/19414
            if (/*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isValidElement"](v)) {
                return null;
            }
            if (seen.has(v)) {
                return null;
            }
            seen.add(v);
        }
        return v;
    });
}
}),
]);

//# sourceMappingURL=node_modules_%40mui_x-data-grid_esm_d1b76d49._.js.map